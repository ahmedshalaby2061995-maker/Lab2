"""
Labor Market Analysis Agent
============================
LangChain-based agent that orchestrates all POC tools:
  - ingestion      (for new file uploads)
  - validator      (quality checks)
  - trend_analyzer (QoQ, YoY, cohort compare, breakdowns)
  - forecaster     (baseline + scenarios)
  - rag            (retrieve from prior studies & methodology docs)
  - report_gen     (full executive briefings, MD + PDF)

Uses OpenAI (or any OpenAI-compatible endpoint) via LangChain. Falls back to a
deterministic rule-based router if OPENAI_API_KEY is not configured (so the
POC can be demoed offline).

Key design notes:
  * The agent receives a single user message and returns a natural-language
    response plus an optional 'artifacts' payload (charts, tables, PDF paths).
  * Tools return JSON-serializable dicts; the agent's final step is always to
    narrate the result in executive-ready prose.
"""
from __future__ import annotations

import os
import json
import re
import traceback
from typing import Dict, List, Any, Optional

from tools.validator import validate_dataset
from tools.trend_analyzer import (
    analyze_trend, compare_cohorts, breakdown_by_dimension, get_time_series
)
from tools.forecaster import forecast_indicator, summarize_forecast
from tools.rag import RAGStore
from tools.report_generator import (
    build_quarterly_report_md, build_quarterly_report_pdf
)


# ---------- Tool definitions (LangChain-compatible JSON schema) ----------

TOOL_SCHEMAS = [
    {
        "name": "validate_data",
        "description": "Run data quality checks on the ingested labor market database. "
                       "Returns a list of validation flags (duplicates, out-of-range values, "
                       "missing quarters, identity violations).",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "analyze_trend",
        "description": "Analyze the time-series trend of a labor market indicator. "
                       "Returns latest value, QoQ change, YoY change, min/max, and direction. "
                       "Use this for questions like 'how has Saudi unemployment trended?'",
        "input_schema": {
            "type": "object",
            "properties": {
                "indicator": {"type": "string",
                              "enum": ["unemployment_rate", "employment_to_population",
                                        "labor_force_participation", "average_working_hours"],
                              "description": "Which indicator to analyze."},
                "nationality": {"type": "string", "enum": ["Saudi", "Non-Saudi", "Total"],
                                 "default": "Saudi"},
                "sex": {"type": "string", "enum": ["Male", "Female", "Total"], "default": "Total"},
            },
            "required": ["indicator"],
        },
    },
    {
        "name": "compare_cohorts",
        "description": "Compare several (nationality, sex) cohorts on the same indicator at "
                       "the latest quarter. Use for 'compare Saudi male vs female unemployment'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "indicator": {"type": "string"},
                "cohorts": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "nationality": {"type": "string"},
                            "sex": {"type": "string"},
                            "label": {"type": "string"},
                        },
                    },
                },
            },
            "required": ["indicator", "cohorts"],
        },
    },
    {
        "name": "breakdown",
        "description": "Break an indicator down by a structural dimension (age, education, "
                       "region) for a given quarter. Use for 'show unemployment by region'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "indicator": {"type": "string"},
                "dimension": {"type": "string",
                               "enum": ["age_group", "education", "region",
                                         "occupation", "economic_activity"]},
                "nationality": {"type": "string", "default": "Saudi"},
                "sex": {"type": "string", "default": "Total"},
                "quarter": {"type": "string",
                             "description": "YYYY-Qn format. Defaults to latest."},
            },
            "required": ["indicator", "dimension"],
        },
    },
    {
        "name": "forecast",
        "description": "Produce baseline + optimistic/pessimistic scenario forecasts for an "
                       "indicator over the next N quarters. Use for 'project next year's "
                       "unemployment'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "indicator": {"type": "string"},
                "nationality": {"type": "string", "default": "Saudi"},
                "sex": {"type": "string", "default": "Total"},
                "horizon": {"type": "integer", "minimum": 1, "maximum": 12, "default": 4},
            },
            "required": ["indicator"],
        },
    },
    {
        "name": "search_knowledge_base",
        "description": "Search prior economic studies, methodology docs, and policy briefs "
                       "for qualitative context. Use for 'what does the literature say about "
                       "youth unemployment drivers?' or to enrich quantitative findings.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "k": {"type": "integer", "default": 4},
            },
            "required": ["query"],
        },
    },
    {
        "name": "generate_report",
        "description": "Generate a full quarterly executive briefing (Markdown + PDF) "
                       "combining trends, cohort comparisons, breakdowns, forecasts, and "
                       "qualitative context. Use for 'produce the Q4 report'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "reference_quarter": {"type": "string",
                                       "description": "YYYY-Qn. Defaults to latest available."},
            },
            "required": [],
        },
    },
]


# ---------- Tool dispatcher ----------

class AgentContext:
    """Holds shared state: DB path, RAG store, output directories."""

    def __init__(self, db_path: str = "data/labor.db",
                 rag_corpus_dir: str = "data/rag_corpus",
                 output_dir: str = "data/processed"):
        self.db_path = db_path
        self.rag_corpus_dir = rag_corpus_dir
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.rag = RAGStore(backend=os.getenv("RAG_BACKEND", "tfidf"))
        self._rag_indexed = False

    def ensure_rag(self):
        if not self._rag_indexed:
            n = self.rag.build_from_directory(self.rag_corpus_dir)
            self._rag_indexed = True
            return n
        return None


def execute_tool(ctx: AgentContext, name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Dispatch a tool call. Returns the tool result dict."""
    try:
        if name == "validate_data":
            return validate_dataset(ctx.db_path)
        if name == "analyze_trend":
            return analyze_trend(
                ctx.db_path,
                indicator=args["indicator"],
                nationality=args.get("nationality", "Saudi"),
                sex=args.get("sex", "Total"),
            )
        if name == "compare_cohorts":
            return compare_cohorts(
                ctx.db_path,
                indicator=args["indicator"],
                cohorts=args["cohorts"],
            )
        if name == "breakdown":
            return breakdown_by_dimension(
                ctx.db_path,
                indicator=args["indicator"],
                dimension=args["dimension"],
                nationality=args.get("nationality", "Saudi"),
                sex=args.get("sex", "Total"),
                quarter=args.get("quarter"),
            )
        if name == "forecast":
            return forecast_indicator(
                ctx.db_path,
                indicator=args["indicator"],
                nationality=args.get("nationality", "Saudi"),
                sex=args.get("sex", "Total"),
                horizon=args.get("horizon", 4),
            )
        if name == "search_knowledge_base":
            ctx.ensure_rag()
            return ctx.rag.query(args["query"], k=args.get("k", 4))
        if name == "generate_report":
            ctx.ensure_rag()
            q = args.get("reference_quarter")
            # Pull some RAG context for the report
            ctx_hits = ctx.rag.search(
                "Saudi Arabia labor market trends drivers Vision 2030 unemployment",
                k=4)
            md = build_quarterly_report_md(ctx.db_path, reference_quarter=q,
                                            rag_insights=ctx_hits)
            md_path = os.path.join(ctx.output_dir, "quarterly_briefing.md")
            with open(md_path, "w", encoding="utf-8") as f:
                f.write(md)
            pdf_path = os.path.join(ctx.output_dir, "quarterly_briefing.pdf")
            build_quarterly_report_pdf(ctx.db_path, pdf_path, reference_quarter=q,
                                        rag_insights=ctx_hits)
            return {"ok": True, "markdown_path": md_path, "pdf_path": pdf_path,
                    "markdown_preview": md[:2000]}
        return {"ok": False, "error": f"Unknown tool: {name}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "traceback": traceback.format_exc()}


# ---------- Agent: LangChain/OpenAI path ----------

SYSTEM_PROMPT = """You are a senior labor market analyst AI agent for the Kingdom of Saudi Arabia, \
working from GASTAT (General Authority for Statistics) Labor Force Survey data and prior \
economic studies. Your role is to help a Central Team produce quarterly C-level briefings on \
unemployment, labor force participation, and employment dynamics.

You have access to a structured database of 20+ quarters of GASTAT data (2021 Q1 to present) \
and a knowledge base of prior economic studies, methodology notes, and Vision 2030 policy briefs.

## How to respond:

1. **For data questions** (e.g. "what's the latest Saudi unemployment rate?", "how has youth \
unemployment trended?", "compare male vs female"), call the appropriate tool(s) to get the \
numbers, THEN narrate the finding in 2-4 concise sentences with specific figures, QoQ/YoY \
context, and what it means.

2. **For context/why questions** (e.g. "why is youth unemployment elevated?", "what drives \
female LFP?"), use `search_knowledge_base` to pull from prior studies, then synthesize in \
your own words. Cite the source document briefly.

3. **For "build/generate report" requests**, call `generate_report` and summarize the \
highlights.

4. **For forecasting questions**, use `forecast` with horizon=4 by default. Always mention the \
baseline vs optimistic vs pessimistic scenarios when narrating.

5. **Be concrete**. Always cite specific quarters, values, and percentage-point changes. \
Avoid vague phrases like "has improved somewhat".

6. **Flag data quality issues** when a validation check raises flags.

7. **Be evenhanded**. Note both positive and negative indicators. Don't overclaim causality \
from correlation.

Keep responses executive-ready: factual, concise, and actionable. Use 2-5 short paragraphs \
or structured bullets — not essays.
"""


class LangChainAgent:
    """
    Agent that uses OpenAI (or any OpenAI-compatible endpoint) via LangChain's
    tool-calling loop. Supports custom base URLs (for Azure OpenAI, OpenRouter,
    LiteLLM proxies, local vLLM/Ollama servers, etc).

    Reads from environment:
      OPENAI_API_KEY    — required to enable the LLM agent
      OPENAI_BASE_URL   — optional, custom endpoint (defaults to OpenAI's API)
      OPENAI_MODEL      — optional, defaults to "gpt-4o-mini"

    Falls back to the rule-based router if langchain_openai is not installed
    or no API key is set.
    """

    def __init__(self, ctx: AgentContext, model: Optional[str] = None,
                 max_iters: int = 6):
        self.ctx = ctx
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.max_iters = max_iters
        self._llm = None
        self._available = False
        self._init_llm()

    def _init_llm(self):
        """Try to initialize LangChain + OpenAI. Degrade gracefully."""
        try:
            from langchain_openai import ChatOpenAI
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                return
            base_url = os.getenv("OPENAI_BASE_URL") or os.getenv("OPENAI_API_BASE")
            kwargs = {
                "model": self.model,
                "temperature": 0.2,
                "max_tokens": 2000,
                "api_key": api_key,
            }
            if base_url:
                kwargs["base_url"] = base_url
            self._llm = ChatOpenAI(**kwargs)
            # Bind our tools. langchain_openai accepts the same JSON-schema dict
            # format we already use; it will translate to OpenAI function-calling.
            self._llm_with_tools = self._llm.bind_tools([
                {
                    "type": "function",
                    "function": {
                        "name": t["name"],
                        "description": t["description"],
                        "parameters": t["input_schema"],
                    },
                }
                for t in TOOL_SCHEMAS
            ])
            self._available = True
        except ImportError:
            self._available = False
        except Exception:
            self._available = False

    @property
    def available(self) -> bool:
        return self._available

    def chat(self, message: str, history: Optional[List[Dict]] = None) -> Dict[str, Any]:
        """
        Run a single user turn. Returns:
            { "reply": str, "tool_calls": [...], "artifacts": {...} }
        """
        from langchain_core.messages import (
            SystemMessage, HumanMessage, AIMessage, ToolMessage
        )
        if not self._available:
            raise RuntimeError("LangChain agent not available.")

        messages = [SystemMessage(content=SYSTEM_PROMPT)]
        if history:
            for h in history:
                if h["role"] == "user":
                    messages.append(HumanMessage(content=h["content"]))
                elif h["role"] == "assistant":
                    messages.append(AIMessage(content=h["content"]))
        messages.append(HumanMessage(content=message))

        tool_calls_log = []
        artifacts = {}

        for _ in range(self.max_iters):
            resp = self._llm_with_tools.invoke(messages)
            messages.append(resp)

            if not getattr(resp, "tool_calls", None):
                # Final answer
                return {
                    "reply": resp.content if isinstance(resp.content, str) else str(resp.content),
                    "tool_calls": tool_calls_log,
                    "artifacts": artifacts,
                }

            for tc in resp.tool_calls:
                name = tc["name"]
                args = tc["args"]
                result = execute_tool(self.ctx, name, args)
                tool_calls_log.append({"tool": name, "args": args,
                                        "result_summary": _summarize_result(name, result)})
                # Capture artifacts
                if name == "generate_report" and result.get("ok"):
                    artifacts["pdf_path"] = result.get("pdf_path")
                    artifacts["markdown_path"] = result.get("markdown_path")
                messages.append(ToolMessage(
                    content=json.dumps(result, default=str)[:8000],
                    tool_call_id=tc["id"],
                ))

        return {
            "reply": "(Hit max tool iterations — returning what I have.)",
            "tool_calls": tool_calls_log,
            "artifacts": artifacts,
        }


# ---------- Fallback: rule-based router (no LLM required) ----------

class RuleBasedAgent:
    """
    Deterministic fallback agent for demoing the POC without an API key.
    Uses keyword routing + hand-crafted narratives. Not as flexible as the LLM
    agent but proves the tool layer works end-to-end.
    """

    def __init__(self, ctx: AgentContext):
        self.ctx = ctx

    def chat(self, message: str, history: Optional[List[Dict]] = None) -> Dict[str, Any]:
        m = message.lower().strip()
        tool_calls: List[Dict] = []
        artifacts: Dict[str, Any] = {}

        # --- Report generation ---
        if any(k in m for k in ["generate report", "quarterly report", "briefing",
                                 "executive report", "build the report", "produce report",
                                 "full report"]):
            res = execute_tool(self.ctx, "generate_report", {})
            tool_calls.append({"tool": "generate_report", "args": {},
                               "result_summary": "Generated MD+PDF briefing"})
            if res.get("ok"):
                artifacts["pdf_path"] = res["pdf_path"]
                artifacts["markdown_path"] = res["markdown_path"]
                return {
                    "reply": "Generated the quarterly briefing. The executive summary, cohort "
                             "benchmarks, structural breakdowns (age, education, region), a 4-"
                             "quarter forecast with baseline/optimistic/pessimistic scenarios, "
                             "and qualitative context from prior studies are all included. "
                             "The PDF and Markdown versions are linked below.",
                    "tool_calls": tool_calls,
                    "artifacts": artifacts,
                }
            return {"reply": f"Report generation failed: {res.get('error')}",
                    "tool_calls": tool_calls, "artifacts": artifacts}

        # --- Validation ---
        if any(k in m for k in ["validate", "validation", "data quality", "quality check",
                                 "anomalies", "inconsistencies"]):
            res = execute_tool(self.ctx, "validate_data", {})
            tool_calls.append({"tool": "validate_data", "args": {},
                               "result_summary": f"{len(res.get('flags',[]))} flags"})
            flags = res.get("flags", [])
            summary = res.get("summary", {})
            reply = (f"Validation complete. Database contains {summary.get('total_rows', 0):,} "
                     f"rows across {len(summary.get('quarters', []))} quarters and "
                     f"{len(summary.get('indicators', []))} indicators.\n\n"
                     f"Findings:\n" + "\n".join(f"• {f}" for f in flags))
            return {"reply": reply, "tool_calls": tool_calls, "artifacts": artifacts}

        # --- Forecast ---
        if any(k in m for k in ["forecast", "project", "projection", "next quarter",
                                 "next year", "predict"]):
            indicator = _detect_indicator(m)
            nat, sex = _detect_nationality_sex(m)
            res = execute_tool(self.ctx, "forecast", {
                "indicator": indicator, "nationality": nat, "sex": sex, "horizon": 4
            })
            tool_calls.append({"tool": "forecast", "args": {"indicator": indicator},
                               "result_summary": "4-quarter projection"})
            if res.get("ok"):
                s = summarize_forecast(res)
                lines = [s, ""]
                for q, b, o, p in zip(res["horizon_quarters"], res["baseline"],
                                       res["optimistic"], res["pessimistic"]):
                    lines.append(f"  • {q}: baseline {b:.2f}%, "
                                  f"optimistic {o:.2f}%, pessimistic {p:.2f}%")
                return {"reply": "\n".join(lines), "tool_calls": tool_calls, "artifacts": artifacts}

        # --- Breakdown ---
        if any(k in m for k in ["by age", "by region", "by education", "by occupation"]):
            indicator = _detect_indicator(m)
            if "region" in m:
                dim = "region"
            elif "age" in m:
                dim = "age_group"
            elif "education" in m:
                dim = "education"
            elif "occupation" in m:
                dim = "occupation"
            else:
                dim = "age_group"
            nat, sex = _detect_nationality_sex(m)
            res = execute_tool(self.ctx, "breakdown", {
                "indicator": indicator, "dimension": dim, "nationality": nat, "sex": sex
            })
            tool_calls.append({"tool": "breakdown",
                               "args": {"indicator": indicator, "dimension": dim},
                               "result_summary": f"{dim} breakdown"})
            if res.get("ok"):
                lines = [f"**{nat} {indicator.replace('_',' ')} by {dim.replace('_',' ')}** "
                          f"— {res['quarter']}:\n"]
                for r in res["breakdown"][:12]:
                    lines.append(f"  • {r['category']}: {r['value']:.2f}%")
                lines.append(f"\n**Highest:** {res['highest']} · **Lowest:** {res['lowest']}")
                return {"reply": "\n".join(lines), "tool_calls": tool_calls, "artifacts": artifacts}

        # --- Cohort compare ---
        if any(k in m for k in ["compare", "vs", "versus", "male vs female",
                                 "saudi vs non-saudi"]):
            indicator = _detect_indicator(m)
            cohorts = [
                {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
                {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
                {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
            ]
            res = execute_tool(self.ctx, "compare_cohorts",
                               {"indicator": indicator, "cohorts": cohorts})
            tool_calls.append({"tool": "compare_cohorts",
                               "args": {"indicator": indicator},
                               "result_summary": "3 cohorts compared"})
            if res.get("ok"):
                lines = [f"**{indicator.replace('_',' ').title()} — {res['latest_quarter']}**\n"]
                for k, v in res["cohort_values"].items():
                    lines.append(f"  • {k}: {v:.2f}%")
                lines.append("\n**Gaps:**")
                for g in res["gaps"]:
                    lines.append(f"  • {g['pair']}: {g['gap']:+.2f}pp")
                return {"reply": "\n".join(lines), "tool_calls": tool_calls, "artifacts": artifacts}

        # --- RAG / context ---
        if any(k in m for k in ["why", "driver", "cause", "context", "explain",
                                 "what does", "according to", "literature"]):
            res = execute_tool(self.ctx, "search_knowledge_base", {"query": message, "k": 3})
            tool_calls.append({"tool": "search_knowledge_base",
                               "args": {"query": message},
                               "result_summary": f"{res.get('n_results',0)} hits"})
            if res.get("ok"):
                lines = ["Drawing from prior studies:\n"]
                for h in res["results"][:3]:
                    snippet = h["text"][:350].replace("\n", " ")
                    lines.append(f"**Source: {h['doc_id']}** (relevance {h['score']:.2f})")
                    lines.append(f"> {snippet}...\n")
                return {"reply": "\n".join(lines), "tool_calls": tool_calls, "artifacts": artifacts}

        # --- Default: trend analysis ---
        indicator = _detect_indicator(m)
        nat, sex = _detect_nationality_sex(m)
        res = execute_tool(self.ctx, "analyze_trend", {
            "indicator": indicator, "nationality": nat, "sex": sex
        })
        tool_calls.append({"tool": "analyze_trend",
                           "args": {"indicator": indicator, "nationality": nat, "sex": sex},
                           "result_summary": "Trend analyzed"})
        if res.get("ok"):
            return {"reply": res["summary"], "tool_calls": tool_calls, "artifacts": artifacts}
        return {"reply": f"I couldn't find that series. Error: {res.get('error')}",
                "tool_calls": tool_calls, "artifacts": artifacts}


def _detect_indicator(m: str) -> str:
    if any(k in m for k in ["unemploy", "jobless"]):
        return "unemployment_rate"
    if any(k in m for k in ["employment to population", "employment-to-population",
                             "employment ratio"]):
        return "employment_to_population"
    if any(k in m for k in ["participation", "lfp", "labor force"]):
        return "labor_force_participation"
    if any(k in m for k in ["working hours", "hours worked"]):
        return "average_working_hours"
    return "unemployment_rate"


def _detect_nationality_sex(m: str) -> tuple:
    """Detect nationality & sex with word-boundary matching so 'unemployment' doesn't trigger 'men'."""
    def has_word(w: str) -> bool:
        return re.search(rf"\b{re.escape(w)}\b", m) is not None

    nat = "Saudi"
    sex = "Total"
    if "non-saudi" in m or has_word("non saudi") or has_word("expat") or has_word("expats"):
        nat = "Non-Saudi"
    elif has_word("total") or has_word("national") or has_word("overall"):
        nat = "Total"
    if has_word("female") or has_word("women") or has_word("woman"):
        sex = "Female"
    elif has_word("male") or has_word("men"):
        sex = "Male"
    return nat, sex


def _summarize_result(name: str, result: Dict) -> str:
    """Compact one-line summary of a tool result for logging."""
    if not result.get("ok", True) and "error" in result:
        return f"error: {result['error']}"
    if name == "analyze_trend" and "summary" in result:
        return result["summary"][:120]
    if name == "forecast" and result.get("ok"):
        return (f"last={result['last_historical_value']:.2f}, "
                f"baseline@{result['horizon_quarters'][-1]}={result['baseline'][-1]:.2f}")
    if name == "generate_report" and result.get("ok"):
        return f"wrote {result.get('pdf_path')}"
    if name == "search_knowledge_base":
        return f"{result.get('n_results', 0)} results"
    if name == "validate_data":
        return f"{len(result.get('flags', []))} flags"
    return "ok"


# ---------- Public factory ----------

def build_agent(ctx: Optional[AgentContext] = None):
    """Return a LangChain agent if possible, else a rule-based fallback."""
    ctx = ctx or AgentContext()
    lc = LangChainAgent(ctx)
    if lc.available:
        return lc, "langchain+openai"
    return RuleBasedAgent(ctx), "rule-based (fallback)"


if __name__ == "__main__":
    import sys
    ctx = AgentContext()
    agent, kind = build_agent(ctx)
    print(f"[Agent mode: {kind}]\n")

    # Quick smoke test with rule-based agent
    test_queries = [
        "What's the latest Saudi unemployment rate trend?",
        "Compare Saudi male vs female unemployment",
        "Show Saudi unemployment by region",
        "Forecast Saudi unemployment for next 4 quarters",
        "Why is youth unemployment elevated?",
        "Validate the dataset",
        "Generate the quarterly briefing",
    ]
    q = sys.argv[1] if len(sys.argv) > 1 else test_queries[0]
    print(f"Q: {q}\n")
    out = agent.chat(q)
    print(f"A: {out['reply']}\n")
    if out.get("tool_calls"):
        print("Tool calls:")
        for tc in out["tool_calls"]:
            print(f"  - {tc['tool']}({tc.get('args', {})}) -> {tc['result_summary']}")
    if out.get("artifacts"):
        print(f"Artifacts: {out['artifacts']}")

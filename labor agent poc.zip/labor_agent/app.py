"""
FastAPI Backend — Labor Market Analysis Agent
==============================================
Exposes:
  GET  /                     → serves the chat + dashboard UI
  POST /api/chat             → send a chat message to the agent
  POST /api/upload           → upload a new GASTAT xlsx for ingestion
  GET  /api/indicators       → list available indicators & dimensions
  GET  /api/series           → fetch a time series for the dashboard
  GET  /api/breakdown        → fetch a dimensional breakdown for the dashboard
  GET  /api/forecast         → fetch a forecast for the dashboard
  GET  /api/validate         → run validation and return flags
  POST /api/report           → generate MD + PDF briefing
  GET  /api/download/{name}  → download a generated report file
  GET  /api/health           → liveness probe

Run:
  uvicorn app:app --reload --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import os
import shutil
import logging
from pathlib import Path
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, UploadFile, File, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from agent import build_agent, AgentContext
from ingestion import ingest_gastat_xlsx, save_to_db, infer_quarter_from_filename
from tools.trend_analyzer import (
    analyze_trend, compare_cohorts, breakdown_by_dimension, get_time_series
)
from tools.forecaster import forecast_indicator
from tools.validator import validate_dataset


# ---------- Configuration ----------

BASE_DIR = Path(__file__).parent
DB_PATH = os.getenv("DB_PATH", str(BASE_DIR / "data/labor.db"))
RAG_CORPUS_DIR = os.getenv("RAG_CORPUS_DIR", str(BASE_DIR / "data/rag_corpus"))
OUTPUT_DIR = os.getenv("OUTPUT_DIR", str(BASE_DIR / "data/processed"))
UPLOADS_DIR = os.getenv("UPLOADS_DIR", str(BASE_DIR / "data/raw"))

for d in (OUTPUT_DIR, UPLOADS_DIR, RAG_CORPUS_DIR):
    os.makedirs(d, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("labor_agent")


# ---------- App & shared agent context ----------

app = FastAPI(
    title="Labor Market Analysis Agent",
    description="AI-powered agent for quarterly Saudi labor market analysis (GASTAT).",
    version="1.0.0",
)

ctx = AgentContext(db_path=DB_PATH, rag_corpus_dir=RAG_CORPUS_DIR, output_dir=OUTPUT_DIR)
agent, agent_mode = build_agent(ctx)
log.info(f"Agent initialized in {agent_mode} mode.")

# Build RAG on startup so first query is fast
try:
    n = ctx.ensure_rag()
    if n:
        log.info(f"RAG indexed {n} chunks from {RAG_CORPUS_DIR}")
except Exception as e:
    log.warning(f"RAG initialization failed: {e}")

templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


# ---------- Pydantic request/response models ----------

class ChatMessage(BaseModel):
    role: str = Field(..., description="'user' or 'assistant'")
    content: str


class ChatRequest(BaseModel):
    message: str
    history: Optional[List[ChatMessage]] = None


class ChatResponse(BaseModel):
    reply: str
    tool_calls: List[Dict[str, Any]] = []
    artifacts: Dict[str, Any] = {}
    mode: str


class ReportRequest(BaseModel):
    reference_quarter: Optional[str] = None


# ---------- Routes ----------

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Serve the chat + dashboard UI."""
    return templates.TemplateResponse("index.html", {
        "request": request,
        "agent_mode": agent_mode,
    })


@app.get("/api/health")
async def health():
    return {"status": "ok", "agent_mode": agent_mode,
            "db": os.path.exists(DB_PATH),
            "rag_corpus": os.path.isdir(RAG_CORPUS_DIR)}


@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    try:
        history = [h.model_dump() for h in (req.history or [])]
        result = agent.chat(req.message, history=history)
        return ChatResponse(
            reply=result.get("reply", ""),
            tool_calls=result.get("tool_calls", []),
            artifacts=result.get("artifacts", {}),
            mode=agent_mode,
        )
    except Exception as e:
        log.exception("chat failed")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    """Accept a new GASTAT xlsx, parse it, and load into the database."""
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400,
                            detail="Only .xlsx / .xlsm files are supported.")
    save_path = os.path.join(UPLOADS_DIR, file.filename)
    try:
        with open(save_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        # Parse
        snapshot_q = infer_quarter_from_filename(save_path)
        df = ingest_gastat_xlsx(save_path, snapshot_quarter=snapshot_q)
        if df.empty:
            raise HTTPException(status_code=400,
                                detail="Could not parse any data from this file. "
                                       "Check that it follows GASTAT format.")
        # Validate first, then save
        rows = save_to_db(df, DB_PATH, save_path)

        # Run validation
        val = validate_dataset(DB_PATH)

        return {
            "ok": True,
            "filename": file.filename,
            "snapshot_quarter": snapshot_q,
            "rows_ingested": rows,
            "indicators_detected": sorted(df["indicator"].unique().tolist()),
            "quarters_detected": sorted(df["quarter"].unique().tolist()),
            "validation": {
                "flags": val["flags"],
                "total_rows": val.get("summary", {}).get("total_rows"),
            },
        }
    except HTTPException:
        raise
    except Exception as e:
        log.exception("upload failed")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/indicators")
async def list_indicators():
    """Return the set of (indicator, dimension) pairs available in the DB."""
    import sqlite3
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    rows = cur.execute("""
        SELECT indicator, dimension, COUNT(*) as n, COUNT(DISTINCT quarter) as quarters
        FROM labor_facts GROUP BY indicator, dimension ORDER BY indicator, dimension
    """).fetchall()
    quarters = [r[0] for r in cur.execute(
        "SELECT DISTINCT quarter FROM labor_facts ORDER BY quarter"
    ).fetchall()]
    con.close()
    return {
        "indicators": [
            {"indicator": r[0], "dimension": r[1], "rows": r[2], "quarters": r[3]}
            for r in rows
        ],
        "quarters": quarters,
        "latest_quarter": quarters[-1] if quarters else None,
    }


@app.get("/api/series")
async def api_series(indicator: str, nationality: str = "Saudi", sex: str = "Total",
                    category: str = "All", dimension: str = "time_series"):
    """Return a time series for plotting."""
    df = get_time_series(DB_PATH, indicator, nationality, sex, category, dimension)
    if df.empty:
        return {"ok": False, "error": "No data for that series."}
    return {
        "ok": True,
        "indicator": indicator,
        "nationality": nationality,
        "sex": sex,
        "points": df.to_dict(orient="records"),
    }


@app.get("/api/trend")
async def api_trend(indicator: str, nationality: str = "Saudi", sex: str = "Total"):
    return analyze_trend(DB_PATH, indicator, nationality, sex)


@app.get("/api/breakdown")
async def api_breakdown(indicator: str, dimension: str,
                       nationality: str = "Saudi", sex: str = "Total",
                       quarter: Optional[str] = None):
    return breakdown_by_dimension(DB_PATH, indicator, dimension, nationality, sex, quarter)


@app.get("/api/forecast")
async def api_forecast(indicator: str = "unemployment_rate",
                      nationality: str = "Saudi", sex: str = "Total",
                      horizon: int = 4):
    return forecast_indicator(DB_PATH, indicator, nationality, sex, horizon=horizon)


@app.get("/api/cohorts")
async def api_cohorts(indicator: str = "unemployment_rate"):
    """Standard 3-cohort comparison for the dashboard."""
    return compare_cohorts(DB_PATH, indicator, cohorts=[
        {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
        {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
        {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
        {"nationality": "Total", "sex": "Total", "label": "National Total"},
    ])


@app.get("/api/validate")
async def api_validate():
    return validate_dataset(DB_PATH)


@app.post("/api/report")
async def api_report(req: ReportRequest):
    """Generate the full quarterly briefing."""
    from agent import execute_tool
    result = execute_tool(ctx, "generate_report",
                          {"reference_quarter": req.reference_quarter} if req.reference_quarter
                          else {})
    if not result.get("ok"):
        raise HTTPException(status_code=500, detail=result.get("error", "Report failed"))
    return {
        "ok": True,
        "pdf_url": f"/api/download/{os.path.basename(result['pdf_path'])}",
        "markdown_url": f"/api/download/{os.path.basename(result['markdown_path'])}",
        "preview": result.get("markdown_preview", ""),
    }


@app.get("/api/download/{filename}")
async def download(filename: str):
    # Basic safety: only allow files within OUTPUT_DIR
    safe = os.path.normpath(filename).lstrip("/")
    if ".." in safe or "/" in safe:
        raise HTTPException(status_code=400, detail="Invalid filename.")
    path = os.path.join(OUTPUT_DIR, safe)
    if not os.path.isfile(path):
        raise HTTPException(status_code=404, detail="File not found.")
    media = "application/pdf" if safe.endswith(".pdf") else "text/markdown"
    return FileResponse(path, media_type=media, filename=safe)


@app.get("/api/summary")
async def api_summary():
    """Dashboard summary: KPIs, recent trend, forecast, cohort gap — one call."""
    kpis = {}
    try:
        ur = analyze_trend(DB_PATH, "unemployment_rate", "Saudi", "Total")
        emp = analyze_trend(DB_PATH, "employment_to_population", "Saudi", "Total")
        lfp = analyze_trend(DB_PATH, "labor_force_participation", "Saudi", "Total")
        cohort = compare_cohorts(DB_PATH, "unemployment_rate", cohorts=[
            {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
            {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
            {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
            {"nationality": "Total", "sex": "Total", "label": "National Total"},
        ])
        fc = forecast_indicator(DB_PATH, "unemployment_rate", "Saudi", "Total", horizon=4)
        val = validate_dataset(DB_PATH)
        return {
            "ok": True,
            "latest_quarter": ur.get("latest_quarter"),
            "kpis": {
                "saudi_unemployment": {
                    "value": ur.get("latest_value"),
                    "qoq": ur.get("qoq_change"),
                    "yoy": ur.get("yoy_change"),
                    "trend": ur.get("overall_trend"),
                    "series": ur.get("series"),
                },
                "saudi_emp_to_pop": {
                    "value": emp.get("latest_value"),
                    "qoq": emp.get("qoq_change"),
                    "yoy": emp.get("yoy_change"),
                    "series": emp.get("series"),
                },
                "saudi_lfp": {
                    "value": lfp.get("latest_value"),
                    "qoq": lfp.get("qoq_change"),
                    "yoy": lfp.get("yoy_change"),
                    "series": lfp.get("series"),
                },
            },
            "cohorts": cohort,
            "forecast": fc,
            "validation_flags": val.get("flags", []),
        }
    except Exception as e:
        log.exception("summary failed")
        return {"ok": False, "error": str(e)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)

# DEPLOYMENT.md — Production Deployment Guide

From a working local rebuild to a client-shareable URL on Google Cloud Run, hosted near Saudi Arabia.

> **Region note.** This guide uses `me-central1` (Doha, Qatar) since that's where your Cloud SQL instance currently lives. If you later need the workload in `me-central2` (Dammam, Saudi Arabia) for data-residency reasons, you'll need to re-provision Cloud SQL in that region — regions can't be moved.

> **Windows-first.** Commands shown in PowerShell. macOS/Linux equivalents follow when they differ.

---

## Table of contents

1. [Where you are now](#0-where-you-are-now)
2. [Phase 1 — Verify Cloud SQL is ready](#phase-1--verify-cloud-sql-is-ready)
3. [Phase 2 — Harden credentials before deploying](#phase-2--harden-credentials-before-deploying)
4. [Phase 3 — Store secrets in Secret Manager](#phase-3--store-secrets-in-secret-manager)
5. [Phase 4 — Create the Artifact Registry repository](#phase-4--create-the-artifact-registry-repository)
6. [Phase 5 — Build and push the Docker image](#phase-5--build-and-push-the-docker-image)
7. [Phase 6 — Deploy to Cloud Run](#phase-6--deploy-to-cloud-run)
8. [Phase 7 — Smoke test the production URL](#phase-7--smoke-test-the-production-url)
9. [Phase 8 — Custom domain (optional)](#phase-8--custom-domain-optional)
10. [Phase 9 — Share with the client](#phase-9--share-with-the-client)
11. [Day-2 operations](#day-2-operations)
12. [Troubleshooting](#troubleshooting)
13. [Quick-reference card](#quick-reference-card)

---

## 0. Where you are now

You've already done:

- ✅ Created the GCP project (`labor-agent-prod` or similar)
- ✅ Provisioned Cloud SQL PostgreSQL (`labor-agent-db` in `me-central1`)
- ✅ Installed `gcloud` CLI and authenticated
- ✅ Rebuilt the app for PostgreSQL (`labor_agent_pg`)
- ✅ Verified `bootstrap.py` ingests against Cloud SQL successfully via the proxy

Remaining: build a container, store secrets, deploy to Cloud Run, share the URL.

### Set these PowerShell variables once

Every command below uses these. Set them at the start of each PowerShell session:

```powershell
$env:PROJECT_ID    = "labor-agent-prod"          # YOUR project ID (replace)
$env:REGION        = "me-central1"               # Doha
$env:SQL_INSTANCE  = "labor-agent-db"
$env:SQL_DB_NAME   = "labor_agent"
$env:SQL_USER      = "labor_agent_user"
$env:SERVICE       = "labor-agent"
$env:REPO          = "labor-agent"
```

**macOS/Linux:**
```bash
export PROJECT_ID="labor-agent-prod"
export REGION="me-central1"
export SQL_INSTANCE="labor-agent-db"
export SQL_DB_NAME="labor_agent"
export SQL_USER="labor_agent_user"
export SERVICE="labor-agent"
export REPO="labor-agent"
```

Verify gcloud is set to the right project:

```powershell
gcloud config set project $env:PROJECT_ID
gcloud config set run/region $env:REGION
gcloud config list
```

---

## Phase 1 — Verify Cloud SQL is ready

Confirm the database is populated before you deploy. Cloud Run will read from this same database.

### Get the Cloud SQL connection name

```powershell
$env:SQL_CONNECTION = gcloud sql instances describe $env:SQL_INSTANCE --format="value(connectionName)"
echo $env:SQL_CONNECTION
# Should print something like: labor-agent-prod:me-central1:labor-agent-db
```

**Save this value.** You'll reference it many times.

**macOS/Linux:**
```bash
export SQL_CONNECTION=$(gcloud sql instances describe $SQL_INSTANCE --format="value(connectionName)")
echo $SQL_CONNECTION
```

### Verify the data via the proxy

If the Cloud SQL Proxy isn't already running, start it in a separate terminal:

```powershell
./cloud-sql-proxy $env:SQL_CONNECTION --port=5432
```

In your main terminal, point at it and check the row counts:

```powershell
$env:DATABASE_URL = "postgresql://$($env:SQL_USER):YOUR_PASSWORD@localhost:5432/$($env:SQL_DB_NAME)"

python -c "from db import connect; con = connect(); print('labor_facts:', con.execute('SELECT COUNT(*) FROM labor_facts').fetchone()[0]); print('register_facts:', con.execute('SELECT COUNT(*) FROM register_facts').fetchone()[0]); con.close()"
```

Expected output:
```
labor_facts: 5109
register_facts: 99
```

If you see zeros or errors, run `python bootstrap.py` first to load the data, then verify.

Once you've confirmed the data is in Cloud SQL, **stop the proxy** (Ctrl+C in its terminal). Cloud Run will reach Cloud SQL directly via the built-in connector, not through the proxy.

---

## Phase 2 — Harden credentials before deploying

The app currently has demo credentials (`admin`/`admin`, `analyst`/`analyst`). **Change these before sharing with the client.**

### Generate stronger passwords

```powershell
python -c "import secrets; print('admin password:', secrets.token_urlsafe(12)); print('analyst password:', secrets.token_urlsafe(12))"
```

Save both passwords — you'll use them for client demos.

### Update the credentials in `app.py`

Open `app.py`, find the `USERS` dictionary (near line 100), and update the passwords:

```python
USERS: Dict[str, Dict[str, str]] = {
    "admin": {
        "password_hash": _hash_password("YOUR_NEW_ADMIN_PASSWORD"),
        "display_name": "Admin User",
        "role": "Administrator",
    },
    "analyst": {
        "password_hash": _hash_password("YOUR_NEW_ANALYST_PASSWORD"),
        "display_name": "Labor Analyst",
        "role": "Analyst",
    },
}
```

Save the file. These will be baked into the Docker image in the next phase.

> **Better long-term:** Replace this hardcoded dict with proper user management (Google IAP, Okta, or PwC SSO). For an MVP client demo, hardcoded credentials are acceptable as long as they're not `admin/admin`.

---

## Phase 3 — Store secrets in Secret Manager

Cloud Run will inject these as environment variables at runtime — they never appear in code or env files.

### Enable Secret Manager API (one-time)

```powershell
gcloud services enable secretmanager.googleapis.com
```

### Create the three secrets

**1. OpenAI API key:**

```powershell
"sk-your-actual-openai-api-key" | gcloud secrets create openai-api-key --data-file=-
```

If the secret already exists from earlier attempts:
```powershell
"sk-your-actual-openai-api-key" | gcloud secrets versions add openai-api-key --data-file=-
```

**2. Database URL (Cloud Run uses a Unix socket — different format from local):**

```powershell
"postgresql://$($env:SQL_USER):YOUR_PASSWORD@/$($env:SQL_DB_NAME)?host=/cloudsql/$($env:SQL_CONNECTION)" | gcloud secrets create database-url --data-file=-
```

Note the format: no `localhost`, no port. The `host=/cloudsql/...` parameter tells psycopg2 to use the Unix socket that Cloud Run mounts.

**3. Session secret (signs auth cookies):**

```powershell
python -c "import secrets; print(secrets.token_urlsafe(32))" | gcloud secrets create session-secret --data-file=-
```

### macOS/Linux equivalents

```bash
echo -n "sk-your-openai-key" | gcloud secrets create openai-api-key --data-file=-

echo -n "postgresql://${SQL_USER}:YOUR_PASSWORD@/${SQL_DB_NAME}?host=/cloudsql/${SQL_CONNECTION}" | gcloud secrets create database-url --data-file=-

python -c "import secrets; print(secrets.token_urlsafe(32))" | gcloud secrets create session-secret --data-file=-
```

### Verify all three exist

```powershell
gcloud secrets list
```

You should see `openai-api-key`, `database-url`, `session-secret`.

### Grant Cloud Run permission to read them

```powershell
$env:PROJECT_NUMBER = gcloud projects describe $env:PROJECT_ID --format="value(projectNumber)"
$env:SERVICE_ACCOUNT = "$($env:PROJECT_NUMBER)-compute@developer.gserviceaccount.com"

@("openai-api-key", "database-url", "session-secret") | ForEach-Object {
    gcloud secrets add-iam-policy-binding $_ --member="serviceAccount:$($env:SERVICE_ACCOUNT)" --role="roles/secretmanager.secretAccessor"
}
```

**macOS/Linux:**
```bash
PROJECT_NUMBER=$(gcloud projects describe $PROJECT_ID --format="value(projectNumber)")
SERVICE_ACCOUNT="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"

for SECRET in openai-api-key database-url session-secret; do
  gcloud secrets add-iam-policy-binding $SECRET \
    --member="serviceAccount:${SERVICE_ACCOUNT}" \
    --role="roles/secretmanager.secretAccessor"
done
```

---

## Phase 4 — Create the Artifact Registry repository

This is where your Docker images live (private to your project).

### Enable Artifact Registry API (one-time)

```powershell
gcloud services enable artifactregistry.googleapis.com
```

### Create the repository

```powershell
gcloud artifacts repositories create $env:REPO `
    --repository-format=docker `
    --location=$env:REGION `
    --description="Labor Market Analysis Agent images"
```

**macOS/Linux:**
```bash
gcloud artifacts repositories create $REPO \
    --repository-format=docker \
    --location=$REGION \
    --description="Labor Market Analysis Agent images"
```

If it errors with "already exists" that's fine — you can skip.

### Configure docker to authenticate to it

```powershell
gcloud auth configure-docker "$($env:REGION)-docker.pkg.dev"
```

**macOS/Linux:**
```bash
gcloud auth configure-docker "${REGION}-docker.pkg.dev"
```

---

## Phase 5 — Build and push the Docker image

### Enable Cloud Build API (one-time)

```powershell
gcloud services enable cloudbuild.googleapis.com
```

### Build remotely (recommended — fast, no local Docker needed)

From inside your project folder (`labor_agent_pg`):

```powershell
gcloud builds submit --tag "$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):v1" .
```

**macOS/Linux:**
```bash
gcloud builds submit --tag "${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/${SERVICE}:v1" .
```

This will:
1. Upload your source code to Cloud Build
2. Build the Docker image in GCP infrastructure
3. Push it to Artifact Registry

Expect 5–10 minutes the first time, 2–3 minutes for incremental builds.

> **Tip:** for subsequent builds, increment the tag: `v2`, `v3`, etc. Don't use `latest` for production deployments — explicit version tags make rollback trivial.

### Alternative: build locally (if Cloud Build is slow or unavailable)

```powershell
docker build -t "$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):v1" .
docker push "$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):v1"
```

This requires Docker Desktop running.

---

## Phase 6 — Deploy to Cloud Run

### Enable Cloud Run API (one-time)

```powershell
gcloud services enable run.googleapis.com
```

### Deploy

```powershell
gcloud run deploy $env:SERVICE `
    --image="$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):v1" `
    --region=$env:REGION `
    --platform=managed `
    --allow-unauthenticated `
    --port=8080 `
    --memory=2Gi `
    --cpu=1 `
    --min-instances=1 `
    --max-instances=3 `
    --timeout=300 `
    --add-cloudsql-instances=$env:SQL_CONNECTION `
    --set-secrets="OPENAI_API_KEY=openai-api-key:latest,DATABASE_URL=database-url:latest,SESSION_SECRET=session-secret:latest" `
    --set-env-vars="OPENAI_MODEL=gpt-4o-mini,OPENAI_BASE_URL=https://api.openai.com/v1"
```

**macOS/Linux:**
```bash
gcloud run deploy $SERVICE \
    --image="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/${SERVICE}:v1" \
    --region=$REGION \
    --platform=managed \
    --allow-unauthenticated \
    --port=8080 \
    --memory=2Gi \
    --cpu=1 \
    --min-instances=1 \
    --max-instances=3 \
    --timeout=300 \
    --add-cloudsql-instances=$SQL_CONNECTION \
    --set-secrets="OPENAI_API_KEY=openai-api-key:latest,DATABASE_URL=database-url:latest,SESSION_SECRET=session-secret:latest" \
    --set-env-vars="OPENAI_MODEL=gpt-4o-mini,OPENAI_BASE_URL=https://api.openai.com/v1"
```

### What each flag does

| Flag | Why |
|---|---|
| `--allow-unauthenticated` | Public URL — your app handles auth via the login page |
| `--port=8080` | Cloud Run's required listening port |
| `--memory=2Gi` | Enough for pandas + RAG + LLM client |
| `--min-instances=1` | Keep one warm so the client doesn't hit cold-start latency |
| `--max-instances=3` | Cap auto-scaling (cost control) |
| `--timeout=300` | 5 min — report generation can take 30+ seconds |
| `--add-cloudsql-instances` | Mounts Cloud SQL at `/cloudsql/<connection>` inside the container |
| `--set-secrets` | Injects Secret Manager values as env vars at startup |

### Get the service URL

```powershell
$env:SERVICE_URL = gcloud run services describe $env:SERVICE --region=$env:REGION --format="value(status.url)"
echo $env:SERVICE_URL
# https://labor-agent-XXXXXX-XX.a.run.app
```

**Open this URL in your browser.** You should see the login page. Sign in with your hardened admin credentials from Phase 2.

🎉 **The app is live.**

---

## Phase 7 — Smoke test the production URL

Run through these in the browser:

- [ ] Login page loads
- [ ] Can sign in with admin credentials
- [ ] Dashboard shows the 6 MoHRSD KPIs with values (3.53%, 7.24%, 67.43%, 49.52%, 42.37%, 9.57%)
- [ ] Trend chart renders
- [ ] Cohort comparison chart renders
- [ ] Forecast chart renders
- [ ] Chat: ask "What's the Saudi unemployment trend?" — should respond in <15 seconds
- [ ] Generate Briefing button produces a PDF you can download
- [ ] Upload a new file (try the bundled GASTAT xlsx) — should ingest in <10 seconds
- [ ] Sign out works, redirects to login

### If anything fails

Check the logs:

```powershell
gcloud run services logs read $env:SERVICE --region=$env:REGION --limit=100
```

Or tail them live:
```powershell
gcloud beta run services logs tail $env:SERVICE --region=$env:REGION
```

See [Troubleshooting](#troubleshooting) for common errors.

---

## Phase 8 — Custom domain (optional)

The default Cloud Run URL works but is ugly: `https://labor-agent-abc123-uc.a.run.app`. For client demos, a custom domain looks more professional.

### Skip this phase if

- This is an internal-only demo
- You're sharing the URL only with the AI Director and the immediate team
- You don't have a domain to use

### Option A — use a PwC-owned domain

Ask PwC IT to allocate a subdomain (e.g., `labor.pwc-saudi.com` or `agent.pwc.com.sa`). They'll need to add DNS records pointing to your Cloud Run service.

### Option B — buy a domain

Any registrar works (Namecheap, GoDaddy, Google Domains, IONOS). Get one that suits the brand.

### Verify domain ownership

```powershell
gcloud domains verify your-domain.com
```

Follow the on-screen prompts (usually a DNS TXT record you add at your registrar).

### Map the domain to Cloud Run

```powershell
gcloud beta run domain-mappings create `
    --service=$env:SERVICE `
    --domain=labor.your-domain.com `
    --region=$env:REGION
```

GCP returns DNS records (A/AAAA or CNAME) for you to add at your DNS provider.

### Wait for SSL provisioning

Once DNS propagates (5–30 minutes), GCP automatically provisions a managed Let's Encrypt SSL certificate. You'll get HTTPS at `https://labor.your-domain.com` within an hour.

---

## Phase 9 — Share with the client

### What to send

**The URL** — either the Cloud Run default or your custom domain.

**The credentials** — admin username + password from Phase 2.

### Send them separately

For demo security, send the URL by email but credentials by a different channel (Slack, SMS, in-person, a separate email). Never the same message — if either channel is compromised, the other still protects you.

### Email template

> Subject: **Labor Market Analysis Agent — Demo access**
>
> Hi [Client name],
>
> The AI-augmented labor market agent is now live. You can access it here: **https://labor.your-domain.com**
>
> The dashboard surfaces the six MoHRSD quarterly KPIs the moment you sign in, and the chat panel lets you ask the agent natural-language questions about trends, cohort comparisons, forecasts, and the prior-studies knowledge base. You can also generate the full quarterly briefing as a PDF.
>
> Your sign-in credentials will follow in a separate message.
>
> Best, [Your name]

---

## Day-2 operations

### Redeploy after a code change

```powershell
# Bump the version tag every time
gcloud builds submit --tag "$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):v2" .

gcloud run deploy $env:SERVICE `
    --image="$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):v2" `
    --region=$env:REGION
```

Cloud Run does a zero-downtime rollover — the old revision keeps serving traffic until the new one passes health checks, then routes flips.

### Rollback to a previous revision

```powershell
# List revisions
gcloud run revisions list --service=$env:SERVICE --region=$env:REGION

# Pin traffic to a specific revision
gcloud run services update-traffic $env:SERVICE `
    --region=$env:REGION `
    --to-revisions=labor-agent-00003-xyz=100
```

### Tail logs in real time

```powershell
gcloud beta run services logs tail $env:SERVICE --region=$env:REGION
```

### Rotate a secret (e.g., new OpenAI key)

```powershell
"sk-new-key" | gcloud secrets versions add openai-api-key --data-file=-

# Cloud Run picks up the new version on the next deploy
gcloud run services update $env:SERVICE --region=$env:REGION
```

### Suspend the service (stop serving traffic — costs drop to near-zero)

```powershell
gcloud run services update $env:SERVICE --region=$env:REGION --no-traffic
```

Resume:
```powershell
gcloud run services update $env:SERVICE --region=$env:REGION --traffic=100
```

### Database backups

Cloud SQL auto-backs up daily. To take a manual snapshot before a risky change:

```powershell
gcloud sql backups create --instance=$env:SQL_INSTANCE
```

### Set up a billing alert (do this once)

In the GCP Console → **Billing** → **Budgets & alerts** → **Create budget**:
- Amount: $100/month
- Alert at 50%, 90%, 100%

This emails you before surprises.

### Expected monthly cost

| Service | Monthly |
|---|---|
| Cloud Run (1 vCPU, 2GB, min=1) | $25–40 |
| Cloud SQL `db-f1-micro` | $10–15 |
| Artifact Registry storage | ~$1 |
| Secret Manager | ~$0.30 |
| Egress traffic | $1–5 |
| **Total** | **~$40–65** |

---

## Troubleshooting

### "Permission denied" on Secret Manager at startup

Re-run the IAM grants in Phase 3:

```powershell
$env:PROJECT_NUMBER = gcloud projects describe $env:PROJECT_ID --format="value(projectNumber)"
$env:SERVICE_ACCOUNT = "$($env:PROJECT_NUMBER)-compute@developer.gserviceaccount.com"
@("openai-api-key", "database-url", "session-secret") | ForEach-Object {
    gcloud secrets add-iam-policy-binding $_ --member="serviceAccount:$($env:SERVICE_ACCOUNT)" --role="roles/secretmanager.secretAccessor"
}
```

### Container starts but immediately crashes

Pull the logs:

```powershell
gcloud run services logs read $env:SERVICE --region=$env:REGION --limit=100
```

Most likely culprits:

| Symptom | Cause | Fix |
|---|---|---|
| `RuntimeError: DATABASE_URL is not set` | Secret not bound | Verify `--set-secrets` flag in deploy command |
| `Connection refused on localhost:5432` | Using local DATABASE_URL format in prod | Re-check the secret value — should use `host=/cloudsql/...` |
| `no such file: /cloudsql/...` | `--add-cloudsql-instances` missing | Re-run deploy with that flag |
| `ModuleNotFoundError: psycopg2` | Image build issue | Rebuild — `psycopg2-binary` is in requirements.txt |

### Slow first request after idle

You set `--min-instances=1` so a container should stay warm. If you see 10+ second first-request lag, confirm:

```powershell
gcloud run services describe $env:SERVICE --region=$env:REGION --format="value(spec.template.spec.containerConcurrency,spec.template.metadata.annotations)"
```

### Client says "the URL doesn't load"

1. Confirm the service is healthy: `gcloud run services describe $env:SERVICE --region=$env:REGION`
2. Their network may block traffic to GCP-hosted apps in certain regions — uncommon but happens with some corporate firewalls
3. If using a custom domain, confirm DNS has propagated: `nslookup labor.your-domain.com`

### Costs are higher than expected

Check the breakdown in **Billing → Reports**. Common surprises:
- Egress traffic (if many users download large reports)
- Cloud SQL storage (default 10GB SSD)
- Cloud Run if you removed `--max-instances` and traffic spiked

---

## Quick-reference card

Save this for everyday use. All commands assume the env vars at the top of this guide are set.

```powershell
# View service status
gcloud run services describe $env:SERVICE --region=$env:REGION

# Get the live URL
gcloud run services describe $env:SERVICE --region=$env:REGION --format="value(status.url)"

# View logs (latest 50)
gcloud run services logs read $env:SERVICE --region=$env:REGION --limit=50

# Tail logs live
gcloud beta run services logs tail $env:SERVICE --region=$env:REGION

# Redeploy
gcloud builds submit --tag "$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):vN" .
gcloud run deploy $env:SERVICE --image="$($env:REGION)-docker.pkg.dev/$($env:PROJECT_ID)/$($env:REPO)/$($env:SERVICE):vN" --region=$env:REGION

# List revisions
gcloud run revisions list --service=$env:SERVICE --region=$env:REGION

# Pin traffic to a revision (rollback)
gcloud run services update-traffic $env:SERVICE --region=$env:REGION --to-revisions=labor-agent-00003-xyz=100

# Update one env var without a rebuild
gcloud run services update $env:SERVICE --region=$env:REGION --set-env-vars="LOG_LEVEL=DEBUG"

# Rotate a secret
"new-value" | gcloud secrets versions add openai-api-key --data-file=-
gcloud run services update $env:SERVICE --region=$env:REGION   # picks up new version

# Suspend / resume the service
gcloud run services update $env:SERVICE --region=$env:REGION --no-traffic
gcloud run services update $env:SERVICE --region=$env:REGION --traffic=100

# Connect to Cloud SQL locally for ad-hoc queries
./cloud-sql-proxy $env:SQL_CONNECTION --port=5432
# In another terminal:
$env:DATABASE_URL = "postgresql://$($env:SQL_USER):PASSWORD@localhost:5432/$($env:SQL_DB_NAME)"
python -c "from db import connect; c = connect(); print(c.execute('SELECT COUNT(*) FROM labor_facts').fetchone()); c.close()"
```

---

**Version:** v1.0 · **Region:** `me-central1` (Doha) · **Last updated:** {{ today }}

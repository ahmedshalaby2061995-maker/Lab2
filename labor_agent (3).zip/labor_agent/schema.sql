-- ============================================================================
-- Labor Market Analysis Agent — PostgreSQL schema
-- ============================================================================
-- Apply with:
--   python db.py init
-- Or manually:
--   psql $DATABASE_URL -f schema.sql
--
-- Idempotent: uses CREATE TABLE IF NOT EXISTS throughout. Safe to re-run.


-- ── GASTAT Labor Force Survey facts (the main long-format table) ─────
-- One row per (quarter, indicator, dimension, category, nationality, sex).
-- Holds ~5,109 rows for a typical 20-quarter seed.

CREATE TABLE IF NOT EXISTS labor_facts (
    quarter       TEXT NOT NULL,
    table_id      TEXT NOT NULL,
    indicator     TEXT NOT NULL,
    dimension     TEXT NOT NULL,
    category      TEXT NOT NULL,
    nationality   TEXT NOT NULL,
    sex           TEXT NOT NULL,
    value         DOUBLE PRECISION NOT NULL,
    source_file   TEXT NOT NULL,
    ingested_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (quarter, table_id, indicator, dimension, category, nationality, sex)
);

CREATE INDEX IF NOT EXISTS idx_labor_facts_quarter   ON labor_facts(quarter);
CREATE INDEX IF NOT EXISTS idx_labor_facts_indicator ON labor_facts(indicator);
CREATE INDEX IF NOT EXISTS idx_labor_facts_dimension ON labor_facts(dimension);
CREATE INDEX IF NOT EXISTS idx_labor_facts_nat_sex   ON labor_facts(nationality, sex);


-- ── Register-based Labor Market Statistics (Table 3-5) ───────────────
-- One row per (quarter, occupation, nationality, sex). Source for KPIs 5 & 6.

CREATE TABLE IF NOT EXISTS register_facts (
    quarter       TEXT NOT NULL,
    occupation    TEXT NOT NULL,
    nationality   TEXT NOT NULL,
    sex           TEXT NOT NULL,
    count         INTEGER NOT NULL,
    source_file   TEXT NOT NULL,
    ingested_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (quarter, occupation, nationality, sex)
);

CREATE INDEX IF NOT EXISTS idx_register_facts_quarter ON register_facts(quarter);


-- ── Ingestion audit log ──────────────────────────────────────────────
-- Every successful xlsx ingestion writes one row here for traceability.

CREATE TABLE IF NOT EXISTS ingestion_log (
    id                BIGSERIAL PRIMARY KEY,
    source_file       TEXT NOT NULL,
    file_hash         TEXT,
    snapshot_quarter  TEXT,
    rows_ingested     INTEGER NOT NULL DEFAULT 0,
    validation_flags  TEXT,
    ingested_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ingestion_log_at ON ingestion_log(ingested_at DESC);


-- ── Knowledge Management — uploaded reference documents ──────────────
-- Replaces the old separate SQLite km.db. Same schema, now in PostgreSQL.

CREATE TABLE IF NOT EXISTS km_documents (
    id            BIGSERIAL PRIMARY KEY,
    filename      TEXT NOT NULL,
    stored_name   TEXT NOT NULL UNIQUE,
    file_type     TEXT NOT NULL,
    size_bytes    BIGINT NOT NULL,
    word_count    INTEGER,
    page_count    INTEGER,
    sha256        TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'indexed',
    uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    uploaded_by   TEXT
);

CREATE INDEX IF NOT EXISTS idx_km_documents_uploaded_at ON km_documents(uploaded_at DESC);
CREATE INDEX IF NOT EXISTS idx_km_documents_sha256      ON km_documents(sha256);


-- ── Auth sessions ────────────────────────────────────────────────────
-- Database-backed sessions so login survives container restarts and
-- works across multiple Cloud Run instances. Replaces the in-memory dict.

CREATE TABLE IF NOT EXISTS sessions (
    token       TEXT PRIMARY KEY,
    username    TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at  TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

# MVP UI Upgrade — Chat & Dashboard as Separate Services

## What changed

This patch redesigns the frontend to fix the layout/zoom issues and elevate the sophistication level. Only ONE file needs to be replaced.

### Issues fixed
1. **Chat box zoom problem** — chat is now full-width (max 820px centered) instead of cramped in a narrow side column.
2. **Empty Dashboard view** — Dashboard is now a full standalone service that loads correctly when selected.
3. **Removed "Both" view** — Chat and Dashboard are now two distinct services. The sidebar drives navigation between them.

### Design improvements
- **Editorial typography** — Instrument Serif for headlines (italic emphasis on key phrases), Geist sans for UI, Geist Mono for labels.
- **Sidebar nav** is now the primary navigation — clicking *Agent Chat* or *Analytics Dashboard* swaps the entire main content area.
- **Hero chat experience** — generous welcome state with quick-prompt cards (categorized: Trend Analysis · Cohort Comparison · Forecasting · Reporting), a proper composer at the bottom with Send button, file upload, and keyboard hints.
- **Dashboard view** loads lazily on first visit and persists across sessions.
- **Refined message rendering** — assistant replies use serif type for editorial feel, user messages use clean sans.

## Apply the patch

Replace ONE file:

```
mvp_patch/templates/app.html  →  labor_agent/templates/app.html
```

That's it. Restart uvicorn:

```powershell
.\.venv\Scripts\uvicorn app:app --host 0.0.0.0 --port 8000
```

Open http://localhost:8000 → you'll land on the **Chat** service by default. Click **Analytics Dashboard** in the sidebar to switch.

## Notes

- All your existing `app.py`, `login.html`, backend endpoints, and tools remain unchanged.
- Your saved view preference and dashboard card visibility settings persist in localStorage.
- The "Reports" link in the sidebar takes users to the dashboard and scrolls to the report-generation card.

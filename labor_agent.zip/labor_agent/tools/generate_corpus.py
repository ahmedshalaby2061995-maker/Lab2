"""
Generate synthetic previous economic studies & reports for the RAG corpus.
Each doc is a realistic-looking labor market analysis briefing. Mix of .txt and
.pdf files so we exercise both readers. These simulate 'previous economic
studies' the team would normally reference.
"""
import os
from pathlib import Path

DOCS = {
    "GASTAT_Methodology_Notes_LFS_2024.txt": """
GENERAL AUTHORITY FOR STATISTICS (GASTAT) — KINGDOM OF SAUDI ARABIA
Labor Force Survey (LFS) Methodology — Updated 2024
====================================================

Background
----------
GASTAT conducts the Labor Force Survey on a quarterly basis to produce official
statistics on unemployment, employment, and labor force participation across
the Saudi population aged 15 and above. The survey follows International Labor
Organization (ILO) standards.

Core Definitions
----------------
Employed: Persons aged 15+ who, during the reference week, worked at least one
hour for pay, profit, or family gain, or were temporarily absent from a job.

Unemployed: Persons aged 15+ who (a) did not work during the reference week,
(b) were available to start work, and (c) actively searched for work during
the previous four weeks.

Labor force: The sum of employed and unemployed persons.

Labor force participation rate (LFP): Labor force as a percentage of working-
age population (15+).

Employment-to-population ratio: Employed persons as a percentage of working-age
population.

Unemployment rate: Unemployed persons as a percentage of the labor force.

Sample and Coverage
-------------------
The LFS sample covers all 13 administrative regions and is designed to produce
estimates at the national level by nationality (Saudi / Non-Saudi), sex, age
group, and educational attainment. Sample size is approximately 33,000
households per quarter.

Seasonality
-----------
Historical data indicate that labor market indicators exhibit mild seasonality.
Unemployment rates typically rise slightly in Q3 (summer) and decline in Q1
following graduation cycles. Analysts should use seasonally-adjusted series
when comparing across quarters, or rely on year-over-year (YoY) comparisons.

Revisions
---------
Estimates for the most recent quarter are preliminary. Revisions of up to 0.3
percentage points are common in subsequent releases as more household responses
are processed. Final revised figures are published four quarters after initial
release.

Key Policy Context
------------------
Saudi Vision 2030 targets an overall unemployment rate of 7% by 2030 and
female labor force participation rate of 30% (both targets met ahead of
schedule in 2023-2024). Current policy focus is on youth employment,
private sector localization (Saudization), and female participation in
high-value sectors.
""",

    "Saudi_Labor_Market_Annual_Review_2023.txt": """
SAUDI ARABIA LABOR MARKET — ANNUAL REVIEW 2023
==============================================

Executive Summary
-----------------
2023 marked a transformative year for the Saudi labor market. The national
unemployment rate fell to 4.4% in Q4 2023 — the lowest on record — while the
Saudi unemployment rate fell from 8.0% at the start of the year to 7.8% by
year-end. Female participation continued its rapid expansion, reaching 36% in
Q4 2023, well ahead of the Vision 2030 target of 30%.

Key Drivers
-----------
1. Private sector expansion: The private sector added approximately 450,000
   Saudi jobs across 2023, driven by growth in wholesale/retail, construction,
   professional services, and tourism.

2. Saudization policies: Nitaqat program reforms and new quotas in professional
   services (including accounting, engineering, and HR) created meaningful
   demand for Saudi workers.

3. Female labor supply surge: Legal reforms over the previous decade and
   expanded childcare infrastructure continued to draw women into the labor
   force. Notably, Saudi female unemployment fell from 13.8% in Q4 2022 to
   11.6% in Q4 2023.

4. Mega-project demand: NEOM, Red Sea Project, Qiddiya, and Diriyah began
   significant hiring cycles, absorbing technical and skilled labor.

Concerns and Risks
------------------
- Youth unemployment (ages 15-24) remains structurally elevated at 17-20%,
  roughly 3x the overall rate. The gap between educational output and labor
  market demand persists, especially in humanities and theoretical science
  graduates.

- Regional disparities remain wide. Unemployment rates in southern and
  northern regions (Jazan, Aseer, Al-Jouf, Northern Borders) are consistently
  2-4 percentage points higher than Riyadh and the Eastern Province.

- Saudi female unemployment rate (11.6%) remains nearly 3x that of Saudi
  males (4.3%), reflecting both supply-side expansion and demand-side
  bottlenecks in sectors welcoming female participation.

Outlook for 2024
----------------
Baseline projections anticipate the overall unemployment rate stabilizing
around 4.5-5.0% through 2024, with Saudi-specific unemployment continuing to
fall below 7% by year-end. Risks to the outlook include global demand
slowdown affecting oil-linked hiring and potential softening in construction
as mega-project phases transition from build-out to operations.
""",

    "Vision_2030_Labor_Market_Policy_Brief.txt": """
VISION 2030 — LABOR MARKET OBJECTIVES AND PROGRESS
===================================================

Original 2016 Targets
---------------------
Saudi Vision 2030, launched in April 2016, set three headline labor market
targets:
  1. Reduce the overall unemployment rate from 11.6% to 7% by 2030.
  2. Raise female labor force participation from 17% to 30% by 2030.
  3. Raise SME contribution to GDP from 20% to 35%.

Progress as of 2024
-------------------
The overall unemployment target was achieved in 2023 (4.4%), seven years
ahead of schedule. Female LFP reached 30% in 2022 and 36% in 2023, also far
ahead of schedule. These achievements prompted revised, more ambitious targets
announced in late 2024:
  - Overall unemployment: maintain below 5%.
  - Female LFP: reach 40% by 2030.
  - Saudi unemployment: below 5% by 2030.
  - NEET (Not in Employment, Education, or Training) rate for ages 15-29:
    below 15%.

Flagship Programs
-----------------
1. Doroob (skills platform): Over 2 million beneficiaries since 2017; training
   in digital, technical, and soft skills.

2. Nitaqat (Saudization): Firm-level quota system with escalating incentives
   and sanctions. Expanded to new professions in 2022-2024.

3. Hadaf (Human Resources Development Fund): Wage subsidies and training
   support for private-sector Saudi employment.

4. Qiwa platform: Digital labor-market infrastructure for contracts, visa
   transfers, and compliance.

5. Tawteen (localization in strategic sectors): Enforces Saudi employment
   quotas in retail, communications, financial services, accounting, law, and
   other professional sectors.

Implementation Lessons
----------------------
- Demand-side interventions (wage subsidies, quotas) work best when paired
  with supply-side interventions (training, certification) to prevent
  displacement of non-Saudi workers without matching skills on the Saudi side.

- Female participation gains were strongest in retail, hospitality, and
  public administration — indicating that sectoral openness is a stronger
  driver than aggregate labor demand.

- Youth unemployment remains the most resistant indicator, requiring
  earlier-stage interventions (secondary education curriculum alignment,
  apprenticeship scaffolding).
""",

    "Regional_Disparities_Study_2022.txt": """
REGIONAL LABOR MARKET DISPARITIES IN SAUDI ARABIA — 2022 STUDY
==============================================================

Introduction
------------
This study analyzes unemployment and participation patterns across the 13
administrative regions of the Kingdom, drawing on GASTAT LFS data from
2017-2022. We find persistent gaps between the four most populous regions
(Riyadh, Makkah, Eastern Province, Madinah) and the peripheral regions
(Jazan, Aseer, Najran, Al-Baha, Al-Jouf, Northern Borders, Tabuk).

Key Findings
------------
1. Unemployment rates in peripheral regions average 2-4 percentage points
   higher than in core regions, with Jazan consistently the highest (often
   exceeding 10% for Saudi nationals) and Riyadh the lowest (typically
   below 6% for Saudis).

2. Female unemployment rates in peripheral regions can exceed 15%,
   driven by limited sector diversity and lower private-sector density.

3. LFP rates for Saudi females are highest in Riyadh (42-45%), followed by
   the Eastern Province and Makkah, reflecting concentration of professional
   services, healthcare, and education.

4. Non-Saudi labor is heavily concentrated in the Eastern Province, Riyadh,
   and Makkah, with construction, mega-project, and Hajj-related employment
   dominating.

Policy Implications
-------------------
- Targeted regional investment programs (e.g. Tabuk Development Authority,
  NEOM, Red Sea Project) have begun narrowing some gaps but take 3-5 years
  to translate into measurable labor market outcomes.

- Women-focused employment programs in peripheral regions should prioritize
  telework, healthcare, and retail/hospitality pipelines.

- Secondary education quality and digital infrastructure in peripheral
  regions remain key supply-side constraints.
""",

    "Youth_Employment_Analysis_Q2_2024.txt": """
YOUTH EMPLOYMENT IN SAUDI ARABIA — Q2 2024 ANALYSIS
====================================================

Summary
-------
Youth (ages 15-24) represents one of the most challenging segments of the
Saudi labor market. This brief summarizes the structural drivers and recent
trends.

Key Statistics (as of Q2 2024)
------------------------------
- Saudi youth unemployment rate: approximately 18% overall.
- Saudi female youth unemployment: approximately 23%.
- Saudi male youth unemployment: approximately 13%.
- Youth labor force participation: approximately 25%.
- Youth NEET rate: approximately 22%.

Structural Drivers
------------------
1. Education-labor mismatch: A large share of university graduates hold
   degrees in humanities, Islamic studies, and education — fields with
   limited private-sector absorption. STEM and technical/vocational
   graduates have significantly better placement rates.

2. Reservation wage gap: Saudi youth often enter the labor market with
   expectations set by public-sector wage norms, creating friction with
   lower private-sector entry wages.

3. Work-experience barrier: Private employers prefer candidates with 1-2
   years of experience. Without apprenticeship structures or first-job
   programs at scale, new entrants face a chicken-and-egg barrier.

4. Sector preferences: Youth express strong preference for government, oil
   & gas, and banking roles. The fastest-growing sectors (retail, hospitality,
   construction services) have lower preference.

Interventions That Appear to Work
---------------------------------
- Paid internship/apprenticeship programs (Tamheer): measurable placement
  uplift of 20-30% for participants.
- Wage subsidy schemes (Hadaf): effective but expensive per placement; best
  targeted at first-job candidates rather than ongoing subsidies.
- Career guidance in secondary school: early evidence of 5-8 percentage
  point improvement in relevant-field university enrollment.

Recommendations
---------------
- Double down on Tamheer and expand to medium firms (currently concentrated
  in large firms).
- Launch curriculum reform for high schools to align with sectoral demand
  projections.
- Create regional industry-education advisory councils.
""",

    "Female_LFP_Saudi_Arabia_Study.txt": """
DRIVERS OF FEMALE LABOR FORCE PARTICIPATION GROWTH IN SAUDI ARABIA
===================================================================

Overview
--------
Saudi Arabia has experienced one of the fastest female labor force
participation increases documented in recent decades — from 17% in 2016 to
36% in 2023 — representing approximately 2.7 million additional women
entering the labor force.

Contributing Factors
--------------------
1. Legal reforms (2017-2021): Easier access to driving, travel, and civil
   documentation; workplace protections; reform of guardianship rules.

2. Sectoral openings: Retail (women cashiers from 2011, expanded in 2016),
   hospitality, entertainment, defense/security, ride-hailing, delivery.

3. Professional services expansion: Accounting, law, engineering increasingly
   female-friendly; healthcare and education remain majority-female in
   staff share.

4. Childcare expansion: Government and private nurseries; employer-linked
   childcare subsidies for female employees.

5. Social attitudes: Rapid normalization of female employment in urban
   centers; generational shift in expectations.

6. Digital/remote work: Post-COVID acceleration of remote and hybrid roles
   has particularly benefited women in peripheral regions.

Remaining Challenges
--------------------
- Saudi female unemployment (10-12%) remains elevated, indicating that labor
  supply growth has outpaced demand absorption.

- Representation at senior/executive levels remains low (below 10% on
  Tadawul-listed company boards).

- Wage gaps persist — Saudi female monthly wages average roughly 70-75% of
  Saudi male wages in comparable roles.

- Sectoral concentration: Education, healthcare, and retail account for over
  60% of Saudi female employment. Diversification is a policy priority.

Outlook
-------
Continued growth to 40%+ LFP by 2030 is plausible but not automatic. Demand-
side policy (targeted Saudization in high-growth sectors) and continued
infrastructure investment (childcare, transit, flexible work) will be
critical.
""",

    "Sectoral_Composition_Report_2023.txt": """
SECTORAL COMPOSITION OF SAUDI EMPLOYMENT — 2023 SNAPSHOT
========================================================

Overall Distribution
--------------------
Wholesale & retail trade is the largest sector by employment, accounting for
approximately 20% of total employed. Construction follows at roughly 18%,
then manufacturing at 10%, public administration at 9%, and accommodation &
food service at 7%.

Saudi-Specific Distribution
---------------------------
Saudi employment is skewed toward:
  - Public administration (~25%)
  - Education (~15%)
  - Healthcare & social work (~10%)
  - Wholesale & retail (~8%)
  - Financial/insurance activities (~5%)

Saudi men are concentrated in public administration, security/defense, and
professional services. Saudi women are concentrated in education, healthcare,
and increasingly retail.

Non-Saudi Distribution
----------------------
Non-Saudi workers dominate:
  - Construction (~30% of non-Saudi employment)
  - Wholesale & retail (~25%)
  - Accommodation & food service (~10%)
  - Domestic/household services (~10%)
  - Manufacturing (~10%)

Nitaqat Program Impact
----------------------
Saudization quotas have shifted sectoral composition over the last decade:
- Retail Saudization rose from under 5% in 2010 to over 35% in 2023.
- Healthcare professional Saudization (physicians, pharmacists) rose from
  approximately 15% to over 30%.
- Accounting & HR professions have seen rapid Saudization since the 2022
  expansion.

Sectors Resistant to Saudization
--------------------------------
Construction, domestic services, and agriculture remain dominated by non-
Saudi workers due to wage differentials, physical demand, and limited Saudi
labor supply for these roles.

Future Trends
-------------
Expected growth sectors (2025-2030):
  - Tourism/hospitality (NEOM, Red Sea, Qiddiya, AlUla)
  - Logistics (Vision 2030 hub strategy)
  - Financial services (Regional HQ program)
  - Digital/tech (DGA, PIF tech investments)
  - Healthcare (population growth, service expansion)

Declining/stable share sectors:
  - Oil & gas extraction (already capital-intensive)
  - Traditional manufacturing
""",

    "Q3_2025_Flash_Brief.txt": """
Q3 2025 LABOR MARKET FLASH BRIEF
================================

Headline: Saudi unemployment rose to 7.5% in Q3 2025 from 6.8% in Q2 2025,
interrupting the multi-year declining trend.

Likely Drivers
--------------
- Seasonal summer graduation cohort entering the labor force (recurring
  pattern observed each Q3).
- Slower private sector hiring in construction as several mega-project
  phases shifted from build-out to operations.
- Net positive female labor supply as participation continued to rise
  faster than absorption.

Granular View
-------------
- Saudi female unemployment rose from 9.8% (Q2) to 11.2% (Q3), a 1.4pp jump.
- Saudi male unemployment rose modestly from 5.6% to 5.9%.
- Youth unemployment rose from 17.5% to 19.0%.
- Regional concentration: Increases most pronounced in Jazan, Aseer, and
  Al-Baha.

Outlook
-------
The Q3 uptick is likely partially seasonal. Baseline projection: Q4 2025
stabilization around 7.2-7.4%, with further decline in Q1 2026 as post-
graduation entrants secure placement.
""",
}


def main():
    out_dir = Path("data/rag_corpus")
    out_dir.mkdir(parents=True, exist_ok=True)
    for fn, content in DOCS.items():
        (out_dir / fn).write_text(content.strip(), encoding="utf-8")
    print(f"Wrote {len(DOCS)} documents to {out_dir}/")
    for fn in DOCS:
        size = (out_dir / fn).stat().st_size
        print(f"  {fn:50s} {size:>6,} bytes")


if __name__ == "__main__":
    main()

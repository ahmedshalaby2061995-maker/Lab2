"""
Trend & Benchmark Analysis Tool
================================
Automates QoQ, YoY, and cohort comparisons over labor market time series.
All results are returned as JSON-serializable dicts so the agent can narrate them.
"""
from __future__ import annotations

import sqlite3
from typing import Dict, List, Optional, Any

import pandas as pd


def _q_order(q: str) -> tuple:
    """Sort key for 'YYYY-Qn' strings."""
    return int(q[:4]), int(q[-1])


def get_time_series(db_path: str, indicator: str, nationality: str = "Total",
                    sex: str = "Total", category: str = "All",
                    dimension: str = "time_series") -> pd.DataFrame:
    """Fetch one time series as a DataFrame[quarter, value]."""
    con = sqlite3.connect(db_path)
    df = pd.read_sql_query("""
        SELECT quarter, value FROM labor_facts
        WHERE indicator=? AND dimension=? AND nationality=? AND sex=? AND category=?
        ORDER BY quarter
    """, con, params=(indicator, dimension, nationality, sex, category))
    con.close()
    if not df.empty:
        df = df.assign(_k=df["quarter"].map(_q_order)).sort_values("_k").drop(columns="_k")
    return df.reset_index(drop=True)


def compute_qoq_yoy(df: pd.DataFrame) -> pd.DataFrame:
    """Add QoQ and YoY change columns (absolute pp difference)."""
    df = df.copy()
    df["qoq_change"] = df["value"].diff().round(3)
    df["yoy_change"] = df["value"].diff(4).round(3)
    df["qoq_pct"] = (df["value"].pct_change() * 100).round(2)
    df["yoy_pct"] = (df["value"].pct_change(4) * 100).round(2)
    return df


def analyze_trend(db_path: str, indicator: str, nationality: str = "Saudi",
                  sex: str = "Total", category: str = "All",
                  dimension: str = "time_series") -> Dict[str, Any]:
    """
    Run a full trend analysis: levels, QoQ, YoY, min/max, direction,
    and a short natural-language summary of the pattern.
    """
    df = get_time_series(db_path, indicator, nationality, sex, category, dimension)
    if df.empty:
        return {"ok": False, "error": f"No series for {indicator} ({nationality}/{sex}/{category})"}

    df = compute_qoq_yoy(df)
    latest = df.iloc[-1]
    first = df.iloc[0]

    # Direction over last 4 quarters
    recent = df.tail(4)
    recent_trend = "rising" if recent["value"].iloc[-1] > recent["value"].iloc[0] else "declining"
    if abs(recent["value"].iloc[-1] - recent["value"].iloc[0]) < 0.1:
        recent_trend = "stable"

    # Direction over full period
    overall_trend = "rising" if latest["value"] > first["value"] else "declining"
    if abs(latest["value"] - first["value"]) < 0.1:
        overall_trend = "stable"

    result = {
        "ok": True,
        "indicator": indicator,
        "nationality": nationality,
        "sex": sex,
        "category": category,
        "n_periods": int(len(df)),
        "first_quarter": first["quarter"],
        "first_value": float(first["value"]),
        "latest_quarter": latest["quarter"],
        "latest_value": float(latest["value"]),
        "min_value": float(df["value"].min()),
        "min_quarter": df.loc[df["value"].idxmin(), "quarter"],
        "max_value": float(df["value"].max()),
        "max_quarter": df.loc[df["value"].idxmax(), "quarter"],
        "qoq_change": float(latest["qoq_change"]) if pd.notna(latest["qoq_change"]) else None,
        "yoy_change": float(latest["yoy_change"]) if pd.notna(latest["yoy_change"]) else None,
        "qoq_pct": float(latest["qoq_pct"]) if pd.notna(latest["qoq_pct"]) else None,
        "yoy_pct": float(latest["yoy_pct"]) if pd.notna(latest["yoy_pct"]) else None,
        "recent_trend": recent_trend,
        "overall_trend": overall_trend,
        "series": df.to_dict(orient="records"),
    }
    result["summary"] = _summarize_trend(result)
    return result


def _summarize_trend(r: Dict) -> str:
    parts = []
    ind = r["indicator"].replace("_", " ")
    nat = r["nationality"]
    parts.append(
        f"{nat} {ind} moved from {r['first_value']:.2f} in {r['first_quarter']} "
        f"to {r['latest_value']:.2f} in {r['latest_quarter']} — an {r['overall_trend']} "
        f"trajectory over the {r['n_periods']}-quarter window."
    )
    if r["qoq_change"] is not None:
        sign = "+" if r["qoq_change"] >= 0 else ""
        parts.append(f"QoQ change: {sign}{r['qoq_change']:.2f}.")
    if r["yoy_change"] is not None:
        sign = "+" if r["yoy_change"] >= 0 else ""
        parts.append(f"YoY change: {sign}{r['yoy_change']:.2f}.")
    parts.append(
        f"Period range: low of {r['min_value']:.2f} in {r['min_quarter']}, "
        f"high of {r['max_value']:.2f} in {r['max_quarter']}."
    )
    return " ".join(parts)


def compare_cohorts(db_path: str, indicator: str, cohorts: List[Dict[str, str]],
                    dimension: str = "time_series", category: str = "All") -> Dict[str, Any]:
    """
    Compare several (nationality, sex) cohorts on the same indicator.
    Returns aligned values at the latest quarter + gap analysis.
    """
    con = sqlite3.connect(db_path)
    series = {}
    for c in cohorts:
        nat = c.get("nationality", "Saudi")
        sex = c.get("sex", "Total")
        label = c.get("label") or f"{nat}/{sex}"
        df = pd.read_sql_query("""
            SELECT quarter, value FROM labor_facts
            WHERE indicator=? AND dimension=? AND category=? AND nationality=? AND sex=?
            ORDER BY quarter
        """, con, params=(indicator, dimension, category, nat, sex))
        if not df.empty:
            df = df.assign(_k=df["quarter"].map(_q_order)).sort_values("_k").drop(columns="_k")
            series[label] = df.reset_index(drop=True)
    con.close()

    if not series:
        return {"ok": False, "error": "No matching cohorts found."}

    # Align on common latest quarter
    latest_q = min(df["quarter"].iloc[-1] for df in series.values())
    latest_values = {k: float(v[v["quarter"] == latest_q]["value"].iloc[0])
                     for k, v in series.items() if (v["quarter"] == latest_q).any()}

    # Gap analysis (pairwise)
    labels = list(latest_values.keys())
    gaps = []
    for i in range(len(labels)):
        for j in range(i + 1, len(labels)):
            gap = latest_values[labels[i]] - latest_values[labels[j]]
            gaps.append({
                "pair": f"{labels[i]} vs {labels[j]}",
                "gap": round(gap, 2),
            })

    return {
        "ok": True,
        "indicator": indicator,
        "latest_quarter": latest_q,
        "cohort_values": {k: round(v, 2) for k, v in latest_values.items()},
        "gaps": gaps,
        "series": {k: v.to_dict(orient="records") for k, v in series.items()},
    }


def breakdown_by_dimension(db_path: str, indicator: str, dimension: str,
                           nationality: str = "Saudi", sex: str = "Total",
                           quarter: Optional[str] = None) -> Dict[str, Any]:
    """Get a breakdown of an indicator across its categories (e.g. by age, region)."""
    con = sqlite3.connect(db_path)
    params = [indicator, dimension, nationality, sex]
    query = """
        SELECT quarter, category, value FROM labor_facts
        WHERE indicator=? AND dimension=? AND nationality=? AND sex=?
    """
    if quarter:
        query += " AND quarter=?"
        params.append(quarter)
    query += " ORDER BY category"
    df = pd.read_sql_query(query, con, params=params)
    con.close()

    if df.empty:
        return {"ok": False, "error": "No data for this breakdown."}

    # If no quarter specified, use latest
    if not quarter:
        quarter = df["quarter"].max()
        df = df[df["quarter"] == quarter]

    df = df.sort_values("value", ascending=False)
    return {
        "ok": True,
        "indicator": indicator,
        "dimension": dimension,
        "nationality": nationality,
        "sex": sex,
        "quarter": quarter,
        "breakdown": df[["category", "value"]].to_dict(orient="records"),
        "highest": df.iloc[0]["category"] if not df.empty else None,
        "lowest": df.iloc[-1]["category"] if not df.empty else None,
    }


if __name__ == "__main__":
    import json
    import sys
    db = sys.argv[1] if len(sys.argv) > 1 else "data/labor.db"

    print("=== Saudi unemployment trend ===")
    r = analyze_trend(db, "unemployment_rate", "Saudi", "Total")
    print(r["summary"])
    print()

    print("=== Cohort compare: Saudi Male vs Female vs Non-Saudi ===")
    r = compare_cohorts(db, "unemployment_rate", [
        {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
        {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
        {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
    ])
    print(json.dumps({k: v for k, v in r.items() if k != "series"}, indent=2))

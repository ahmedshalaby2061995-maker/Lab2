"""
RAG Tool — Retrieval Augmented Generation for Labor Market Reports
===================================================================
Indexes previous economic studies, GASTAT methodology notes, policy docs, and
executive briefs as a knowledge base the agent can query.

Two pluggable backends:
  1. TFIDFBackend  — pure sklearn, zero external deps. Default for POC.
  2. ChromaBackend — sentence-transformers + ChromaDB. Used in production when
     the user installs chromadb + sentence-transformers.

Both expose the same interface: index(corpus) and search(query, k).

The loader supports .txt, .md, and .pdf files (via pypdf/reportlab).
"""
from __future__ import annotations

import os
import re
import json
import pickle
from pathlib import Path
from typing import List, Dict, Any, Optional

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# --- Corpus loading ---

def _read_pdf(path: str) -> str:
    """Read PDF text — uses pypdf if available, else returns empty string."""
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        return "\n".join((p.extract_text() or "") for p in reader.pages)
    except ImportError:
        try:
            from PyPDF2 import PdfReader
            reader = PdfReader(path)
            return "\n".join((p.extract_text() or "") for p in reader.pages)
        except ImportError:
            return ""


def _chunk_text(text: str, chunk_size: int = 800, overlap: int = 100) -> List[str]:
    """Split text into overlapping chunks (~chunk_size chars, break on sentences)."""
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    chunks: List[str] = []
    i = 0
    while i < len(text):
        end = min(i + chunk_size, len(text))
        # Prefer to break on period or newline
        if end < len(text):
            for sep in [". ", "? ", "! ", "\n"]:
                idx = text.rfind(sep, i, end)
                if idx > i + chunk_size // 2:
                    end = idx + len(sep)
                    break
        chunks.append(text[i:end].strip())
        if end >= len(text):
            break
        i = max(end - overlap, i + 1)
    return [c for c in chunks if len(c) > 50]


def load_corpus(directory: str) -> List[Dict[str, Any]]:
    """Scan directory for documents and chunk them. Returns list of doc dicts."""
    docs: List[Dict[str, Any]] = []
    if not os.path.isdir(directory):
        return docs
    for fn in sorted(os.listdir(directory)):
        path = os.path.join(directory, fn)
        if not os.path.isfile(path):
            continue
        ext = fn.lower().rsplit(".", 1)[-1]
        text = ""
        if ext in ("txt", "md"):
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        elif ext == "pdf":
            text = _read_pdf(path)
        else:
            continue
        for chunk_i, chunk in enumerate(_chunk_text(text)):
            docs.append({
                "doc_id": fn,
                "chunk_id": f"{fn}#{chunk_i}",
                "text": chunk,
                "source": path,
            })
    return docs


# --- Backends ---

class TFIDFBackend:
    """Default, zero-dep backend using TF-IDF + cosine similarity."""

    def __init__(self):
        self.vec: Optional[TfidfVectorizer] = None
        self.matrix = None
        self.docs: List[Dict[str, Any]] = []

    def index(self, docs: List[Dict[str, Any]]) -> None:
        if not docs:
            return
        self.docs = docs
        texts = [d["text"] for d in docs]
        self.vec = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_df=0.95,
            min_df=1,
            sublinear_tf=True,
        )
        self.matrix = self.vec.fit_transform(texts)

    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        if self.vec is None or not self.docs:
            return []
        q_vec = self.vec.transform([query])
        scores = cosine_similarity(q_vec, self.matrix).flatten()
        top_idx = np.argsort(-scores)[:k]
        out = []
        for idx in top_idx:
            if scores[idx] <= 0:
                continue
            d = dict(self.docs[idx])
            d["score"] = float(scores[idx])
            out.append(d)
        return out

    def save(self, path: str) -> None:
        with open(path, "wb") as f:
            pickle.dump({"vec": self.vec, "matrix": self.matrix, "docs": self.docs}, f)

    def load(self, path: str) -> None:
        with open(path, "rb") as f:
            obj = pickle.load(f)
        self.vec = obj["vec"]
        self.matrix = obj["matrix"]
        self.docs = obj["docs"]


class ChromaBackend:
    """
    Production backend using ChromaDB + sentence-transformers.
    Requires: pip install chromadb sentence-transformers
    """

    def __init__(self, persist_dir: str = "data/chroma", model_name: str = "all-MiniLM-L6-v2"):
        self.persist_dir = persist_dir
        self.model_name = model_name
        self._client = None
        self._collection = None
        self._embedder = None

    def _lazy_init(self):
        if self._client is not None:
            return
        import chromadb
        from chromadb.config import Settings
        from sentence_transformers import SentenceTransformer
        self._client = chromadb.PersistentClient(path=self.persist_dir,
                                                  settings=Settings(anonymized_telemetry=False))
        self._collection = self._client.get_or_create_collection(name="labor_reports")
        self._embedder = SentenceTransformer(self.model_name)

    def index(self, docs: List[Dict[str, Any]]) -> None:
        self._lazy_init()
        if not docs:
            return
        ids = [d["chunk_id"] for d in docs]
        texts = [d["text"] for d in docs]
        metadatas = [{"doc_id": d["doc_id"], "source": d.get("source", "")} for d in docs]
        embeddings = self._embedder.encode(texts, show_progress_bar=False).tolist()
        # Upsert
        self._collection.upsert(ids=ids, documents=texts,
                                 metadatas=metadatas, embeddings=embeddings)

    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        self._lazy_init()
        q_emb = self._embedder.encode([query]).tolist()
        res = self._collection.query(query_embeddings=q_emb, n_results=k)
        out = []
        for doc, meta, dist, id_ in zip(res["documents"][0], res["metadatas"][0],
                                        res["distances"][0], res["ids"][0]):
            out.append({
                "chunk_id": id_,
                "doc_id": meta.get("doc_id"),
                "source": meta.get("source", ""),
                "text": doc,
                "score": 1.0 - float(dist),  # convert distance to similarity-ish
            })
        return out


# --- Public API ---

class RAGStore:
    """High-level wrapper that picks a backend and exposes index/search/query."""

    def __init__(self, backend: str = "tfidf", **kwargs):
        self.backend_name = backend
        if backend == "chroma":
            self.backend = ChromaBackend(**kwargs)
        else:
            self.backend = TFIDFBackend()

    def build_from_directory(self, directory: str) -> int:
        docs = load_corpus(directory)
        self.backend.index(docs)
        return len(docs)

    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        return self.backend.search(query, k)

    def query(self, question: str, k: int = 5) -> Dict[str, Any]:
        """Return structured retrieval result for agent consumption."""
        hits = self.search(question, k)
        return {
            "ok": bool(hits),
            "question": question,
            "n_results": len(hits),
            "results": hits,
            "context": "\n\n---\n\n".join(
                f"[Source: {h['doc_id']}]\n{h['text']}" for h in hits
            ),
        }

    def save(self, path: str) -> None:
        if isinstance(self.backend, TFIDFBackend):
            self.backend.save(path)

    def load(self, path: str) -> None:
        if isinstance(self.backend, TFIDFBackend):
            self.backend.load(path)


if __name__ == "__main__":
    import sys
    corpus_dir = sys.argv[1] if len(sys.argv) > 1 else "data/rag_corpus"
    query = sys.argv[2] if len(sys.argv) > 2 else "What drives youth unemployment in Saudi Arabia?"
    rag = RAGStore(backend="tfidf")
    n = rag.build_from_directory(corpus_dir)
    print(f"Indexed {n} chunks.")
    result = rag.query(query, k=3)
    print(f"\nQ: {query}")
    for i, h in enumerate(result["results"], 1):
        print(f"\n--- Hit {i}: {h['doc_id']} (score={h['score']:.3f}) ---")
        print(h["text"][:300] + "...")

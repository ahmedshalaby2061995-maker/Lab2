"""
FastAPI Backend — Labor Market Analysis Agent
==============================================
Exposes:
  GET  /                     → serves the chat + dashboard UI
  POST /api/chat             → send a chat message to the agent
  POST /api/upload           → upload a new GASTAT xlsx for ingestion
  GET  /api/indicators       → list available indicators & dimensions
  GET  /api/series           → fetch a time series for the dashboard
  GET  /api/breakdown        → fetch a dimensional breakdown for the dashboard
  GET  /api/forecast         → fetch a forecast for the dashboard
  GET  /api/validate         → run validation and return flags
  POST /api/report           → generate MD + PDF briefing
  GET  /api/download/{name}  → download a generated report file
  GET  /api/health           → liveness probe

Run:
  uvicorn app:app --reload --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

# ── Load .env FIRST — before any os.getenv() or agent init ──────────────────
# Uvicorn on Windows does NOT auto-load .env files, so OPENAI_API_KEY would be
# None without this, causing the agent to fall back to rule-based mode.
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv not installed; user must set env vars manually

import math
import os
import shutil
import logging
import secrets
import hashlib
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, UploadFile, File, HTTPException, Request, Depends, Cookie, Form
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from agent import build_agent, AgentContext
from ingestion import ingest_gastat_xlsx, save_to_db, infer_quarter_from_filename
from tools.trend_analyzer import (
    analyze_trend, compare_cohorts, breakdown_by_dimension, get_time_series
)
from tools.forecaster import forecast_indicator
from tools.validator import validate_dataset


# ---------- Configuration ----------

BASE_DIR = Path(__file__).parent
DB_PATH = os.getenv("DB_PATH", str(BASE_DIR / "data/labor.db"))
RAG_CORPUS_DIR = os.getenv("RAG_CORPUS_DIR", str(BASE_DIR / "data/rag_corpus"))
OUTPUT_DIR = os.getenv("OUTPUT_DIR", str(BASE_DIR / "data/processed"))
UPLOADS_DIR = os.getenv("UPLOADS_DIR", str(BASE_DIR / "data/raw"))

for d in (OUTPUT_DIR, UPLOADS_DIR, RAG_CORPUS_DIR):
    os.makedirs(d, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("labor_agent")


# ---------- JSON safety ----------

def _sanitize_json(obj):
    """
    Recursively replace float NaN / Inf with None so FastAPI's json.dumps never
    raises "Out of range float values are not JSON compliant: nan".

    Root cause: pandas .diff() produces NaN for the first row of every series.
    Even after _safe_records() fixes DataFrames, scalar fields (qoq_change,
    yoy_change, rmse, upper_95 list items …) can still carry float('nan').
    """
    if isinstance(obj, float):
        return None if (math.isnan(obj) or math.isinf(obj)) else obj
    if isinstance(obj, dict):
        return {k: _sanitize_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize_json(v) for v in obj]
    return obj


# ---------- Authentication ----------
# Simple in-memory session store. For production, replace with Redis / database.
# Format: {session_token: {"username": str, "expires": datetime}}

SESSIONS: Dict[str, Dict[str, Any]] = {}
SESSION_COOKIE_NAME = "labor_agent_session"
SESSION_TTL_HOURS = 8

# User store. For MVP demo, hardcoded. For production, use a real DB + bcrypt/argon2.
# Passwords are SHA-256 hashed (still demo-grade — replace with bcrypt for prod).
def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

USERS: Dict[str, Dict[str, str]] = {
    "admin": {
        "password_hash": _hash_password("admin"),
        "display_name": "Admin User",
        "role": "Administrator",
    },
    "analyst": {
        "password_hash": _hash_password("analyst"),
        "display_name": "Labor Analyst",
        "role": "Analyst",
    },
}


def _create_session(username: str) -> str:
    """Generate a session token and store it. Returns the token."""
    token = secrets.token_urlsafe(32)
    SESSIONS[token] = {
        "username": username,
        "expires": datetime.utcnow() + timedelta(hours=SESSION_TTL_HOURS),
    }
    return token


def _get_session(token: Optional[str]) -> Optional[Dict[str, Any]]:
    """Look up an active session. Returns None if missing/expired."""
    if not token or token not in SESSIONS:
        return None
    sess = SESSIONS[token]
    if sess["expires"] < datetime.utcnow():
        SESSIONS.pop(token, None)
        return None
    return sess


def require_auth(request: Request,
                  labor_agent_session: Optional[str] = Cookie(default=None)) -> Dict[str, Any]:
    """FastAPI dependency that enforces authentication on protected routes."""
    sess = _get_session(labor_agent_session)
    if not sess:
        # For API calls, return 401 JSON. For page loads, redirect to /login.
        if request.url.path.startswith("/api/"):
            raise HTTPException(status_code=401, detail="Authentication required")
        # Otherwise raise a redirect via HTTPException (custom)
        raise HTTPException(
            status_code=307,
            detail="Redirecting to login",
            headers={"Location": "/login"},
        )
    user = USERS.get(sess["username"], {})
    return {
        "username": sess["username"],
        "display_name": user.get("display_name", sess["username"]),
        "role": user.get("role", "User"),
    }


# ---------- Knowledge-Management store ----------
# A small SQLite table tracks every reference document the user uploads via the
# KM panel. Files themselves are written into RAG_CORPUS_DIR so the agent's
# existing RAG ingest picks them up on next rebuild.

# Reuse the main labor.db rather than a separate file — keeps the KM table
# alongside labor_facts and avoids needing write access to data/ on systems
# where the directory itself is read-only after seeding.
KM_DB_PATH = os.getenv("KM_DB_PATH", DB_PATH)


def _km_init_db() -> None:
    import sqlite3
    con = sqlite3.connect(KM_DB_PATH)
    con.execute("""
        CREATE TABLE IF NOT EXISTS km_documents (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            filename      TEXT NOT NULL,
            stored_name   TEXT NOT NULL UNIQUE,
            file_type     TEXT NOT NULL,
            size_bytes    INTEGER NOT NULL,
            word_count    INTEGER,
            page_count    INTEGER,
            sha256        TEXT NOT NULL,
            status        TEXT NOT NULL DEFAULT 'indexed',
            uploaded_at   TEXT NOT NULL,
            uploaded_by   TEXT
        )
    """)
    con.commit()
    con.close()


_km_init_db()


def _km_extract_text(path: str, ext: str) -> tuple[str, Optional[int]]:
    """Extract text from an uploaded reference document.

    Returns (text, page_count). page_count is None for non-paginated formats.
    Raises ValueError if the file can't be parsed.
    """
    ext = ext.lower().lstrip(".")
    if ext in ("txt", "md"):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(), None
    if ext == "pdf":
        from pypdf import PdfReader
        reader = PdfReader(path)
        parts = []
        for page in reader.pages:
            try:
                parts.append(page.extract_text() or "")
            except Exception:
                parts.append("")
        return "\n".join(parts), len(reader.pages)
    raise ValueError(f"Unsupported file type: .{ext} (use .txt, .md, or .pdf)")


# ---------- App & shared agent context ----------

app = FastAPI(
    title="Labor Market Analysis Agent",
    description="AI-powered agent for quarterly Saudi labor market analysis (GASTAT).",
    version="1.0.0",
)

ctx = AgentContext(db_path=DB_PATH, rag_corpus_dir=RAG_CORPUS_DIR, output_dir=OUTPUT_DIR)
agent, agent_mode = build_agent(ctx)
log.info(f"Agent initialized in {agent_mode} mode.")

# Build RAG on startup so first query is fast
try:
    n = ctx.ensure_rag()
    if n:
        log.info(f"RAG indexed {n} chunks from {RAG_CORPUS_DIR}")
except Exception as e:
    log.warning(f"RAG initialization failed: {e}")

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


# ---------- Pydantic request/response models ----------

class ChatMessage(BaseModel):
    role: str = Field(..., description="'user' or 'assistant'")
    content: str


class ChatRequest(BaseModel):
    message: str
    history: Optional[List[ChatMessage]] = None


class ChatResponse(BaseModel):
    reply: str
    tool_calls: List[Dict[str, Any]] = []
    artifacts: Dict[str, Any] = {}
    mode: str


class ReportRequest(BaseModel):
    reference_quarter: Optional[str] = None


# ---------- Routes ----------

@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    """Silence the browser favicon 404. Returns a 1x1 transparent GIF."""
    from fastapi.responses import Response
    # 1x1 transparent GIF (43 bytes)
    gif = (b"GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00"
           b"!\xf9\x04\x01\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01"
           b"\x00\x00\x02\x02D\x01\x00;")
    return Response(content=gif, media_type="image/gif")


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """Return a useful JSON body for uncaught errors instead of an opaque 500."""
    log.exception(f"Unhandled error on {request.method} {request.url.path}")
    return JSONResponse(
        status_code=500,
        content={
            "ok": False,
            "error": str(exc),
            "type": type(exc).__name__,
            "path": request.url.path,
            "hint": _error_hint(exc),
        },
    )


def _error_hint(exc: Exception) -> str:
    """Map common errors to actionable hints."""
    msg = str(exc).lower()
    name = type(exc).__name__
    if "no such table" in msg or "no such file" in msg or "labor_facts" in msg:
        return ("Database not seeded. Run: python3 ingestion.py "
                "sample_data/Labor_Market_Statistics_Q4_2025_EN__1_.xlsx data/labor.db")
    if "templatenotfound" in name.lower() or "template" in msg and "not found" in msg:
        return ("Templates folder not found. Make sure you launch uvicorn from "
                "inside the labor_agent/ directory.")
    if "openai" in msg or "api key" in msg or "401" in msg or "unauthorized" in msg:
        return ("OpenAI API call failed. Check OPENAI_API_KEY and OPENAI_BASE_URL "
                "in your .env file.")
    if "connection" in msg or "timeout" in msg:
        return ("Network call failed. Check OPENAI_BASE_URL is reachable from this host.")
    return ""


@app.get("/login", response_class=HTMLResponse)
async def login_page(error: Optional[str] = None):
    """Serve the login page. If already logged in, redirect to app."""
    html_path = BASE_DIR / "templates" / "login.html"
    content = html_path.read_text(encoding="utf-8")
    error_html = ""
    if error == "invalid":
        error_html = '<div class="alert">Invalid username or password</div>'
    elif error == "expired":
        error_html = '<div class="alert">Your session expired. Please sign in again.</div>'
    content = content.replace("__ERROR_BLOCK__", error_html)
    return HTMLResponse(content=content)


@app.post("/api/login")
async def api_login(username: str = Form(...), password: str = Form(...)):
    """Authenticate and create a session cookie."""
    user = USERS.get(username)
    if not user or user["password_hash"] != _hash_password(password):
        return RedirectResponse(url="/login?error=invalid", status_code=303)
    token = _create_session(username)
    response = RedirectResponse(url="/", status_code=303)
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=token,
        max_age=SESSION_TTL_HOURS * 3600,
        httponly=True,
        samesite="lax",
    )
    return response


@app.post("/api/logout")
async def api_logout(labor_agent_session: Optional[str] = Cookie(default=None)):
    """Clear session and cookie."""
    if labor_agent_session:
        SESSIONS.pop(labor_agent_session, None)
    response = JSONResponse({"ok": True})
    response.delete_cookie(SESSION_COOKIE_NAME)
    return response


@app.get("/api/me")
async def api_me(user: Dict = Depends(require_auth)):
    """Return current user info — used by frontend to populate the sidebar."""
    return {**user, "agent_mode": agent_mode}


@app.get("/", response_class=HTMLResponse)
async def index(request: Request,
                labor_agent_session: Optional[str] = Cookie(default=None)):
    """Serve the main UI. Redirect to /login if not authenticated."""
    sess = _get_session(labor_agent_session)
    if not sess:
        return RedirectResponse(url="/login", status_code=303)
    html_path = BASE_DIR / "templates" / "app.html"
    content = html_path.read_text(encoding="utf-8")
    user = USERS.get(sess["username"], {})
    content = content.replace("__AGENT_MODE__", str(agent_mode))
    content = content.replace("__USER_NAME__", user.get("display_name", sess["username"]))
    content = content.replace("__USER_ROLE__", user.get("role", "User"))
    return HTMLResponse(content=content)


@app.get("/api/health")
async def health():
    return {"status": "ok", "agent_mode": agent_mode,
            "db": os.path.exists(DB_PATH),
            "rag_corpus": os.path.isdir(RAG_CORPUS_DIR)}


@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, _user: Dict = Depends(require_auth)):
    try:
        # Helpful early check: if the DB is empty, give a clear message
        if not os.path.exists(DB_PATH):
            return ChatResponse(
                reply=("⚠️ The database hasn't been seeded yet. Either upload a "
                       "GASTAT xlsx via the upload area below, or run from the "
                       "terminal:\n\n"
                       "    python3 ingestion.py sample_data/Labor_Market_Statistics_Q4_2025_EN__1_.xlsx data/labor.db"),
                tool_calls=[],
                artifacts={},
                mode=agent_mode,
            )
        history = [h.model_dump() for h in (req.history or [])]
        result = agent.chat(req.message, history=history)
        return ChatResponse(
            reply=result.get("reply", ""),
            tool_calls=result.get("tool_calls", []),
            artifacts=result.get("artifacts", {}),
            mode=agent_mode,
        )
    except Exception as e:
        log.exception("chat failed")
        # Surface the real error to the UI rather than a generic 500
        return ChatResponse(
            reply=f"⚠️ Agent error: {type(e).__name__}: {e}\n\n"
                  f"Check the uvicorn console for the full traceback.",
            tool_calls=[],
            artifacts={},
            mode=agent_mode,
        )


@app.post("/api/upload")
async def upload(file: UploadFile = File(...), _user: Dict = Depends(require_auth)):
    """Accept a new GASTAT xlsx, parse it, and load into the database."""
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400,
                            detail="Only .xlsx / .xlsm files are supported.")
    save_path = os.path.join(UPLOADS_DIR, file.filename)
    try:
        with open(save_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        # Parse
        snapshot_q = infer_quarter_from_filename(save_path)
        df = ingest_gastat_xlsx(save_path, snapshot_quarter=snapshot_q)
        if df.empty:
            raise HTTPException(status_code=400,
                                detail="Could not parse any data from this file. "
                                       "Check that it follows GASTAT format.")
        # Validate first, then save
        rows = save_to_db(df, DB_PATH, save_path)

        # Run validation
        val = validate_dataset(DB_PATH)

        return {
            "ok": True,
            "filename": file.filename,
            "snapshot_quarter": snapshot_q,
            "rows_ingested": rows,
            "indicators_detected": sorted(df["indicator"].unique().tolist()),
            "quarters_detected": sorted(df["quarter"].unique().tolist()),
            "validation": {
                "flags": val["flags"],
                "total_rows": val.get("summary", {}).get("total_rows"),
            },
        }
    except HTTPException:
        raise
    except Exception as e:
        log.exception("upload failed")
        raise HTTPException(status_code=500, detail=str(e))


# ---------- Knowledge Management endpoints ----------

KM_ALLOWED_EXT = {".pdf", ".txt", ".md"}
KM_MAX_BYTES = 25 * 1024 * 1024  # 25 MB


@app.get("/api/km/documents")
async def km_list_documents(_user: Dict = Depends(require_auth)):
    """Return every KM-uploaded reference document, newest first."""
    import sqlite3
    con = sqlite3.connect(KM_DB_PATH)
    con.row_factory = sqlite3.Row
    rows = con.execute("""
        SELECT id, filename, file_type, size_bytes, word_count, page_count,
               sha256, status, uploaded_at, uploaded_by
        FROM km_documents
        ORDER BY uploaded_at DESC
    """).fetchall()
    con.close()
    return {"documents": [dict(r) for r in rows]}


@app.post("/api/km/upload")
async def km_upload(file: UploadFile = File(...),
                     user: Dict = Depends(require_auth)):
    """Accept a reference document, parse it, persist into the RAG corpus, and
    record metadata so the KM table can list it.
    """
    fn = file.filename or ""
    ext = os.path.splitext(fn)[1].lower()
    if ext not in KM_ALLOWED_EXT:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type {ext!r}. Use PDF, TXT, or MD.",
        )

    # Read into memory once so we can hash, size-check, and persist without
    # racing against the upload stream.
    raw = await file.read()
    if len(raw) > KM_MAX_BYTES:
        raise HTTPException(
            status_code=400,
            detail=f"File too large ({len(raw)/1024/1024:.1f} MB). Max 25 MB.",
        )

    sha = hashlib.sha256(raw).hexdigest()

    # Prefix the stored name with the sha so duplicate filenames don't collide
    # and identical content is naturally idempotent.
    stem, suffix = os.path.splitext(os.path.basename(fn))
    safe_stem = "".join(c for c in stem if c.isalnum() or c in "-_") or "doc"
    stored_name = f"{safe_stem}__{sha[:10]}{suffix.lower()}"
    save_path = os.path.join(RAG_CORPUS_DIR, stored_name)

    with open(save_path, "wb") as f:
        f.write(raw)

    try:
        text, page_count = _km_extract_text(save_path, ext)
    except Exception as e:
        # Couldn't parse — delete the file so it doesn't poison the RAG ingest
        try: os.remove(save_path)
        except OSError: pass
        log.exception("KM parse failed for %s", fn)
        raise HTTPException(status_code=400, detail=f"Could not parse document: {e}")

    word_count = len(text.split())

    import sqlite3
    con = sqlite3.connect(KM_DB_PATH)
    try:
        cur = con.execute("""
            INSERT INTO km_documents
              (filename, stored_name, file_type, size_bytes, word_count,
               page_count, sha256, status, uploaded_at, uploaded_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'indexed', ?, ?)
        """, (
            fn, stored_name, ext.lstrip("."), len(raw), word_count,
            page_count, sha, datetime.utcnow().isoformat(timespec="seconds") + "Z",
            user["username"],
        ))
        con.commit()
        new_id = cur.lastrowid
    except sqlite3.IntegrityError:
        # Same SHA already indexed — keep the existing row, drop the duplicate file.
        try: os.remove(save_path)
        except OSError: pass
        existing = con.execute(
            "SELECT id FROM km_documents WHERE sha256 = ?", (sha,)
        ).fetchone()
        new_id = existing[0] if existing else None
    finally:
        con.close()

    return {
        "ok": True,
        "id": new_id,
        "filename": fn,
        "stored_name": stored_name,
        "file_type": ext.lstrip("."),
        "size_bytes": len(raw),
        "word_count": word_count,
        "page_count": page_count,
        "sha256": sha,
        "status": "indexed",
    }


@app.delete("/api/km/documents/{doc_id}")
async def km_delete_document(doc_id: int, _user: Dict = Depends(require_auth)):
    """Remove a KM document — both the file in the RAG corpus and the row."""
    import sqlite3
    con = sqlite3.connect(KM_DB_PATH)
    row = con.execute(
        "SELECT stored_name FROM km_documents WHERE id = ?", (doc_id,)
    ).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Document not found")
    stored_name = row[0]
    con.execute("DELETE FROM km_documents WHERE id = ?", (doc_id,))
    con.commit()
    con.close()

    file_path = os.path.join(RAG_CORPUS_DIR, stored_name)
    try:
        os.remove(file_path)
    except OSError:
        pass
    return {"ok": True, "id": doc_id}


@app.get("/api/indicators")
async def list_indicators():
    """Return the set of (indicator, dimension) pairs available in the DB."""
    import sqlite3
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    rows = cur.execute("""
        SELECT indicator, dimension, COUNT(*) as n, COUNT(DISTINCT quarter) as quarters
        FROM labor_facts GROUP BY indicator, dimension ORDER BY indicator, dimension
    """).fetchall()
    quarters = [r[0] for r in cur.execute(
        "SELECT DISTINCT quarter FROM labor_facts ORDER BY quarter"
    ).fetchall()]
    con.close()
    return {
        "indicators": [
            {"indicator": r[0], "dimension": r[1], "rows": r[2], "quarters": r[3]}
            for r in rows
        ],
        "quarters": quarters,
        "latest_quarter": quarters[-1] if quarters else None,
    }


@app.get("/api/series")
async def api_series(indicator: str, nationality: str = "Saudi", sex: str = "Total",
                    category: str = "All", dimension: str = "time_series",
                    _user: Dict = Depends(require_auth)):
    """Return a time series for plotting."""
    df = get_time_series(DB_PATH, indicator, nationality, sex, category, dimension)
    if df.empty:
        return JSONResponse({"ok": False, "error": "No data for that series."})
    result = {
        "ok": True,
        "indicator": indicator,
        "nationality": nationality,
        "sex": sex,
        "points": df.astype(object).where(df.notna(), None).to_dict(orient="records"),
    }
    return JSONResponse(_sanitize_json(result))


@app.get("/api/trend")
async def api_trend(indicator: str, nationality: str = "Saudi", sex: str = "Total",
                   _user: Dict = Depends(require_auth)):
    return JSONResponse(_sanitize_json(analyze_trend(DB_PATH, indicator, nationality, sex)))


@app.get("/api/breakdown")
async def api_breakdown(indicator: str, dimension: str,
                       nationality: str = "Saudi", sex: str = "Total",
                       quarter: Optional[str] = None,
                       _user: Dict = Depends(require_auth)):
    return JSONResponse(_sanitize_json(
        breakdown_by_dimension(DB_PATH, indicator, dimension, nationality, sex, quarter)
    ))


@app.get("/api/forecast")
async def api_forecast(indicator: str = "unemployment_rate",
                      nationality: str = "Saudi", sex: str = "Total",
                      horizon: int = 4,
                      _user: Dict = Depends(require_auth)):
    return JSONResponse(_sanitize_json(
        forecast_indicator(DB_PATH, indicator, nationality, sex, horizon=horizon)
    ))


@app.get("/api/cohorts")
async def api_cohorts(indicator: str = "unemployment_rate",
                     _user: Dict = Depends(require_auth)):
    """Standard 3-cohort comparison for the dashboard."""
    return JSONResponse(_sanitize_json(compare_cohorts(DB_PATH, indicator, cohorts=[
        {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
        {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
        {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
        {"nationality": "Total", "sex": "Total", "label": "National Total"},
    ])))


@app.get("/api/validate")
async def api_validate(_user: Dict = Depends(require_auth)):
    return validate_dataset(DB_PATH)


@app.post("/api/report")
async def api_report(req: ReportRequest, _user: Dict = Depends(require_auth)):
    """Generate the full quarterly briefing."""
    from agent import execute_tool
    result = execute_tool(ctx, "generate_report",
                          {"reference_quarter": req.reference_quarter} if req.reference_quarter
                          else {})
    if not result.get("ok"):
        raise HTTPException(status_code=500, detail=result.get("error", "Report failed"))
    return {
        "ok": True,
        "pdf_url": f"/api/download/{os.path.basename(result['pdf_path'])}",
        "markdown_url": f"/api/download/{os.path.basename(result['markdown_path'])}",
        "preview": result.get("markdown_preview", ""),
    }


@app.get("/api/download/{filename}")
async def download(filename: str):
    # Basic safety: only allow files within OUTPUT_DIR
    safe = os.path.normpath(filename).lstrip("/")
    if ".." in safe or "/" in safe:
        raise HTTPException(status_code=400, detail="Invalid filename.")
    path = os.path.join(OUTPUT_DIR, safe)
    if not os.path.isfile(path):
        raise HTTPException(status_code=404, detail="File not found.")
    media = "application/pdf" if safe.endswith(".pdf") else "text/markdown"
    return FileResponse(path, media_type=media, filename=safe)


@app.get("/api/summary")
async def api_summary(_user: Dict = Depends(require_auth)):
    """Dashboard summary: KPIs, recent trend, forecast, cohort gap — one call."""
    if not os.path.exists(DB_PATH):
        return {"ok": False, "error": "Database not seeded yet.",
                "hint": "Upload a GASTAT xlsx via the chat panel, or run "
                        "'python3 ingestion.py sample_data/Labor_Market_Statistics_Q4_2025_EN__1_.xlsx data/labor.db'"}
    try:
        # Verify the DB has data before running expensive queries
        import sqlite3
        con = sqlite3.connect(DB_PATH)
        try:
            count = con.execute("SELECT COUNT(*) FROM labor_facts").fetchone()[0]
        except sqlite3.OperationalError:
            count = 0
        con.close()
        if count == 0:
            return {"ok": False, "error": "Database is empty.",
                    "hint": "Upload a GASTAT xlsx to get started."}

        ur = analyze_trend(DB_PATH, "unemployment_rate", "Saudi", "Total")
        emp = analyze_trend(DB_PATH, "employment_to_population", "Saudi", "Total")
        lfp = analyze_trend(DB_PATH, "labor_force_participation", "Saudi", "Total")
        cohort = compare_cohorts(DB_PATH, "unemployment_rate", cohorts=[
            {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
            {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
            {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
            {"nationality": "Total", "sex": "Total", "label": "National Total"},
        ])
        fc = forecast_indicator(DB_PATH, "unemployment_rate", "Saudi", "Total", horizon=4)
        val = validate_dataset(DB_PATH)
        payload = {
            "ok": True,
            "latest_quarter": ur.get("latest_quarter"),
            "kpis": {
                "saudi_unemployment": {
                    "value": ur.get("latest_value"),
                    "qoq": ur.get("qoq_change"),
                    "yoy": ur.get("yoy_change"),
                    "trend": ur.get("overall_trend"),
                    "series": ur.get("series"),
                },
                "saudi_emp_to_pop": {
                    "value": emp.get("latest_value"),
                    "qoq": emp.get("qoq_change"),
                    "yoy": emp.get("yoy_change"),
                    "series": emp.get("series"),
                },
                "saudi_lfp": {
                    "value": lfp.get("latest_value"),
                    "qoq": lfp.get("qoq_change"),
                    "yoy": lfp.get("yoy_change"),
                    "series": lfp.get("series"),
                },
            },
            "cohorts": cohort,
            "forecast": fc,
            "validation_flags": val.get("flags", []),
        }
        return JSONResponse(_sanitize_json(payload))
    except Exception as e:
        log.exception("summary failed")
        return JSONResponse({"ok": False, "error": f"{type(e).__name__}: {e}"})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)

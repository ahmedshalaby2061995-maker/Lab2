# Sectoral Composition
Construction, retail, and hospitality remain the top three private-sector employers.

"""
End-to-end smoke test — exercises every tool and the rule-based agent
without requiring FastAPI / LangChain / Anthropic to be installed.
Run: python3 smoke_test.py
"""
import os
import sys
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

RED = "\033[91m"
GRN = "\033[92m"
YLW = "\033[93m"
BLU = "\033[94m"
BOLD = "\033[1m"
RST = "\033[0m"


def hdr(title):
    print(f"\n{BLU}{BOLD}{'=' * 72}\n{title}\n{'=' * 72}{RST}")


def ok(msg):
    print(f"  {GRN}✓{RST} {msg}")


def fail(msg):
    print(f"  {RED}✗ {msg}{RST}")
    sys.exit(1)


def main():
    failures = 0

    # ---------- 1. Ingestion ----------
    hdr("1. INGESTION")
    from ingestion import ingest_gastat_xlsx, save_to_db

    SAMPLE = ROOT / "sample_data" / "Labor_Market_Statistics_Q4_2025_EN__1_.xlsx"
    if not SAMPLE.exists():
        fail(f"Sample file missing: {SAMPLE}")

    df = ingest_gastat_xlsx(str(SAMPLE))
    if df.empty or len(df) < 1000:
        fail(f"Ingestion returned too few rows: {len(df)}")
    ok(f"Parsed {len(df):,} rows from sample file")
    ok(f"Quarters detected: {sorted(df['quarter'].unique())[0]} → {sorted(df['quarter'].unique())[-1]}")
    ok(f"Indicators: {len(df['indicator'].unique())}")

    db = str(ROOT / "data" / "labor.db")
    n = save_to_db(df, db, str(SAMPLE))
    ok(f"Wrote {n:,} rows to {db}")

    # ---------- 2. Validation ----------
    hdr("2. VALIDATION")
    from tools.validator import validate_dataset
    r = validate_dataset(db)
    ok(f"Validation ran; {len(r['flags'])} flag(s): {r['flags'][0][:80]}")
    ok(f"Summary: {r['summary']['total_rows']:,} rows, {len(r['summary']['quarters'])} quarters")

    # ---------- 3. Trend analysis ----------
    hdr("3. TREND ANALYSIS")
    from tools.trend_analyzer import analyze_trend, compare_cohorts, breakdown_by_dimension

    t = analyze_trend(db, "unemployment_rate", "Saudi", "Total")
    if not t["ok"]:
        fail("Trend analysis failed")
    ok(f"Saudi unemployment: {t['first_value']:.2f}% ({t['first_quarter']}) → "
       f"{t['latest_value']:.2f}% ({t['latest_quarter']}), trend: {t['overall_trend']}")
    ok(f"QoQ: {t['qoq_change']:+.2f}pp  YoY: {t['yoy_change']:+.2f}pp")

    c = compare_cohorts(db, "unemployment_rate", [
        {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
        {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
        {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
    ])
    ok(f"Cohort compare: {len(c['cohort_values'])} cohorts, {len(c['gaps'])} gaps")
    for label, val in c["cohort_values"].items():
        ok(f"    {label}: {val:.2f}%")

    b = breakdown_by_dimension(db, "unemployment_rate", "region", "Saudi", "Total")
    ok(f"Regional breakdown: {len(b['breakdown'])} regions, "
       f"highest={b['highest']}, lowest={b['lowest']}")

    # ---------- 4. Forecasting ----------
    hdr("4. FORECASTING")
    from tools.forecaster import forecast_indicator, summarize_forecast

    f = forecast_indicator(db, "unemployment_rate", "Saudi", "Total", horizon=4)
    if not f["ok"]:
        fail(f"Forecast failed: {f.get('error')}")
    ok(summarize_forecast(f))
    for q, bl, op, pe in zip(f["horizon_quarters"], f["baseline"],
                              f["optimistic"], f["pessimistic"]):
        ok(f"    {q}: baseline={bl:.2f}%, optimistic={op:.2f}%, pessimistic={pe:.2f}%")

    # Check monotonicity
    for bl, op, pe in zip(f["baseline"], f["optimistic"], f["pessimistic"]):
        if not (op <= bl <= pe):
            fail(f"Scenario order broken: optimistic={op}, baseline={bl}, pessimistic={pe}")
    ok("Scenario ordering correct (optimistic <= baseline <= pessimistic for unemployment)")

    # ---------- 5. RAG ----------
    hdr("5. RAG")
    from tools.rag import RAGStore

    corpus_dir = ROOT / "data" / "rag_corpus"
    if not any(corpus_dir.iterdir()):
        ok("Corpus empty, regenerating...")
        os.system(f"python3 {ROOT}/tools/generate_corpus.py")

    rag = RAGStore(backend="tfidf")
    nchunks = rag.build_from_directory(str(corpus_dir))
    ok(f"Indexed {nchunks} chunks from corpus")

    queries = [
        ("youth unemployment drivers", "Youth_Employment"),
        ("female labor force participation", "Female_LFP"),
        ("Vision 2030 targets", "Vision_2030"),
        ("regional disparities", "Regional"),
    ]
    for q, expected_doc in queries:
        res = rag.query(q, k=1)
        if not res["ok"]:
            fail(f"RAG failed for: {q}")
        top = res["results"][0]["doc_id"]
        if expected_doc not in top:
            print(f"  {YLW}! RAG: '{q}' returned {top}, expected containing '{expected_doc}'{RST}")
        else:
            ok(f"Query '{q}' → {top} (score {res['results'][0]['score']:.3f})")

    # ---------- 6. Report generation ----------
    hdr("6. REPORT GENERATION")
    from tools.report_generator import build_quarterly_report_md, build_quarterly_report_pdf
    rag_ctx = rag.search("Saudi labor market trends drivers", k=3)
    md = build_quarterly_report_md(db, rag_insights=rag_ctx)
    md_path = ROOT / "data" / "processed" / "quarterly_briefing.md"
    md_path.parent.mkdir(exist_ok=True, parents=True)
    md_path.write_text(md, encoding="utf-8")
    ok(f"Markdown: {md_path} ({len(md):,} chars)")

    pdf_path = ROOT / "data" / "processed" / "quarterly_briefing.pdf"
    build_quarterly_report_pdf(db, str(pdf_path), rag_insights=rag_ctx)
    size = pdf_path.stat().st_size
    ok(f"PDF: {pdf_path} ({size:,} bytes)")

    # ---------- 7. Agent (rule-based fallback) ----------
    hdr("7. AGENT (RULE-BASED FALLBACK)")
    from agent import build_agent, AgentContext
    ctx = AgentContext(db_path=db, rag_corpus_dir=str(corpus_dir),
                        output_dir=str(ROOT / "data" / "processed"))
    agent, mode = build_agent(ctx)
    ok(f"Agent built in '{mode}' mode")

    agent_queries = [
        "What's the Saudi unemployment trend?",
        "Compare Saudi male vs female unemployment",
        "Show Saudi unemployment by region",
        "Forecast unemployment for the next 4 quarters",
        "Why is youth unemployment elevated?",
        "Validate the data",
    ]
    for q in agent_queries:
        r = agent.chat(q)
        if not r.get("reply"):
            fail(f"Empty reply for: {q}")
        reply_preview = r["reply"][:100].replace("\n", " ")
        tools_used = ", ".join(t["tool"] for t in r.get("tool_calls", []))
        ok(f"Q: '{q}'")
        ok(f"   tools: [{tools_used}]")
        ok(f"   reply: {reply_preview}...")

    # ---------- 8. FastAPI app imports (syntax only — FastAPI not installed here) ----------
    hdr("8. FASTAPI APP (syntax check)")
    try:
        import ast
        with open(ROOT / "app.py") as f:
            ast.parse(f.read())
        ok("app.py parses as valid Python")
    except SyntaxError as e:
        fail(f"app.py has a syntax error: {e}")

    # ---------- Summary ----------
    hdr("RESULT")
    print(f"  {GRN}{BOLD}All smoke tests passed.{RST}")
    print(f"\n  Next step: install deps and launch the FastAPI server:")
    print(f"    {BOLD}pip install -r requirements.txt{RST}")
    print(f"    {BOLD}uvicorn app:app --host 0.0.0.0 --port 8000{RST}")
    print(f"    → Open http://localhost:8000\n")
    return failures


if __name__ == "__main__":
    sys.exit(main())

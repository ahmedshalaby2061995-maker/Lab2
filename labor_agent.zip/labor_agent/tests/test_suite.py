"""
Test suite for the Labor Market Analysis Agent POC.
Run:  pytest tests/ -v
"""
import os
import sqlite3
import tempfile
from pathlib import Path

import pandas as pd
import pytest

import sys
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from ingestion import (
    parse_quarter, infer_quarter_from_filename,
    ingest_gastat_xlsx, save_to_db, init_db
)
from tools.validator import validate_dataset
from tools.trend_analyzer import (
    analyze_trend, compare_cohorts, breakdown_by_dimension, get_time_series
)
from tools.forecaster import forecast_indicator, _holt_winters, _next_quarters
from tools.rag import RAGStore, _chunk_text


SAMPLE_FILE = str(ROOT / "sample_data" / "Labor_Market_Statistics_Q4_2025_EN__1_.xlsx")
TEST_DB = str(ROOT / "data" / "test_labor.db")


# ---------- Ingestion tests ----------

class TestIngestion:
    def test_parse_quarter_formats(self):
        assert parse_quarter("2023 Q1") == "2023-Q1"
        assert parse_quarter("2023Q4") == "2023-Q4"
        assert parse_quarter("Q2 2024") == "2024-Q2"
        assert parse_quarter("not a quarter") is None
        assert parse_quarter(None) is None
        assert parse_quarter(float("nan")) is None

    def test_infer_quarter_from_filename(self):
        assert infer_quarter_from_filename("Labor_Q4_2025.xlsx") == "2025-Q4"
        assert infer_quarter_from_filename("Labor_Market_Fourth_Quarter_2025.xlsx") == "2025-Q4"
        assert infer_quarter_from_filename("random.xlsx") is None

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_ingest_sample(self):
        df = ingest_gastat_xlsx(SAMPLE_FILE)
        assert not df.empty, "Should parse some rows"
        assert len(df) > 1000, f"Expected >1000 rows, got {len(df)}"
        # Required columns
        for col in ["quarter", "table_id", "indicator", "nationality", "sex", "value"]:
            assert col in df.columns
        # Sane values for rates
        rates = df[df["indicator"] == "unemployment_rate"]
        assert not rates.empty
        assert rates["value"].between(0, 100).all()
        # Expected quarters in time series
        ts = df[df["dimension"] == "time_series"]
        assert "2025-Q4" in ts["quarter"].unique()
        assert "2021-Q1" in ts["quarter"].unique()


# ---------- Validator tests ----------

class TestValidator:
    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_validate_clean_data(self, tmp_path):
        db = str(tmp_path / "v_test.db")
        df = ingest_gastat_xlsx(SAMPLE_FILE)
        save_to_db(df, db, SAMPLE_FILE)
        report = validate_dataset(db)
        assert "flags" in report
        assert "summary" in report
        assert report["summary"]["total_rows"] > 0
        assert len(report["summary"]["quarters"]) >= 20

    def test_validate_empty_db(self, tmp_path):
        db = str(tmp_path / "empty.db")
        init_db(db)
        report = validate_dataset(db)
        assert report["ok"] is False
        assert any("No data" in f for f in report["flags"])


# ---------- Trend analyzer tests ----------

class TestTrendAnalyzer:
    @pytest.fixture(scope="class")
    def db(self, tmp_path_factory):
        db_path = str(tmp_path_factory.mktemp("data") / "trend.db")
        df = ingest_gastat_xlsx(SAMPLE_FILE)
        save_to_db(df, db_path, SAMPLE_FILE)
        return db_path

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_get_time_series(self, db):
        df = get_time_series(db, "unemployment_rate", "Saudi", "Total")
        assert not df.empty
        assert len(df) >= 20
        # Sorted ascending
        quarters = df["quarter"].tolist()
        assert quarters == sorted(quarters)

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_analyze_trend_basic(self, db):
        r = analyze_trend(db, "unemployment_rate", "Saudi", "Total")
        assert r["ok"]
        assert r["indicator"] == "unemployment_rate"
        assert r["n_periods"] >= 20
        assert r["latest_quarter"] == "2025-Q4"
        # Saudi unemployment should have declined overall (2021 Q1 was ~12%, 2025 Q4 ~7%)
        assert r["overall_trend"] == "declining"
        # QoQ and YoY should be present
        assert r["qoq_change"] is not None
        assert r["yoy_change"] is not None

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_compare_cohorts(self, db):
        r = compare_cohorts(db, "unemployment_rate", [
            {"nationality": "Saudi", "sex": "Male", "label": "SM"},
            {"nationality": "Saudi", "sex": "Female", "label": "SF"},
        ])
        assert r["ok"]
        assert "SM" in r["cohort_values"]
        assert "SF" in r["cohort_values"]
        # Female rate should exceed male rate in 2025 Q4
        assert r["cohort_values"]["SF"] > r["cohort_values"]["SM"]
        assert len(r["gaps"]) == 1  # one pair

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_breakdown_by_region(self, db):
        r = breakdown_by_dimension(db, "unemployment_rate", "region", "Saudi", "Total")
        assert r["ok"]
        assert len(r["breakdown"]) >= 10  # 13 regions expected
        # Descending order
        values = [b["value"] for b in r["breakdown"]]
        assert values == sorted(values, reverse=True)


# ---------- Forecaster tests ----------

class TestForecaster:
    def test_holt_winters_trend_detection(self):
        # Clear declining trend
        values = [12, 11, 10, 9, 8, 7, 6, 5]
        import numpy as np
        fc, rmse = _holt_winters(np.array(values), horizon=2, seasonal_periods=4)
        # Should continue declining trend
        assert fc[0] < values[-1]

    def test_next_quarters(self):
        assert _next_quarters("2025-Q4", 2) == ["2026-Q1", "2026-Q2"]
        assert _next_quarters("2024-Q2", 3) == ["2024-Q3", "2024-Q4", "2025-Q1"]

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_forecast_unemployment(self, tmp_path):
        db = str(tmp_path / "fc.db")
        df = ingest_gastat_xlsx(SAMPLE_FILE)
        save_to_db(df, db, SAMPLE_FILE)
        r = forecast_indicator(db, "unemployment_rate", "Saudi", "Total", horizon=4)
        assert r["ok"]
        assert len(r["baseline"]) == 4
        assert len(r["optimistic"]) == 4
        assert len(r["pessimistic"]) == 4
        assert r["horizon_quarters"][0] == "2026-Q1"
        # All values should be in plausible range for a rate
        for v in r["baseline"] + r["optimistic"] + r["pessimistic"]:
            assert 0 <= v <= 100
        # Pessimistic should be >= baseline >= optimistic for unemployment
        for b, o, p in zip(r["baseline"], r["optimistic"], r["pessimistic"]):
            assert o <= b <= p, f"Scenario order broken at b={b} o={o} p={p}"


# ---------- RAG tests ----------

class TestRAG:
    def test_chunk_text(self):
        text = "Sentence one. Sentence two. Sentence three. " * 50
        chunks = _chunk_text(text, chunk_size=200, overlap=50)
        assert len(chunks) > 1
        for c in chunks:
            assert len(c) <= 300  # chunk_size + some tolerance

    def test_chunk_empty(self):
        assert _chunk_text("") == []
        assert _chunk_text("short") == []  # filtered by min length

    def test_rag_index_and_search(self, tmp_path):
        # Create minimal corpus
        corpus_dir = tmp_path / "corpus"
        corpus_dir.mkdir()
        (corpus_dir / "doc1.txt").write_text(
            "Youth unemployment in Saudi Arabia is elevated due to education "
            "mismatch, reservation wages, and lack of apprenticeship programs. "
            "The rate for ages 15-24 is typically 3x the overall rate. " * 10
        )
        (corpus_dir / "doc2.txt").write_text(
            "Female labor force participation has grown from 17% to 36% since 2016 "
            "due to legal reforms, sector openings, and childcare expansion. " * 10
        )
        rag = RAGStore(backend="tfidf")
        n = rag.build_from_directory(str(corpus_dir))
        assert n >= 2
        # Relevant query should surface the right doc
        result = rag.query("youth unemployment drivers", k=2)
        assert result["ok"]
        assert result["results"][0]["doc_id"] == "doc1.txt"


# ---------- Agent tests ----------

class TestAgent:
    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_agent_builds(self, tmp_path):
        # Set up a clean test environment
        db = str(tmp_path / "a.db")
        df = ingest_gastat_xlsx(SAMPLE_FILE)
        save_to_db(df, db, SAMPLE_FILE)
        corpus_dir = tmp_path / "corpus"
        corpus_dir.mkdir()
        (corpus_dir / "note.txt").write_text("Sample note. " * 50)

        from agent import AgentContext, build_agent
        ctx = AgentContext(db_path=db, rag_corpus_dir=str(corpus_dir),
                           output_dir=str(tmp_path / "out"))
        agent, kind = build_agent(ctx)
        # At minimum, the rule-based fallback should be available
        assert agent is not None
        assert kind in ("langchain+openai", "rule-based (fallback)")

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_rule_agent_trend_query(self, tmp_path):
        db = str(tmp_path / "a.db")
        df = ingest_gastat_xlsx(SAMPLE_FILE)
        save_to_db(df, db, SAMPLE_FILE)
        from agent import AgentContext, RuleBasedAgent
        ctx = AgentContext(db_path=db, rag_corpus_dir="data/rag_corpus",
                           output_dir=str(tmp_path / "out"))
        agent = RuleBasedAgent(ctx)
        r = agent.chat("What is the Saudi unemployment trend?")
        assert "reply" in r
        assert "Saudi" in r["reply"] or "saudi" in r["reply"].lower()
        assert len(r["tool_calls"]) >= 1

    @pytest.mark.skipif(not os.path.exists(SAMPLE_FILE), reason="Sample file required")
    def test_rule_agent_cohort_query(self, tmp_path):
        db = str(tmp_path / "a.db")
        df = ingest_gastat_xlsx(SAMPLE_FILE)
        save_to_db(df, db, SAMPLE_FILE)
        from agent import AgentContext, RuleBasedAgent
        ctx = AgentContext(db_path=db, rag_corpus_dir="data/rag_corpus",
                           output_dir=str(tmp_path / "out"))
        agent = RuleBasedAgent(ctx)
        r = agent.chat("Compare Saudi male vs female unemployment")
        assert "Saudi Male" in r["reply"]
        assert "Saudi Female" in r["reply"]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))

# Labor Market Analysis Agent — POC

> AI-powered agent for quarterly Saudi labor market analysis using GASTAT Labor Force Survey data.

Automates the workflow that a Central Team typically does by hand every quarter:
ingests GASTAT Excel releases, validates them, runs trend and cohort analysis,
produces baseline + scenario forecasts, retrieves context from prior studies
via RAG, and writes an executive-ready briefing (Markdown + PDF).

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Web UI (HTML/JS + Chart.js)                  │
│              Chat panel  ·  KPI cards  ·  Trend / Forecast charts    │
└──────────────────────────────┬──────────────────────────────────────┘
                               │ HTTP/JSON
┌──────────────────────────────▼──────────────────────────────────────┐
│                       FastAPI Backend (app.py)                       │
│   /api/chat · /api/upload · /api/summary · /api/report · /api/...    │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────────┐
│                  LangChain Agent (agent.py)                          │
│  Claude (Anthropic) — tool-calling loop                              │
│  Fallback: rule-based router (no API key required)                   │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
       ┌───────────────────────┼──────────────────────────┐
       │                       │                          │
       ▼                       ▼                          ▼
  ┌─────────┐          ┌───────────────┐          ┌─────────────┐
  │ tools/  │          │   SQLite DB   │          │  RAG Store  │
  │         │          │ (labor_facts, │          │ TF-IDF  or  │
  │ · ingestion         │  ingestion_   │          │ ChromaDB +  │
  │ · validator          │   log)        │          │ sentence-   │
  │ · trend_analyzer    │               │          │ transformers │
  │ · forecaster        └───────────────┘          └─────────────┘
  │ · rag
  │ · report_generator
  └─────────┘
```

## Tool layer (each independently testable)

| Tool | File | Does |
|---|---|---|
| **Ingestion** | `ingestion.py` | Parses GASTAT xlsx → normalized long-format table → SQLite. Handles the multi-header Saudi/Non-Saudi/Total × Male/Female/Total layout across 40+ sheets. |
| **Validator** | `tools/validator.py` | Range checks, duplicate detection, missing quarters, identity violations (e.g. employment ratio ≤ LFP), large QoQ jumps. |
| **Trend Analyzer** | `tools/trend_analyzer.py` | QoQ / YoY deltas, cohort compare with pairwise gaps, dimensional breakdowns (age/region/education). |
| **Forecaster** | `tools/forecaster.py` | Additive Holt-Winters (level + trend + seasonal) with linear fallback. Baseline + optimistic + pessimistic scenarios + 95% CIs. |
| **RAG** | `tools/rag.py` | Retrieval over prior studies, methodology notes, policy briefs. Pluggable backends: **TF-IDF** (zero deps, default) or **ChromaDB + sentence-transformers** (swap via `RAG_BACKEND=chroma`). |
| **Report Generator** | `tools/report_generator.py` | Full quarterly briefing in Markdown + PDF (reportlab). |

## Quick start

```bash
# 1. Clone / unzip into a directory, then:
cd labor_agent

# 2. (Recommended) virtualenv
python3 -m venv .venv
source .venv/bin/activate        # on Windows: .venv\Scripts\activate

# 3. Install
pip install -r requirements.txt

# 4. (Optional but recommended) set your Anthropic API key
cp .env.example .env
# edit .env and set ANTHROPIC_API_KEY=sk-ant-...

# 5. Seed data — ingest the included GASTAT Q4 2025 sample
python3 ingestion.py sample_data/Labor_Market_Statistics_Q4_2025_EN__1_.xlsx data/labor.db

# 6. Generate the RAG corpus (synthetic prior studies)
python3 tools/generate_corpus.py

# 7. Run the backend + UI
uvicorn app:app --reload --host 0.0.0.0 --port 8000

# Open http://localhost:8000
```

> **Without an API key:** the agent falls back to a deterministic rule-based router
> that still exercises every tool (trends, forecasts, RAG retrieval, report
> generation). This is useful for demoing the pipeline without LLM costs.

## Using the UI

**Chat panel (left):** Ask natural-language questions —
- *"What's the latest Saudi unemployment rate?"*
- *"Compare Saudi male vs female unemployment"*
- *"Show Saudi unemployment by region"*
- *"Forecast unemployment for the next 4 quarters"*
- *"Why is youth unemployment elevated?"* (triggers RAG)
- *"Generate the quarterly briefing"* (produces the PDF + Markdown)

**Upload zone (below chat):** Drop a new GASTAT quarterly xlsx. The agent will:
1. Parse all indicators and quarters
2. Upsert into the SQLite DB (idempotent)
3. Run validation and flag any inconsistencies
4. Refresh the dashboard

**Dashboard (right):** Live KPI cards (Saudi unemployment, employment-to-pop, LFP),
trend line, cohort bar chart, forecast projection with scenarios, validation panel,
and a one-click quarterly report generator.

## API reference

| Endpoint | Purpose |
|---|---|
| `POST /api/chat` | Send a message to the agent. Body: `{"message": "...", "history": [...]}` |
| `POST /api/upload` | Upload a new GASTAT xlsx (multipart). Returns parse summary + validation. |
| `GET /api/summary` | Dashboard payload: KPIs, cohorts, forecast, validation flags. |
| `GET /api/indicators` | List all available indicators × dimensions + quarters. |
| `GET /api/series` | Get a single time series. `?indicator=&nationality=&sex=` |
| `GET /api/trend` | Structured trend analysis. |
| `GET /api/breakdown` | Dimensional breakdown. `?indicator=&dimension=` |
| `GET /api/forecast` | Baseline + scenario forecast. |
| `GET /api/cohorts` | Standard 4-cohort comparison. |
| `GET /api/validate` | Run validation checks. |
| `POST /api/report` | Generate the full MD + PDF briefing. |
| `GET /api/download/{filename}` | Download a generated report file. |
| `GET /api/health` | Liveness probe. |

FastAPI auto-generates interactive docs at `http://localhost:8000/docs`.

## Adding your own prior-study documents (RAG)

Drop `.txt`, `.md`, or `.pdf` files into `data/rag_corpus/`. On next server
restart (or by calling `rag.build_from_directory()` again) they are chunked and
indexed. The pluggable backend means you can switch from TF-IDF to production
embedding search by setting `RAG_BACKEND=chroma` and installing `chromadb` +
`sentence-transformers`.

## Extending

**To add a new indicator:** add an entry to `TABLE_META` in `ingestion.py`.

**To add a new analysis tool:** write a function in `tools/` that returns a
JSON-serializable dict with `ok` + result fields, then:
1. Add a `TOOL_SCHEMAS` entry in `agent.py`
2. Add a dispatch case in `execute_tool()`
3. (Optional) Add a fallback route in `RuleBasedAgent.chat()`

**To swap the LLM:** the agent uses LangChain, so any `BaseChatModel` with
tool-calling works. Change `ChatAnthropic(...)` in `agent.py` to e.g. `ChatOpenAI`.

**To use a different database:** `ingestion.py` uses standard SQL. Change the
connection string and schema DDL to migrate to Postgres / DuckDB / etc.

## Data notes

The included sample is **GASTAT Labor Force Survey, Saudi Arabia, Q4 2025**,
spanning 20 quarters (2021 Q1 → 2025 Q4). The RAG corpus contains **8 synthetic
documents** representing the types of materials a Central Team would typically
reference (GASTAT methodology notes, Vision 2030 policy briefs, regional studies,
youth employment analyses, etc). Replace these with your real documents for
production use.

Forecasts use a hand-rolled additive Holt-Winters implementation to avoid the
statsmodels dependency. For production, consider swapping in Prophet,
statsmodels, or a proper time-series library.

## Testing

```bash
# Smoke test each tool independently
python3 ingestion.py sample_data/Labor_Market_Statistics_Q4_2025_EN__1_.xlsx
python3 -m tools.validator
python3 -m tools.trend_analyzer
python3 -m tools.forecaster
python3 -m tools.rag data/rag_corpus "youth unemployment"
python3 -m tools.report_generator

# Smoke test the agent
python3 agent.py "What's the Saudi unemployment trend?"
python3 agent.py "Compare Saudi male vs female unemployment"
python3 agent.py "Forecast unemployment for 4 quarters"

# Run pytest suite
pytest tests/ -v
```

## Known limitations (this is a POC)

- RAG corpus is synthetic; swap in real prior studies for production.
- Forecasting uses Holt-Winters; consider Prophet / SARIMA / LSTM for production.
- Agent has basic history support; no long-term memory or cross-session state.
- No authentication — add OAuth / API keys before deploying beyond the Central Team.
- Single-tenant SQLite — for scale, migrate to Postgres with proper indexing.
- No multi-user concurrency controls on report generation.

## License

Provided as a proof-of-concept. Adapt freely to your organization's requirements.

/**
 * PwC RDU Design System — barrel export.
 *
 * Lets consumers do:
 *   import { Button, Card, Badge, BrandMark } from "@pwc/rdu-design-system";
 *   import { cn } from "@pwc/rdu-design-system";
 *
 * If you'd rather tree-shake aggressively, import from the deep paths:
 *   import { Button } from "@pwc/rdu-design-system/components/ui/button";
 */

// ─── Utilities ───────────────────────────────────────────────────────────
export { cn, formatDate, relativeTime, initials } from "./lib/utils";

// ─── Brand ───────────────────────────────────────────────────────────────
export { BrandMark } from "./components/BrandMark";

// ─── Primitives ──────────────────────────────────────────────────────────
export * from "./components/ui/alert";
export * from "./components/ui/avatar";
export * from "./components/ui/badge";
export * from "./components/ui/button";
export * from "./components/ui/card";
export * from "./components/ui/dialog";
export * from "./components/ui/dropdown-menu";
export * from "./components/ui/input";
export * from "./components/ui/label";
export * from "./components/ui/popover";
export * from "./components/ui/progress";
export * from "./components/ui/scroll-area";
export * from "./components/ui/select";
export * from "./components/ui/separator";
export * from "./components/ui/skeleton";
export * from "./components/ui/table";
export * from "./components/ui/tabs";
export * from "./components/ui/textarea";
export * from "./components/ui/tooltip";

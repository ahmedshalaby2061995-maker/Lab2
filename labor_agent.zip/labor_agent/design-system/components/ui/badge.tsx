import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "../../lib/utils";

/**
 * PwC badge — capsule with a small leading vertical bar. The bar is the
 * distinguishing flourish: nobody else's design system has it, and it nods
 * to the PwC graphic mark.
 */
const badgeVariants = cva(
  "relative inline-flex items-center gap-1 rounded-full pl-3 pr-2.5 py-0.5 text-[11px] font-medium tracking-tight transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 before:absolute before:left-1.5 before:top-1.5 before:bottom-1.5 before:w-[2px] before:rounded-full",
  {
    variants: {
      variant: {
        default:
          "bg-secondary text-secondary-foreground before:bg-primary",
        secondary:
          "bg-muted text-foreground before:bg-foreground/40",
        destructive:
          "bg-destructive/10 text-destructive before:bg-destructive",
        success:
          "bg-success/10 text-success before:bg-success",
        warning:
          "bg-warning/15 text-warning-foreground before:bg-warning",
        outline:
          "border border-border bg-transparent text-foreground before:bg-muted-foreground/40",
        subtle:
          "bg-muted text-muted-foreground before:bg-muted-foreground/40",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { badgeVariants };

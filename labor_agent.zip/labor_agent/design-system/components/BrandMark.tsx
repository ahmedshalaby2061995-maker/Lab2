import * as React from "react";
import { cn } from "../lib/utils";

interface Props {
  /** Display size in pixels for the square mark. Default 36. */
  size?: number;
  /** When true, renders the mark + the "PwC RDU" wordmark + tagline. */
  showWordmark?: boolean;
  /** Tagline shown beneath the wordmark. Default "Training Assessment". */
  tagline?: string;
  /** Wordmark text. Default "PwC RDU". */
  wordmark?: string;
  className?: string;
  /** Override the foreground color of the wordmark (e.g. for dark sidebars). */
  wordmarkColor?: string;
}

/**
 * PwC RDU brand mark — a single-letter glyph in the primary orange,
 * with an inverted accent bar on the left edge. Distinct from generic
 * shield / lock iconography that ships in icon libraries.
 */
export function BrandMark({
  size = 36,
  showWordmark = true,
  tagline = "Training Assessment",
  wordmark = "PwC RDU",
  className,
  wordmarkColor,
}: Props) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <div
        className="relative flex items-center justify-center"
        style={{ width: size, height: size }}
      >
        <div className="absolute inset-0 rounded-sm bg-primary" />
        <div className="absolute inset-y-0 left-0 w-[14%] min-w-[2px] rounded-l-sm bg-primary-foreground/90" />
        <span
          className="relative font-display font-bold leading-none text-primary-foreground"
          style={{ fontSize: size * 0.45 }}
        >
          {wordmark[0] ?? "P"}
        </span>
      </div>
      {showWordmark && (
        <div className="leading-tight" style={wordmarkColor ? { color: wordmarkColor } : undefined}>
          <p className="font-display text-base font-semibold">{wordmark}</p>
          {tagline && (
            <p className="text-[10px] uppercase tracking-[0.15em] opacity-55">{tagline}</p>
          )}
        </div>
      )}
    </div>
  );
}

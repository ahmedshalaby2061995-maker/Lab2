/** @type {import('tailwindcss').Config} */
const pwcPreset = require("@pwc/rdu-design-system/tailwind.preset.js");

module.exports = {
  presets: [pwcPreset],
  content: [
    "./index.html",
    "./src/**/*.{ts,tsx}",
    // IMPORTANT — Tailwind needs to see the design system source so it can
    // compile the utility classes those components reference. Without this
    // line, you'll see unstyled components in production builds.
    "./node_modules/@pwc/rdu-design-system/components/**/*.{ts,tsx}",
  ],
};

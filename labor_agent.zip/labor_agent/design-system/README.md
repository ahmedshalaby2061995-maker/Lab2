# PwC RDU Design System

Warm-cream surfaces · deep-navy ink · PwC orange accent · Fraunces serif display + Inter body. Built on **Tailwind CSS v3** + **Radix UI** primitives.

The system was extracted from the PwC RDU Training Assessment Platform and is intended for reuse across other internal PwC engagement tools.

---

## What's in this folder

```
design-system/
├── README.md                      # this file
├── package.json                   # name, peer deps, exports map
├── index.ts                       # barrel export — `import { Button } from "@pwc/rdu-design-system"`
├── tailwind.preset.js             # importable Tailwind preset (colors, fonts, shadows, radii)
├── tokens.json                    # W3C Design Tokens — importable into Figma via Tokens Studio
├── styles/
│   ├── fonts.css                  # @import urls for Inter + Fraunces
│   └── tokens.css                 # CSS custom properties (light + dark)
├── lib/
│   └── utils.ts                   # cn(), formatDate(), relativeTime(), initials()
├── components/
│   ├── BrandMark.tsx              # the PwC "P" mark + wordmark + tagline
│   └── ui/                        # 19 Radix-based primitives
│       ├── alert.tsx
│       ├── avatar.tsx
│       ├── badge.tsx              # ⚑ signature: capsule + leading vertical bar
│       ├── button.tsx
│       ├── card.tsx               # no border, soft elevation on cream
│       ├── dialog.tsx
│       ├── dropdown-menu.tsx
│       ├── input.tsx
│       ├── label.tsx
│       ├── popover.tsx
│       ├── progress.tsx
│       ├── scroll-area.tsx
│       ├── select.tsx
│       ├── separator.tsx
│       ├── skeleton.tsx
│       ├── table.tsx
│       ├── tabs.tsx
│       ├── textarea.tsx
│       └── tooltip.tsx
└── examples/
    ├── app.css                       # CSS entry point template for consumers
    └── example-tailwind.config.js    # Tailwind config template for consumers
```

---

## Three ways to consume it

### Option A · Copy the folder into a new project (simplest)

```bash
# from your new React+Vite+Tailwind project root:
cp -R /path/to/RDU-Training-Agent/design-system ./design-system

# install peer deps (next section)

# point Tailwind at the design system
# (edit your tailwind.config.js per ./design-system/examples/example-tailwind.config.js)

# import the styles in your app entry CSS
# (per ./design-system/examples/app.css)

# use it in code
import { Button, Card, BrandMark } from "./design-system";
```

**Pros:** zero infrastructure. **Cons:** no version pinning, manual to update.

### Option B · Standalone git repo

```bash
# 1. push design-system/ to its own repo, e.g. github.com/pwc/rdu-design-system
# 2. tag a release (v0.1.0)
# 3. install in any consuming project:
npm install git+ssh://git@github.com/pwc/rdu-design-system.git#v0.1.0
```

**Pros:** versioned, single source of truth, fixes propagate via `npm update`. **Cons:** needs a git repo + you tag releases.

### Option C · Private npm registry

```bash
# 1. configure npm to publish to PwC's private registry (or GitHub Packages)
npm publish

# 2. install normally:
npm install @pwc/rdu-design-system
```

**Pros:** standard `npm install`, semver, types. **Cons:** needs registry auth.

---

## Setup in a consuming project

### 1. Install peer dependencies

```bash
npm install \
  react react-dom \
  tailwindcss tailwindcss-animate \
  class-variance-authority clsx tailwind-merge \
  lucide-react \
  @radix-ui/react-avatar @radix-ui/react-dialog \
  @radix-ui/react-dropdown-menu @radix-ui/react-label \
  @radix-ui/react-popover @radix-ui/react-progress \
  @radix-ui/react-scroll-area @radix-ui/react-select \
  @radix-ui/react-separator @radix-ui/react-slot \
  @radix-ui/react-tabs @radix-ui/react-tooltip
```

### 2. Wire up Tailwind

```js
// tailwind.config.js
const pwcPreset = require("@pwc/rdu-design-system/tailwind.preset.js");

module.exports = {
  presets: [pwcPreset],
  content: [
    "./index.html",
    "./src/**/*.{ts,tsx}",
    // IMPORTANT — Tailwind needs to see the design system source:
    "./node_modules/@pwc/rdu-design-system/components/**/*.{ts,tsx}",
  ],
};
```

### 3. Import styles in your app entry

```css
/* src/index.css */
@import "@pwc/rdu-design-system/styles/fonts.css";

@tailwind base;
@tailwind components;
@tailwind utilities;

@import "@pwc/rdu-design-system/styles/tokens.css";
```

### 4. Use the components

```tsx
import { Button, Card, CardContent, BrandMark, Badge } from "@pwc/rdu-design-system";

export function App() {
  return (
    <div className="bg-background min-h-screen p-8">
      <BrandMark />
      <h1 className="font-display text-4xl mt-6">Welcome.</h1>

      <Card className="mt-6">
        <CardContent className="p-6 space-y-4">
          <Badge>System ready</Badge>
          <p>This card uses warm cream surface with soft elevation.</p>
          <Button>Primary action</Button>
        </CardContent>
      </Card>
    </div>
  );
}
```

---

## What makes it distinctive

| Element | Treatment |
|---|---|
| **Surface** | Warm cream `#FAF8F5` (not stark white). White cards float on it via soft shadow + ring — no hairline border. |
| **Ink** | Deep navy `#1A2332` (not flat black). Used for body text, headings, and the sidebar background. |
| **Accent** | PwC orange `#D04A02`. Appears on primary CTAs, badge bars, sidebar active indicators, focus rings. |
| **Display type** | **Fraunces** variable serif for `<h1>` and `<h2>` — this is the most-different single move from shadcn-default systems that use Inter for everything. |
| **Body type** | Inter Variable. |
| **Badge motif** | Capsule pill with a 2px leading vertical color bar (`before:` pseudo-element). The bar is the recurring brand flourish — also appears on active sidebar items, on KPI card edges, on the brand mark itself. |
| **Cards** | No border. White-on-cream contrast + custom `shadow-soft` token tuned for warm backgrounds. |
| **Iconography** | Lucide React (Phosphor-adjacent). Swap for Phosphor Bold or Tabler Outline if you want more visual weight. |

---

## Design tokens (for design tools)

`tokens.json` follows the [W3C Design Tokens Community Group](https://design-tokens.github.io/community-group/format/) format. Import into Figma via the **Tokens Studio** plugin (https://tokens.studio):

1. Open Tokens Studio in Figma
2. Settings → Sync providers → JSON file → upload `tokens.json`
3. Apply tokens to layers via the Tokens Studio panel

Same JSON also works with [Style Dictionary](https://amzn.github.io/style-dictionary/) for cross-platform export (iOS/Android/etc.).

---

## Theming for a different engagement

If you reskin for a non-PwC use case, override the CSS custom properties on `:root`. No component code needs to change.

```css
:root {
  --primary: 220 70% 50%;          /* swap to a different brand color */
  --secondary: 215 33% 14%;        /* keep navy or change */
  --background: 36 27% 97%;        /* keep cream or go neutral */
  /* ... */
}
```

The `tailwind.preset.js` reads from these vars via `hsl(var(--…))`, so changing the vars updates every `bg-primary` / `text-primary` / etc. across the app instantly.

---

## What's intentionally NOT in this folder

These belong to the RDU app, not the design system, and would need to be rebuilt for a different domain:

- App-specific layouts (`AppShell`, dashboards, workbench split-views)
- Domain components (`RecommendationBadge`, `ScoreTable`, `SourcePane`, `ChatPanel`)
- Auth client (Better Auth wiring)
- Routing, queries, business logic

If you want any of those as starting points for another tool, copy them out of `frontend/src/` and adapt — they all import only from this design system, so they'll work in any project that has the system installed.

---

## Versioning + changelog

Currently `0.1.0`. When you make breaking changes (rename a token, change a component prop), bump the major version and note it here.

| Version | Changes |
|---------|---------|
| 0.1.0 | Initial extraction from RDU Training Assessment Platform: 19 primitives, BrandMark, tokens.css + .json, Tailwind preset. |

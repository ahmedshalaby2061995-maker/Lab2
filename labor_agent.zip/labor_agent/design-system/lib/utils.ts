import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/** `cn(...inputs)` — combine class strings with Tailwind-aware deduplication. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Locale-friendly date format used across PwC RDU surfaces. */
export function formatDate(d: string | number | Date): string {
  return new Date(d).toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** "5m ago" / "2h ago" / "3d ago" / fallback to a date. */
export function relativeTime(d: string | number | Date): string {
  const ts =
    typeof d === "string" || typeof d === "number"
      ? new Date(d).getTime()
      : d.getTime();
  const diffSec = (Date.now() - ts) / 1000;
  if (diffSec < 60) return "just now";
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  if (diffSec < 604800) return `${Math.floor(diffSec / 86400)}d ago`;
  return new Date(ts).toLocaleDateString();
}

/** First-character initials for avatar fallbacks. */
export function initials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return (parts[0]![0]! + parts[parts.length - 1]![0]!).toUpperCase();
}

"""
Database module — PostgreSQL only.
====================================
This is a clean PostgreSQL-native implementation. SQLite is gone.

Why?
----
The original codebase was a local POC with SQLite. We've now migrated to
PostgreSQL for two reasons:
  1. Cloud Run is stateless — SQLite's local file disappears on every restart.
  2. SQLite ↔ PostgreSQL SQL incompatibilities (AUTOINCREMENT vs SERIAL,
     placeholders, etc.) made the hybrid adapter brittle.

Both local development and Cloud Run now use PostgreSQL. Locally that means
Docker Compose spins up Postgres on localhost:5432. In production it's
Cloud SQL via the Cloud SQL Proxy.

Configuration
-------------
A single environment variable controls everything:

    DATABASE_URL=postgresql://user:pass@host:port/dbname

Local dev (after `docker compose up -d postgres`):
    DATABASE_URL=postgresql://labor:labor@localhost:5432/labor_agent

Cloud Run (Unix socket via Cloud SQL Proxy):
    DATABASE_URL=postgresql://user:pass@/labor_agent?host=/cloudsql/PROJECT:REGION:INSTANCE

Usage
-----
    from db import connect, bulk_insert

    con = connect()
    cur = con.cursor()
    cur.execute("SELECT * FROM labor_facts WHERE quarter = %s", ("2025-Q4",))
    rows = cur.fetchall()
    con.close()

    # Bulk insert — 10-100x faster than row-by-row over the network
    bulk_insert(con, "labor_facts", rows_as_dicts,
                on_conflict_keys=["quarter", "table_id", "indicator", "dimension",
                                  "category", "nationality", "sex"])

Placeholder note
----------------
Use psycopg2's `%s` placeholders for new code. For backward compatibility,
this module still accepts the SQLite-style `?` placeholders — they're
rewritten transparently.
"""
from __future__ import annotations

import os
import re
import sys
from contextlib import contextmanager
from typing import Iterable, Optional, Sequence

import psycopg2
import psycopg2.extras
import psycopg2.extensions


def _get_database_url() -> str:
    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError(
            "DATABASE_URL is not set.\n\n"
            "For local development, run:\n"
            "  docker compose up -d postgres\n"
            "Then add to your shell or .env:\n"
            "  DATABASE_URL=postgresql://labor:labor@localhost:5432/labor_agent\n"
        )
    if not url.startswith(("postgresql://", "postgres://")):
        raise RuntimeError(
            f"DATABASE_URL must be a PostgreSQL URL (got: {url[:30]}...). "
            "SQLite is no longer supported."
        )
    return url


# ── Placeholder rewriter — backward compat for SQL written with `?` ────

_PLACEHOLDER_RE = re.compile(r"\?(?=(?:[^']*'[^']*')*[^']*$)")


def _rewrite_sql(sql: str) -> str:
    """Convert sqlite3-style `?` placeholders to psycopg2-style `%s`."""
    if "?" not in sql:
        return sql
    return _PLACEHOLDER_RE.sub("%s", sql)


# ── Cursor and connection wrappers ─────────────────────────────────────

class _Cursor:
    """Thin shim around psycopg2 cursor that auto-rewrites `?` to `%s`
    and provides executescript() for multi-statement DDL."""

    def __init__(self, cur):
        self._cur = cur

    def execute(self, sql: str, params: Optional[Sequence] = None):
        sql = _rewrite_sql(sql)
        if params is None:
            return self._cur.execute(sql)
        return self._cur.execute(sql, params)

    def executemany(self, sql: str, seq_of_params: Iterable):
        sql = _rewrite_sql(sql)
        return self._cur.executemany(sql, seq_of_params)

    def executescript(self, script: str):
        """Run multi-statement DDL (psycopg2 doesn't have this natively)."""
        script = _rewrite_sql(script)
        for stmt in script.split(";"):
            stmt = stmt.strip()
            if stmt:
                self._cur.execute(stmt)

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()

    def fetchmany(self, size=None):
        return self._cur.fetchmany(size) if size else self._cur.fetchmany()

    @property
    def rowcount(self):
        return self._cur.rowcount

    @property
    def description(self):
        return self._cur.description

    def close(self):
        return self._cur.close()

    def __iter__(self):
        return iter(self._cur)


class _Connection:
    """Wraps a psycopg2 connection to expose a sqlite3-like interface."""

    def __init__(self, raw):
        self._raw = raw

    def cursor(self):
        return _Cursor(self._raw.cursor())

    def execute(self, sql: str, params: Optional[Sequence] = None) -> _Cursor:
        cur = self.cursor()
        cur.execute(sql, params)
        return cur

    def executescript(self, script: str):
        cur = self.cursor()
        cur.executescript(script)
        return cur

    def commit(self):
        return self._raw.commit()

    def rollback(self):
        return self._raw.rollback()

    def close(self):
        return self._raw.close()

    @property
    def raw(self):
        """Expose the underlying psycopg2 connection — needed for pandas.read_sql_query()."""
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            self.commit()
        else:
            self.rollback()
        self.close()


# ── Public API ─────────────────────────────────────────────────────────

def connect(_unused_path: Optional[str] = None) -> _Connection:
    """Open a PostgreSQL connection.

    The path argument is ignored — it exists only for backward compatibility
    with callers that previously wrote `connect(db_path)`. The connection
    target always comes from DATABASE_URL.
    """
    url = _get_database_url()
    raw = psycopg2.connect(url)
    return _Connection(raw)


@contextmanager
def open_conn():
    """Context-manager form for cleaner new code:

        with open_conn() as con:
            cur = con.cursor()
            cur.execute("SELECT ...")
    """
    con = connect()
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def pandas_read_sql(sql: str, con: _Connection, params: Optional[Sequence] = None):
    """pandas.read_sql_query() helper that handles `?` placeholders."""
    import pandas as pd
    sql = _rewrite_sql(sql)
    return pd.read_sql_query(sql, con.raw, params=params)


def bulk_insert(con: _Connection,
                table: str,
                rows: list,
                columns: Optional[list] = None,
                on_conflict_keys: Optional[list] = None,
                update_cols: Optional[list] = None) -> int:
    """
    Fast bulk INSERT using psycopg2.extras.execute_values.

    Sends all rows in a single query — 10-100x faster than row-by-row
    inserts, especially over the network to Cloud SQL.

    Args:
        con: a _Connection from connect()
        table: target table name
        rows: list of dicts OR list of tuples. If dicts, `columns` is inferred.
        columns: list of column names (required if rows are tuples)
        on_conflict_keys: if set, adds `ON CONFLICT (...) DO UPDATE SET ...`
                          for idempotent upserts.
        update_cols: explicit list of columns to update on conflict. If None,
                     all non-key columns are updated.

    Returns: number of rows affected.
    """
    if not rows:
        return 0

    if isinstance(rows[0], dict):
        if columns is None:
            columns = list(rows[0].keys())
        values = [tuple(r.get(c) for c in columns) for r in rows]
    else:
        if columns is None:
            raise ValueError("columns is required when rows are tuples")
        values = [tuple(r) for r in rows]

    col_list = ", ".join(columns)
    sql = f"INSERT INTO {table} ({col_list}) VALUES %s"

    if on_conflict_keys:
        if update_cols is None:
            update_cols = [c for c in columns if c not in on_conflict_keys]
        if update_cols:
            set_clause = ", ".join(f"{c} = EXCLUDED.{c}" for c in update_cols)
            conflict_target = ", ".join(on_conflict_keys)
            sql += f" ON CONFLICT ({conflict_target}) DO UPDATE SET {set_clause}"
        else:
            conflict_target = ", ".join(on_conflict_keys)
            sql += f" ON CONFLICT ({conflict_target}) DO NOTHING"

    cur = con.raw.cursor()
    psycopg2.extras.execute_values(cur, sql, values, page_size=500)
    cur.close()
    # Note: psycopg2.execute_values reports cur.rowcount for only the LAST page,
    # not the total. Since ON CONFLICT DO UPDATE/NOTHING touches every input row,
    # the real "rows affected" is just len(values).
    return len(values)


def init_schema(con: Optional[_Connection] = None, schema_path: Optional[str] = None) -> None:
    """Apply schema.sql to the database. Idempotent (CREATE TABLE IF NOT EXISTS)."""
    if schema_path is None:
        here = os.path.dirname(os.path.abspath(__file__))
        schema_path = os.path.join(here, "schema.sql")

    if not os.path.exists(schema_path):
        raise FileNotFoundError(f"schema.sql not found at {schema_path}")

    with open(schema_path) as f:
        script = f.read()

    own_con = False
    if con is None:
        con = connect()
        own_con = True

    try:
        con.executescript(script)
        con.commit()
    finally:
        if own_con:
            con.close()


# ── CLI ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "init":
        print("Initializing schema...")
        init_schema()
        print("Schema applied.")
    elif len(sys.argv) > 1 and sys.argv[1] == "check":
        try:
            con = connect()
            v = con.execute("SELECT version()").fetchone()
            print(f"OK — connected to: {v[0][:60]}...")
            con.close()
        except Exception as e:
            print(f"FAIL — {type(e).__name__}: {e}")
            sys.exit(1)
    else:
        print("Usage:")
        print("  python db.py init    # apply schema.sql to the database")
        print("  python db.py check   # verify DATABASE_URL is set and reachable")

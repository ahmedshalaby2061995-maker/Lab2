# Labor Market Analysis Agent

AI-augmented quarterly intelligence for the Saudi labor market. Built on GASTAT Labor Force Survey data, with a FastAPI backend, LangChain agent, and a chat + dashboard UI.

**This is the PostgreSQL-native rebuild.** SQLite is no longer supported — local development and Cloud Run both use PostgreSQL, so SQL behavior matches across environments and cloud deployment is just a change of `DATABASE_URL`.

---

## Architecture at a glance

```
┌─────────────┐    ┌─────────────┐    ┌─────────────────┐
│  Browser    │───▶│  FastAPI    │───▶│  LangChain      │
│  (chat +    │    │  (app.py)   │    │  agent          │
│   dashboard)│    │             │    │  + 8 tools      │
└─────────────┘    └──────┬──────┘    └────────┬────────┘
                          │                     │
                          ▼                     ▼
                   ┌──────────────┐      ┌──────────────┐
                   │ PostgreSQL   │      │  OpenAI API  │
                   │ (Cloud SQL   │      │  (any OpenAI │
                   │  or local    │      │  -compatible │
                   │  Docker)     │      │  endpoint)   │
                   └──────────────┘      └──────────────┘
```

---

## Quick start (local development)

### Prerequisites

- Python 3.10+
- Docker (for the local PostgreSQL)
- An OpenAI API key (or compatible endpoint)

### 1. Start PostgreSQL

```bash
docker compose up -d postgres
```

This starts a Postgres 15 container on `localhost:5432` and auto-applies `schema.sql` on the first run. Same engine and version as Cloud SQL in production.

### 2. Install Python dependencies

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

### 3. Set environment variables

Copy `.env.example` to `.env` and fill in your `OPENAI_API_KEY`:

```bash
cp .env.example .env
```

Then export them for your shell:

```powershell
# Windows PowerShell
$env:DATABASE_URL = "postgresql://labor:labor@localhost:5432/labor_agent"
$env:OPENAI_API_KEY = "sk-..."
```

```bash
# macOS / Linux
export DATABASE_URL="postgresql://labor:labor@localhost:5432/labor_agent"
export OPENAI_API_KEY="sk-..."
```

### 4. Bootstrap the database

One command applies the schema and ingests the bundled sample data:

```bash
python bootstrap.py
```

Expected output:
```
✓ Connected on attempt 1
✓ Schema applied
✓ Wrote 5,109 rows to labor_facts in 0.8s
✓ Wrote 99 rows to register_facts (2025-Q4) in 0.2s

  labor_facts          5,109 rows
  register_facts          99 rows
  ingestion_log            2 rows
  km_documents             0 rows

  MoHRSD KPIs (2025-Q4):
    KPI 1: Total Unemployment Rate     3.53%
    KPI 2: Saudi Unemployment Rate     7.24%
    KPI 3: Total LFP Rate             67.43%
    KPI 4: Saudi LFP Rate             49.52%
    KPI 5: Highly Skilled Saudis      42.37%
    KPI 6: Highly Skilled Expats       9.57%
```

### 5. Run the app

```bash
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

Open http://localhost:8000 → sign in with `admin` / `admin`.

---

## Project layout

```
labor_agent/
├── app.py                  # FastAPI backend: 14 REST endpoints
├── agent.py                # LangChain agent + rule-based fallback
├── ingestion.py            # GASTAT xlsx → labor_facts (bulk inserts)
├── db.py                   # PostgreSQL adapter (with bulk_insert helper)
├── bootstrap.py            # One-command local setup
├── schema.sql              # All tables — single source of truth
├── docker-compose.yml      # Local Postgres
├── Dockerfile              # Production container for Cloud Run
├── requirements.txt
├── .env.example
│
├── tools/
│   ├── kpi_calculator.py   # 6 MoHRSD KPIs
│   ├── trend_analyzer.py   # QoQ / YoY / cohort comparisons
│   ├── forecaster.py       # Holt-Winters with scenarios
│   ├── validator.py        # Data quality checks
│   ├── rag.py              # TF-IDF retrieval over corpus
│   ├── report_generator.py # PDF + Markdown briefing
│   └── generate_corpus.py
│
├── templates/
│   ├── login.html
│   ├── app.html            # Chat + dashboard SPA
│   └── index.html
│
├── data/
│   ├── rag_corpus/         # Knowledge base for RAG
│   └── processed/          # Generated reports
│
└── sample_data/            # Bundled sample xlsx files
```

---

## Key endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/login` / `/api/logout` | Session auth |
| `GET`  | `/api/me` | Current user info |
| `GET`  | `/api/health` | Liveness probe |
| `POST` | `/api/chat` | Chat with the agent |
| `POST` | `/api/upload` | Ingest a GASTAT xlsx (auto-detects LFS vs Register-based) |
| `GET`  | `/api/kpis` | **6 MoHRSD KPIs** in one call |
| `GET`  | `/api/kpi-history/{id}` | Historical series for sparklines |
| `GET`  | `/api/summary` | Dashboard payload |
| `GET`  | `/api/trend` / `/api/breakdown` / `/api/forecast` / `/api/cohorts` | Drill-down |
| `GET`  | `/api/validate` | Data quality flags |
| `POST` | `/api/report` | Generate quarterly briefing (PDF + Markdown) |
| `GET`  | `/api/km/documents` / `POST` / `DELETE` | Knowledge management |
| `GET`  | `/docs` | OpenAPI auto-generated docs |

---

## Deploying to Cloud Run (Dammam, Saudi Arabia)

The only change between local and production is `DATABASE_URL`. See the original [`DEPLOYMENT.md`](DEPLOYMENT.md) for the full Cloud Run + Cloud SQL walkthrough. The key differences in this rebuild:

1. **No SQLite → PostgreSQL migration step needed** — you've been on PostgreSQL all along.
2. **Bulk inserts** make ingestion fast over the network (under 5 seconds for 5,109 rows against Cloud SQL).
3. **Single unified database** — KM, labor_facts, register_facts, ingestion_log all in one place.
4. **Schema is in `schema.sql`** — apply once with `python db.py init` (or auto-applied by Docker Compose locally).

The deployment commands stay the same — `gcloud builds submit`, `gcloud run deploy`, `--set-secrets`, etc.

---

## Common commands

```bash
# Start local Postgres
docker compose up -d postgres

# Apply schema (only needed if you change schema.sql; first start does it automatically)
python db.py init

# Verify the database is reachable
python db.py check

# Connect with psql (Windows requires PostgreSQL client installed)
psql postgresql://labor:labor@localhost:5432/labor_agent

# Reset the local database (deletes all data)
docker compose down -v

# Re-bootstrap from scratch
docker compose up -d postgres
python bootstrap.py

# Tail the app's logs
docker compose logs -f postgres   # for the database
# (uvicorn logs print to your terminal in dev mode)
```

---

## Troubleshooting

### `RuntimeError: DATABASE_URL is not set`
Export the env var first. See step 3 of the quickstart.

### `connection refused on port 5432`
Postgres isn't running. Check `docker compose ps`. If the container is healthy but you still can't connect, the port may be taken — try `docker compose logs postgres`.

### `psycopg2.errors.UndefinedTable`
Schema hasn't been applied. Run `python db.py init` or `python bootstrap.py`.

### Ingestion is slow against Cloud SQL
Make sure you're using the bulk-insert path. The old row-by-row insertion was the cause of the slowness — the rebuild uses `psycopg2.extras.execute_values()` which is 50-100x faster.

### KPIs 5 & 6 show "N/A — Data not ingested"
You haven't ingested the Register-based xlsx yet. Either run `python bootstrap.py` (does it automatically) or upload via the chat UI.

---

## What changed in this rebuild vs the previous version

| Item | Before | Now |
|---|---|---|
| Database | SQLite + adapter rewriting SQL | PostgreSQL only |
| Schema location | Inline in `ingestion.py` + `tools/kpi_calculator.py` + `app.py` | Single `schema.sql` |
| KM database | Separate `km.db` SQLite file | Same Postgres database as everything else |
| Insert speed | Row-by-row (5,109 rows = 5+ minutes against Cloud SQL) | Bulk insert (under 5 seconds) |
| Local-to-cloud parity | Different DB engine | Identical (Docker Postgres ↔ Cloud SQL) |
| `AUTOINCREMENT` vs `SERIAL` workaround | DDL rewriter in `db.py` | Native PostgreSQL types |
| Local setup | `pip install`, run uvicorn | `docker compose up -d postgres`, `python bootstrap.py`, run uvicorn |

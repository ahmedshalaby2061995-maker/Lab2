#!/usr/bin/env python3
"""
Bootstrap script — one-command local setup
============================================
What this does:
  1. Verifies PostgreSQL is reachable (DATABASE_URL must be set)
  2. Applies schema.sql (creates labor_facts, register_facts, ingestion_log, km_documents)
  3. Ingests the bundled GASTAT LFS sample data (5,109 rows)
  4. Ingests the bundled Register-based sample data (~99 rows for KPIs 5 & 6)
  5. Prints a summary of what's in the database

Run with:
  python bootstrap.py

Prerequisites:
  - Docker running: `docker compose up -d postgres`
  - DATABASE_URL exported: `export DATABASE_URL=postgresql://labor:labor@localhost:5432/labor_agent`
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path


HERE = Path(__file__).resolve().parent

SAMPLE_GASTAT = HERE / "sample_data" / "Labor_Market_Statistics_Q4_2025_EN__1_.xlsx"
SAMPLE_REGISTER = HERE / "sample_data" / "Register-based_Labour_Market_Statistics_Q4_2025_EN.xlsx"


def wait_for_db(max_seconds: int = 30):
    """Poll the database every second until it's reachable, or fail."""
    print("Checking database connection...")
    from db import connect
    for i in range(max_seconds):
        try:
            con = connect()
            con.execute("SELECT 1").fetchone()
            con.close()
            print(f"  ✓ Connected on attempt {i+1}")
            return
        except Exception as e:
            if i == 0:
                print(f"  Waiting for PostgreSQL... ({type(e).__name__})")
            time.sleep(1)
    print(f"  ✗ Could not connect to database after {max_seconds}s")
    print(f"\nTroubleshooting:")
    print(f"  1. Is DATABASE_URL set? Current: {os.environ.get('DATABASE_URL', '(not set)')}")
    print(f"  2. Is the database running? `docker compose ps`")
    print(f"  3. Try: `docker compose logs postgres`")
    sys.exit(1)


def apply_schema():
    print("\nApplying schema.sql...")
    from db import init_schema
    init_schema()
    print("  ✓ Schema applied (idempotent — safe to re-run)")


def ingest_gastat():
    if not SAMPLE_GASTAT.exists():
        print(f"\n  ! GASTAT sample not found at {SAMPLE_GASTAT}, skipping")
        return
    print(f"\nIngesting GASTAT LFS sample: {SAMPLE_GASTAT.name}...")
    from ingestion import ingest_gastat_xlsx, save_to_db
    t0 = time.time()
    df = ingest_gastat_xlsx(str(SAMPLE_GASTAT))
    print(f"  Parsed {len(df):,} rows in {time.time()-t0:.1f}s")
    t0 = time.time()
    n = save_to_db(df, None, str(SAMPLE_GASTAT))
    print(f"  ✓ Wrote {n:,} rows to labor_facts in {time.time()-t0:.1f}s")


def ingest_register():
    if not SAMPLE_REGISTER.exists():
        print(f"\n  ! Register-based sample not found at {SAMPLE_REGISTER}, skipping")
        return
    print(f"\nIngesting Register-based sample: {SAMPLE_REGISTER.name}...")
    from tools.kpi_calculator import ingest_register_based_xlsx
    t0 = time.time()
    result = ingest_register_based_xlsx(str(SAMPLE_REGISTER), None)
    if result.get("ok"):
        print(f"  ✓ Wrote {result['records_written']} rows to register_facts "
              f"({result['snapshot_quarter']}) in {time.time()-t0:.1f}s")
    else:
        print(f"  ✗ Register-based ingestion failed: {result.get('error')}")


def show_summary():
    print("\n" + "=" * 60)
    print("Database summary")
    print("=" * 60)
    from db import connect
    con = connect()
    try:
        for table in ("labor_facts", "register_facts", "ingestion_log", "km_documents"):
            try:
                n = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                print(f"  {table:<20} {n:>8,} rows")
            except Exception as e:
                print(f"  {table:<20} ERROR: {e}")

        # Show latest quarters
        q = con.execute("SELECT DISTINCT quarter FROM labor_facts ORDER BY quarter DESC LIMIT 5").fetchall()
        if q:
            quarters = ", ".join(r[0] for r in q)
            print(f"\n  Recent quarters: {quarters}")

        # Show MoHRSD KPIs if available
        try:
            from tools.kpi_calculator import compute_mohrsd_kpis
            kpis = compute_mohrsd_kpis(None)
            if kpis.get("ok"):
                print(f"\n  MoHRSD KPIs ({kpis['quarter']}):")
                for k in kpis["kpis"]:
                    val = f"{k['value']:.2f}%" if k['value'] is not None else "N/A"
                    print(f"    KPI {k['id']}: {k['name']:<28} {val:>8}")
        except Exception as e:
            print(f"\n  (KPI summary skipped: {e})")
    finally:
        con.close()
    print("\n" + "=" * 60)
    print("Next steps:")
    print("  - Run the app:    uvicorn app:app --host 0.0.0.0 --port 8000")
    print("  - Open browser:   http://localhost:8000")
    print("  - Sign in:        admin / admin")
    print("=" * 60)


if __name__ == "__main__":
    if not os.environ.get("DATABASE_URL"):
        print("DATABASE_URL is not set.\n")
        print("Quick fix:")
        print("  1. Start Postgres:  docker compose up -d postgres")
        print("  2. Export the URL:")
        print("     Windows (PowerShell):")
        print('       $env:DATABASE_URL = "postgresql://labor:labor@localhost:5432/labor_agent"')
        print("     macOS / Linux:")
        print('       export DATABASE_URL="postgresql://labor:labor@localhost:5432/labor_agent"')
        print("  3. Re-run:  python bootstrap.py")
        sys.exit(1)

    wait_for_db()
    apply_schema()
    ingest_gastat()
    ingest_register()
    show_summary()

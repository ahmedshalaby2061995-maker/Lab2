"""
MoHRSD Quarterly KPI Calculator
================================
Computes the 6 KPIs required for the Ministry of Human Resources and Social
Development (MoHRSD) quarterly report.

KPI #  Name                         Source                          Column
─────  ───────────────────────────  ──────────────────────────────  ──────
  1    Total Unemployment Rate      GASTAT LFS Table 2-1            Col J (idx 9)  — Total/Total
  2    Saudi Unemployment Rate      GASTAT LFS Table 2-1            Col D (idx 3)  — Saudi/Total
  3    Total LFP Rate               GASTAT LFS Table 5-1            Col J (idx 9)  — Total/Total
  4    Saudi LFP Rate               GASTAT LFS Table 5-1            Col D (idx 3)  — Saudi/Total
  5    Highly Skilled Saudis %      Register-based LMS Table 3-5    Col D (idx 3)  — (Managers+Professionals)/Total
  6    Highly Skilled Expats %      Register-based LMS Table 3-5    Col G (idx 6)  — (Managers+Professionals)/Total

Data stored in two SQLite tables:
  - labor_facts        (from GASTAT LFS ingestion — already exists)
  - register_facts     (from Register-based LMS ingestion — new)
"""
from __future__ import annotations

import os
from db import connect
from typing import Dict, Any, Optional, List

import pandas as pd


# ── Schema for register-based data ──────────────────────────────────────

REGISTER_SCHEMA = """
-- The register_facts table is now defined in /schema.sql and applied by
-- `python db.py init`. This constant is kept for backward-compat only; if
-- anyone still calls init_register_db() it just re-applies the central
-- schema (idempotent).
"""


def init_register_db(_db_path: Optional[str] = None) -> None:
    """Idempotent — applies the full schema.sql. Backward-compat wrapper."""
    from db import init_schema
    init_schema()


# ── Parse and ingest Register-based Table 3-5 ──────────────────────────

def ingest_register_based_xlsx(path: str, db_path: str,
                                snapshot_quarter: Optional[str] = None) -> Dict[str, Any]:
    """
    Parse GASTAT Register-based Labor Market Statistics xlsx.
    Extracts Table 3-5 (occupation × nationality × sex) and stores in register_facts.
    Returns ingestion summary.
    """
    from datetime import datetime
    import re

    # Detect quarter from filename if not provided
    if not snapshot_quarter:
        name = os.path.basename(path)
        m = re.search(r'Q([1-4])[_\s]*(20\d{2})|(20\d{2})[_\s]*Q([1-4])', name, re.IGNORECASE)
        if m:
            if m.group(1):
                snapshot_quarter = f"{m.group(2)}-Q{m.group(1)}"
            else:
                snapshot_quarter = f"{m.group(3)}-Q{m.group(4)}"
        else:
            snapshot_quarter = "unknown"

    sheets = pd.read_excel(path, sheet_name=None, header=None)

    # Find table 3-5
    df = None
    for name in sheets:
        if name.strip() in ("3-5", "3.5"):
            df = sheets[name]
            break
    if df is None:
        return {"ok": False, "error": "Table 3-5 not found in file."}

    # Parse occupation rows (rows 7-16 in the standard GASTAT layout)
    # Row structure: occupation | Saudi M | Saudi F | Saudi T | NonSaudi M | NonSaudi F | NonSaudi T | Total M | Total F | Total T
    records = []
    now = datetime.utcnow().isoformat()
    source = os.path.basename(path)

    occupation_rows = {}
    for i in range(7, len(df)):
        occ = str(df.iloc[i, 0]).strip() if pd.notna(df.iloc[i, 0]) else ""
        if not occ or occ.lower().startswith(("source", "note", "total", "*")):
            if occ.lower() == "total":
                occupation_rows["Total"] = i
            continue
        occupation_rows[occ] = i

    # Also capture the Total row
    for i in range(7, len(df)):
        occ = str(df.iloc[i, 0]).strip() if pd.notna(df.iloc[i, 0]) else ""
        if occ.lower() == "total":
            occupation_rows["Total"] = i
            break

    nat_sex_map = [
        (1, "Saudi", "Male"),
        (2, "Saudi", "Female"),
        (3, "Saudi", "Total"),
        (4, "Non-Saudi", "Male"),
        (5, "Non-Saudi", "Female"),
        (6, "Non-Saudi", "Total"),
        (7, "Total", "Male"),
        (8, "Total", "Female"),
        (9, "Total", "Total"),
    ]

    for occ_name, row_idx in occupation_rows.items():
        for col_idx, nat, sex in nat_sex_map:
            val = df.iloc[row_idx, col_idx]
            if pd.notna(val):
                try:
                    count = int(float(val))
                except (TypeError, ValueError):
                    continue
                records.append({
                    "quarter": snapshot_quarter,
                    "occupation": occ_name,
                    "nationality": nat,
                    "sex": sex,
                    "count": count,
                    "source_file": source,
                    "ingested_at": now,
                })

    if not records:
        return {"ok": False, "error": "No occupation data parsed from Table 3-5."}

    # Write to DB — bulk insert in one round-trip (fast even over network)
    from db import bulk_insert
    init_register_db()
    con = connect()
    try:
        written = bulk_insert(
            con, "register_facts", records,
            columns=["quarter", "occupation", "nationality", "sex",
                     "count", "source_file", "ingested_at"],
            on_conflict_keys=["quarter", "occupation", "nationality", "sex"],
        )
        con.commit()
    finally:
        con.close()

    return {
        "ok": True,
        "snapshot_quarter": snapshot_quarter,
        "occupations_parsed": list(occupation_rows.keys()),
        "records_written": written,
        "total_records": len(records),
    }


# ── KPI computation ────────────────────────────────────────────────────

def compute_mohrsd_kpis(db_path: str, quarter: Optional[str] = None) -> Dict[str, Any]:
    """
    Compute all 6 MoHRSD KPIs for a given quarter. If quarter is None, uses
    the latest available quarter from each source.

    Returns:
      {
        "ok": True,
        "quarter": "2025-Q4",
        "kpis": [
          {"id": 1, "name": "...", "value": 3.53, "unit": "%", "source": "...", "formula": "..."},
          ...
        ]
      }
    """
    con = connect(db_path)

    # ── KPIs 1-4: from labor_facts ──────────────────────────────────────
    kpis = []

    # Find the latest quarter in labor_facts if not specified
    lfs_quarter = quarter
    if not lfs_quarter:
        row = con.execute(
            "SELECT MAX(quarter) FROM labor_facts WHERE indicator='unemployment_rate' AND dimension='time_series'"
        ).fetchone()
        lfs_quarter = row[0] if row and row[0] else None

    if lfs_quarter:
        # KPI 1: Total Unemployment Rate
        row = con.execute("""
            SELECT value FROM labor_facts
            WHERE indicator='unemployment_rate' AND dimension='time_series'
              AND nationality='Total' AND sex='Total' AND quarter=?
        """, (lfs_quarter,)).fetchone()
        kpis.append({
            "id": 1,
            "name": "Total Unemployment Rate",
            "value": round(row[0], 2) if row else None,
            "unit": "%",
            "source": "GASTAT LFS Table 2-1, Col J",
            "formula": "Unemployed Total / Labor Force Total × 100",
            "quarter": lfs_quarter,
        })

        # KPI 2: Saudi Unemployment Rate
        row = con.execute("""
            SELECT value FROM labor_facts
            WHERE indicator='unemployment_rate' AND dimension='time_series'
              AND nationality='Saudi' AND sex='Total' AND quarter=?
        """, (lfs_quarter,)).fetchone()
        kpis.append({
            "id": 2,
            "name": "Saudi Unemployment Rate",
            "value": round(row[0], 2) if row else None,
            "unit": "%",
            "source": "GASTAT LFS Table 2-1, Col D",
            "formula": "Unemployed Saudi / Saudi Labor Force × 100",
            "quarter": lfs_quarter,
        })

        # KPI 3: Total LFP Rate
        row = con.execute("""
            SELECT value FROM labor_facts
            WHERE indicator='labor_force_participation' AND dimension='time_series'
              AND nationality='Total' AND sex='Total' AND quarter=?
        """, (lfs_quarter,)).fetchone()
        kpis.append({
            "id": 3,
            "name": "Total LFP Rate",
            "value": round(row[0], 2) if row else None,
            "unit": "%",
            "source": "GASTAT LFS Table 5-1, Col J",
            "formula": "Total Labor Force / Working-Age Population Total × 100",
            "quarter": lfs_quarter,
        })

        # KPI 4: Saudi LFP Rate
        row = con.execute("""
            SELECT value FROM labor_facts
            WHERE indicator='labor_force_participation' AND dimension='time_series'
              AND nationality='Saudi' AND sex='Total' AND quarter=?
        """, (lfs_quarter,)).fetchone()
        kpis.append({
            "id": 4,
            "name": "Saudi LFP Rate",
            "value": round(row[0], 2) if row else None,
            "unit": "%",
            "source": "GASTAT LFS Table 5-1, Col D",
            "formula": "Saudi Labor Force / Saudi Working-Age Population × 100",
            "quarter": lfs_quarter,
        })
    else:
        for i in range(1, 5):
            kpis.append({"id": i, "name": ["Total Unemployment Rate", "Saudi Unemployment Rate",
                                             "Total LFP Rate", "Saudi LFP Rate"][i-1],
                          "value": None, "unit": "%", "source": "GASTAT LFS (not ingested)",
                          "formula": "", "quarter": None})

    # ── KPIs 5-6: from register_facts ───────────────────────────────────

    # Check if register_facts table exists
    has_register = False
    try:
        con.execute("SELECT 1 FROM register_facts LIMIT 1")
        has_register = True
    except:
        pass

    reg_quarter = quarter
    if has_register and not reg_quarter:
        row = con.execute("SELECT MAX(quarter) FROM register_facts").fetchone()
        reg_quarter = row[0] if row and row[0] else None

    if has_register and reg_quarter:
        # KPI 5: Highly Skilled Saudis
        managers = con.execute("""
            SELECT count FROM register_facts
            WHERE quarter=? AND occupation='Managers' AND nationality='Saudi' AND sex='Total'
        """, (reg_quarter,)).fetchone()
        professionals = con.execute("""
            SELECT count FROM register_facts
            WHERE quarter=? AND occupation='Professionals' AND nationality='Saudi' AND sex='Total'
        """, (reg_quarter,)).fetchone()
        total = con.execute("""
            SELECT count FROM register_facts
            WHERE quarter=? AND occupation='Total' AND nationality='Saudi' AND sex='Total'
        """, (reg_quarter,)).fetchone()

        if managers and professionals and total and total[0] > 0:
            hs_saudi = (managers[0] + professionals[0]) / total[0] * 100
            kpis.append({
                "id": 5,
                "name": "Highly Skilled Saudis",
                "value": round(hs_saudi, 2),
                "unit": "%",
                "source": "Register-based LMS Table 3-5, Col D",
                "formula": f"(Managers {managers[0]:,} + Professionals {professionals[0]:,}) / Total {total[0]:,} × 100",
                "quarter": reg_quarter,
            })
        else:
            kpis.append({"id": 5, "name": "Highly Skilled Saudis", "value": None,
                          "unit": "%", "source": "Register-based LMS Table 3-5, Col D",
                          "formula": "(Managers + Professionals) / Total Saudi Workers × 100",
                          "quarter": reg_quarter})

        # KPI 6: Highly Skilled Expats
        managers = con.execute("""
            SELECT count FROM register_facts
            WHERE quarter=? AND occupation='Managers' AND nationality='Non-Saudi' AND sex='Total'
        """, (reg_quarter,)).fetchone()
        professionals = con.execute("""
            SELECT count FROM register_facts
            WHERE quarter=? AND occupation='Professionals' AND nationality='Non-Saudi' AND sex='Total'
        """, (reg_quarter,)).fetchone()
        total = con.execute("""
            SELECT count FROM register_facts
            WHERE quarter=? AND occupation='Total' AND nationality='Non-Saudi' AND sex='Total'
        """, (reg_quarter,)).fetchone()

        if managers and professionals and total and total[0] > 0:
            hs_expat = (managers[0] + professionals[0]) / total[0] * 100
            kpis.append({
                "id": 6,
                "name": "Highly Skilled Expats",
                "value": round(hs_expat, 2),
                "unit": "%",
                "source": "Register-based LMS Table 3-5, Col G",
                "formula": f"(Managers {managers[0]:,} + Professionals {professionals[0]:,}) / Total {total[0]:,} × 100",
                "quarter": reg_quarter,
            })
        else:
            kpis.append({"id": 6, "name": "Highly Skilled Expats", "value": None,
                          "unit": "%", "source": "Register-based LMS Table 3-5, Col G",
                          "formula": "(Managers + Professionals) / Total Non-Saudi Workers × 100",
                          "quarter": reg_quarter})
    else:
        kpis.append({"id": 5, "name": "Highly Skilled Saudis", "value": None, "unit": "%",
                      "source": "Register-based LMS (not ingested)", "formula": "", "quarter": None})
        kpis.append({"id": 6, "name": "Highly Skilled Expats", "value": None, "unit": "%",
                      "source": "Register-based LMS (not ingested)", "formula": "", "quarter": None})

    con.close()

    # Determine the reference quarter (use the most common across KPIs)
    ref_quarter = lfs_quarter or reg_quarter or "unknown"

    return {
        "ok": True,
        "quarter": ref_quarter,
        "kpis": kpis,
        "summary": _summarize_kpis(kpis, ref_quarter),
    }


def _summarize_kpis(kpis: List[Dict], quarter: str) -> str:
    """Generate a narrative summary of all 6 KPIs for the agent."""
    lines = [f"MoHRSD Quarterly KPIs — {quarter}:\n"]
    for k in kpis:
        val = f"{k['value']:.2f}{k['unit']}" if k['value'] is not None else "N/A (data not ingested)"
        lines.append(f"  KPI {k['id']}: {k['name']} = {val}")
        if k['value'] is not None and k.get('formula'):
            lines.append(f"         Formula: {k['formula']}")
            lines.append(f"         Source:  {k['source']}")
    return "\n".join(lines)


# ── Historical trend across quarters ────────────────────────────────────

def get_kpi_history(db_path: str, kpi_id: int) -> Dict[str, Any]:
    """Get the historical series for a specific KPI across all available quarters."""
    con = connect(db_path)

    if kpi_id in (1, 2, 3, 4):
        indicator_map = {
            1: ("unemployment_rate", "Total", "Total"),
            2: ("unemployment_rate", "Saudi", "Total"),
            3: ("labor_force_participation", "Total", "Total"),
            4: ("labor_force_participation", "Saudi", "Total"),
        }
        indicator, nat, sex = indicator_map[kpi_id]
        df = pd.read_sql_query("""
            SELECT quarter, value FROM labor_facts
            WHERE indicator=%s AND dimension='time_series' AND nationality=%s AND sex=%s AND category='All'
            ORDER BY quarter
        """, con.raw, params=(indicator, nat, sex))
        con.close()
        if df.empty:
            return {"ok": False, "error": f"No history for KPI {kpi_id}."}
        return {
            "ok": True,
            "kpi_id": kpi_id,
            "series": df.astype(object).where(pd.notna(df), None).to_dict(orient="records"),
        }

    elif kpi_id in (5, 6):
        nationality = "Saudi" if kpi_id == 5 else "Non-Saudi"
        try:
            quarters = [r[0] for r in con.execute(
                "SELECT DISTINCT quarter FROM register_facts ORDER BY quarter"
            ).fetchall()]
        except:
            con.close()
            return {"ok": False, "error": "Register-based data not ingested."}

        series = []
        for q in quarters:
            mgr = con.execute(
                "SELECT count FROM register_facts WHERE quarter=? AND occupation='Managers' AND nationality=? AND sex='Total'",
                (q, nationality)).fetchone()
            pro = con.execute(
                "SELECT count FROM register_facts WHERE quarter=? AND occupation='Professionals' AND nationality=? AND sex='Total'",
                (q, nationality)).fetchone()
            tot = con.execute(
                "SELECT count FROM register_facts WHERE quarter=? AND occupation='Total' AND nationality=? AND sex='Total'",
                (q, nationality)).fetchone()
            if mgr and pro and tot and tot[0] > 0:
                series.append({"quarter": q, "value": round((mgr[0] + pro[0]) / tot[0] * 100, 2)})
        con.close()
        return {"ok": True, "kpi_id": kpi_id, "series": series}

    return {"ok": False, "error": f"Unknown KPI ID: {kpi_id}"}


if __name__ == "__main__":
    import sys
    import json

    db = sys.argv[1] if len(sys.argv) > 1 else "data/labor.db"

    # If a register-based xlsx is provided, ingest it first
    if len(sys.argv) > 2:
        reg_path = sys.argv[2]
        print(f"Ingesting register-based file: {reg_path}")
        result = ingest_register_based_xlsx(reg_path, db)
        print(json.dumps(result, indent=2, default=str))
        print()

    # Compute all 6 KPIs
    kpis = compute_mohrsd_kpis(db)
    print(kpis["summary"])

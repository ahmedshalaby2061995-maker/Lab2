"""
Report Generator Tool
=====================
Produces executive-ready narrative reports in Markdown and PDF formats.
Pulls from the trend analyzer, forecaster, and RAG tools to assemble a
full quarterly briefing.
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
)

from tools.trend_analyzer import analyze_trend, compare_cohorts, breakdown_by_dimension
from tools.forecaster import forecast_indicator, summarize_forecast
from tools.validator import validate_dataset


# --- Markdown report generator ---

def build_quarterly_report_md(db_path: str, reference_quarter: Optional[str] = None,
                              rag_insights: Optional[List[Dict]] = None) -> str:
    """Build a Markdown-formatted executive briefing for the latest available quarter."""
    from db import connect
    con = connect(db_path)
    cur = con.cursor()
    latest = reference_quarter or cur.execute(
        "SELECT MAX(quarter) FROM labor_facts"
    ).fetchone()[0]
    con.close()

    lines: List[str] = []
    lines.append(f"# Saudi Arabia Labor Market — Quarterly Briefing\n")
    lines.append(f"**Reference Period:** {latest}  ")
    lines.append(f"**Prepared:** {datetime.utcnow().strftime('%Y-%m-%d')}  ")
    lines.append(f"**Source:** GASTAT Labor Force Survey + Internal Analysis Agent\n\n")

    # --- 1. Executive Summary ---
    ur = analyze_trend(db_path, "unemployment_rate", "Saudi", "Total")
    emp = analyze_trend(db_path, "employment_to_population", "Saudi", "Total")
    lfp = analyze_trend(db_path, "labor_force_participation", "Saudi", "Total")

    lines.append("## 1. Executive Summary\n")
    if ur.get("ok"):
        lines.append(
            f"- **Saudi unemployment rate** stands at **{ur['latest_value']:.2f}%** "
            f"in {ur['latest_quarter']}, "
            f"**{'+' if ur['qoq_change'] and ur['qoq_change']>=0 else ''}{ur['qoq_change']:.2f}pp** QoQ and "
            f"**{'+' if ur['yoy_change'] and ur['yoy_change']>=0 else ''}{ur['yoy_change']:.2f}pp** YoY. "
            f"Overall {ur['overall_trend']} trajectory since {ur['first_quarter']} "
            f"(period high: {ur['max_value']:.2f}% in {ur['max_quarter']}; "
            f"period low: {ur['min_value']:.2f}% in {ur['min_quarter']})."
        )
    if emp.get("ok"):
        lines.append(
            f"- **Saudi employment-to-population ratio**: **{emp['latest_value']:.2f}%** "
            f"({'+' if emp['qoq_change'] and emp['qoq_change']>=0 else ''}{emp['qoq_change']:.2f}pp QoQ; "
            f"{'+' if emp['yoy_change'] and emp['yoy_change']>=0 else ''}{emp['yoy_change']:.2f}pp YoY)."
        )
    if lfp.get("ok"):
        lines.append(
            f"- **Saudi labor force participation rate**: **{lfp['latest_value']:.2f}%** "
            f"({'+' if lfp['qoq_change'] and lfp['qoq_change']>=0 else ''}{lfp['qoq_change']:.2f}pp QoQ; "
            f"{'+' if lfp['yoy_change'] and lfp['yoy_change']>=0 else ''}{lfp['yoy_change']:.2f}pp YoY)."
        )
    lines.append("")

    # --- 2. Cohort comparison ---
    lines.append("## 2. Cohort Benchmarks (Latest Quarter)\n")
    cohort = compare_cohorts(db_path, "unemployment_rate", [
        {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
        {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
        {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
        {"nationality": "Total", "sex": "Total", "label": "National Total"},
    ])
    if cohort.get("ok"):
        lines.append("| Cohort | Unemployment Rate |")
        lines.append("|---|---:|")
        for k, v in cohort["cohort_values"].items():
            lines.append(f"| {k} | {v:.2f}% |")
        lines.append("")
        lines.append("**Key gaps:**")
        for g in cohort["gaps"]:
            lines.append(f"- {g['pair']}: {g['gap']:+.2f}pp")
        lines.append("")

    # --- 3. Dimensional breakdowns ---
    lines.append("## 3. Structural Breakdowns\n")
    for dim_label, dim_key in [("Age Group", "age_group"), ("Education", "education"),
                               ("Administrative Region", "region")]:
        b = breakdown_by_dimension(db_path, "unemployment_rate", dim_key, "Saudi", "Total")
        if b.get("ok"):
            lines.append(f"### Saudi Unemployment by {dim_label} — {b['quarter']}\n")
            lines.append(f"| {dim_label} | Rate |")
            lines.append("|---|---:|")
            for r in b["breakdown"]:
                lines.append(f"| {r['category']} | {r['value']:.2f}% |")
            lines.append(f"\n**Highest:** {b['highest']} · **Lowest:** {b['lowest']}\n")

    # --- 4. Forecast ---
    lines.append("## 4. Forecast (Next 4 Quarters)\n")
    f = forecast_indicator(db_path, "unemployment_rate", "Saudi", "Total", horizon=4)
    if f.get("ok"):
        lines.append(f"*{summarize_forecast(f)}*\n")
        lines.append("| Quarter | Baseline | Optimistic | Pessimistic | Lower 95% | Upper 95% |")
        lines.append("|---|---:|---:|---:|---:|---:|")
        for q, b, o, p, l, u in zip(f["horizon_quarters"], f["baseline"], f["optimistic"],
                                     f["pessimistic"], f["lower_95"], f["upper_95"]):
            lines.append(f"| {q} | {b:.2f}% | {o:.2f}% | {p:.2f}% | {l:.2f}% | {u:.2f}% |")
        lines.append("")

    # --- 5. Qualitative context (from RAG) ---
    if rag_insights:
        lines.append("## 5. Qualitative Context\n")
        lines.append("Drawing on prior economic studies and policy briefs:\n")
        for i, ins in enumerate(rag_insights[:5], 1):
            lines.append(f"**{i}. From {ins.get('doc_id','Unknown source')}**:")
            lines.append(f"> {ins.get('text','')[:300]}...\n")

    # --- 6. Data validation ---
    val = validate_dataset(db_path)
    lines.append("## 6. Data Validation\n")
    if val["flags"]:
        for f_ in val["flags"]:
            lines.append(f"- {f_}")
    lines.append("")

    lines.append("---\n*Generated by the Labor Market Analysis Agent. Figures are "
                 "preliminary and may be revised in subsequent quarters per GASTAT practice.*")
    return "\n".join(lines)


# --- PDF report generator ---

def build_quarterly_report_pdf(db_path: str, out_path: str,
                               reference_quarter: Optional[str] = None,
                               rag_insights: Optional[List[Dict]] = None) -> str:
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    from db import connect
    con = connect()
    cur = con.cursor()
    latest = reference_quarter or cur.execute(
        "SELECT MAX(quarter) FROM labor_facts"
    ).fetchone()[0]
    con.close()

    doc = SimpleDocTemplate(out_path, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm,
                             topMargin=2*cm, bottomMargin=2*cm,
                             title=f"Saudi Labor Market Briefing — {latest}",
                             author="Labor Market Agent")
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="H1Custom", parent=styles["Heading1"],
                               textColor=colors.HexColor("#1a3a5c"), spaceAfter=12))
    styles.add(ParagraphStyle(name="H2Custom", parent=styles["Heading2"],
                               textColor=colors.HexColor("#2a5a8c"), spaceAfter=8, spaceBefore=14))
    styles.add(ParagraphStyle(name="BodyCustom", parent=styles["BodyText"],
                               fontSize=10, leading=14, spaceAfter=6))
    styles.add(ParagraphStyle(name="Meta", parent=styles["BodyText"],
                               fontSize=9, textColor=colors.grey))

    story: List = []

    # Header
    story.append(Paragraph(f"Saudi Arabia Labor Market — Quarterly Briefing", styles["H1Custom"]))
    story.append(Paragraph(f"Reference Period: <b>{latest}</b>", styles["Meta"]))
    story.append(Paragraph(f"Prepared: {datetime.utcnow().strftime('%Y-%m-%d')}", styles["Meta"]))
    story.append(Paragraph("Source: GASTAT Labor Force Survey + Internal Analysis Agent", styles["Meta"]))
    story.append(Spacer(1, 0.3*cm))

    # 1. Executive summary
    story.append(Paragraph("1. Executive Summary", styles["H2Custom"]))
    ur = analyze_trend(db_path, "unemployment_rate", "Saudi", "Total")
    emp = analyze_trend(db_path, "employment_to_population", "Saudi", "Total")
    lfp = analyze_trend(db_path, "labor_force_participation", "Saudi", "Total")
    bullets = []
    if ur.get("ok"):
        bullets.append(
            f"<b>Unemployment rate (Saudi):</b> {ur['latest_value']:.2f}% in {ur['latest_quarter']} "
            f"({ur['qoq_change']:+.2f}pp QoQ; {ur['yoy_change']:+.2f}pp YoY). "
            f"Overall {ur['overall_trend']} since {ur['first_quarter']}."
        )
    if emp.get("ok"):
        bullets.append(
            f"<b>Employment-to-population (Saudi):</b> {emp['latest_value']:.2f}% "
            f"({emp['qoq_change']:+.2f}pp QoQ; {emp['yoy_change']:+.2f}pp YoY)."
        )
    if lfp.get("ok"):
        bullets.append(
            f"<b>Labor force participation (Saudi):</b> {lfp['latest_value']:.2f}% "
            f"({lfp['qoq_change']:+.2f}pp QoQ; {lfp['yoy_change']:+.2f}pp YoY)."
        )
    for b in bullets:
        story.append(Paragraph("• " + b, styles["BodyCustom"]))
    story.append(Spacer(1, 0.2*cm))

    # 2. Cohort comparison table
    story.append(Paragraph("2. Cohort Benchmarks (Latest Quarter)", styles["H2Custom"]))
    cohort = compare_cohorts(db_path, "unemployment_rate", [
        {"nationality": "Saudi", "sex": "Male", "label": "Saudi Male"},
        {"nationality": "Saudi", "sex": "Female", "label": "Saudi Female"},
        {"nationality": "Non-Saudi", "sex": "Total", "label": "Non-Saudi"},
        {"nationality": "Total", "sex": "Total", "label": "National Total"},
    ])
    if cohort.get("ok"):
        data = [["Cohort", "Unemployment Rate"]]
        for k, v in cohort["cohort_values"].items():
            data.append([k, f"{v:.2f}%"])
        tbl = Table(data, colWidths=[8*cm, 4*cm])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3a5c")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (1, 0), (1, -1), "RIGHT"),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f2f2")]),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.grey),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.lightgrey),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 0.2*cm))
        for g in cohort["gaps"]:
            story.append(Paragraph(f"• {g['pair']}: {g['gap']:+.2f}pp", styles["BodyCustom"]))

    # 3. Forecast
    story.append(Paragraph("3. Forecast — Next 4 Quarters", styles["H2Custom"]))
    f_ = forecast_indicator(db_path, "unemployment_rate", "Saudi", "Total", horizon=4)
    if f_.get("ok"):
        story.append(Paragraph(summarize_forecast(f_), styles["BodyCustom"]))
        data = [["Quarter", "Baseline", "Optimistic", "Pessimistic", "Lower 95%", "Upper 95%"]]
        for q, b, o, p, l, u in zip(f_["horizon_quarters"], f_["baseline"], f_["optimistic"],
                                     f_["pessimistic"], f_["lower_95"], f_["upper_95"]):
            data.append([q, f"{b:.2f}%", f"{o:.2f}%", f"{p:.2f}%", f"{l:.2f}%", f"{u:.2f}%"])
        tbl = Table(data, colWidths=[2.2*cm, 2.2*cm, 2.2*cm, 2.2*cm, 2.2*cm, 2.2*cm])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3a5c")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f2f2")]),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.grey),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.lightgrey),
        ]))
        story.append(tbl)

    # 4. Context from RAG
    if rag_insights:
        story.append(PageBreak())
        story.append(Paragraph("4. Qualitative Context", styles["H2Custom"]))
        story.append(Paragraph(
            "The following insights draw on prior economic studies and policy briefs:",
            styles["BodyCustom"]))
        for i, ins in enumerate(rag_insights[:5], 1):
            story.append(Paragraph(
                f"<b>From {ins.get('doc_id','Unknown')}:</b>", styles["BodyCustom"]))
            story.append(Paragraph(ins.get("text", "")[:500] + "...", styles["BodyCustom"]))

    # 5. Data validation
    val = validate_dataset(db_path)
    story.append(Paragraph("5. Data Validation", styles["H2Custom"]))
    for flag in val["flags"]:
        story.append(Paragraph("• " + flag, styles["BodyCustom"]))

    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph(
        "<i>Generated by the Labor Market Analysis Agent. Figures are preliminary "
        "and may be revised in subsequent quarters per GASTAT practice.</i>",
        styles["Meta"]))

    doc.build(story)
    return out_path


if __name__ == "__main__":
    import sys
    db = sys.argv[1] if len(sys.argv) > 1 else "data/labor.db"
    out = sys.argv[2] if len(sys.argv) > 2 else "data/processed/quarterly_briefing.pdf"

    # Get some RAG insights
    from tools.rag import RAGStore
    rag = RAGStore(backend="tfidf")
    n = rag.build_from_directory("data/rag_corpus")
    ctx = rag.search("What are the latest trends in Saudi unemployment and what are the drivers?", k=3)

    md = build_quarterly_report_md(db, rag_insights=ctx)
    md_path = out.replace(".pdf", ".md")
    with open(md_path, "w", encoding="utf-8") as fh:
        fh.write(md)
    print(f"Wrote markdown: {md_path}")

    path = build_quarterly_report_pdf(db, out, rag_insights=ctx)
    print(f"Wrote PDF: {path}")

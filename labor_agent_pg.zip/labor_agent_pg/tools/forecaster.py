"""
Forecasting Tool
================
Generates quarterly projections for labor market indicators.

Methods:
  - baseline: Holt-Winters exponential smoothing (additive trend + seasonal if n>=8)
    with sklearn fallback (linear trend on quarter index).
  - scenarios: applies positive/negative shocks on top of baseline.

Returns JSON with projected values, upper/lower bounds, and scenario paths.
"""
from __future__ import annotations

from db import connect
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any
from sklearn.linear_model import LinearRegression


def _q_key(q: str) -> tuple:
    return int(q[:4]), int(q[-1])


def _next_quarters(last: str, n: int) -> List[str]:
    y, q = _q_key(last)
    out = []
    for _ in range(n):
        q += 1
        if q > 4:
            q = 1
            y += 1
        out.append(f"{y}-Q{q}")
    return out


def fit_linear_trend(values: np.ndarray) -> tuple[np.ndarray, float, float, float]:
    """Fit y = slope*x + intercept. Returns (predictions, slope, intercept, rmse)."""
    x = np.arange(len(values)).reshape(-1, 1)
    m = LinearRegression().fit(x, values)
    pred = m.predict(x)
    rmse = float(np.sqrt(np.mean((values - pred) ** 2)))
    return pred, float(m.coef_[0]), float(m.intercept_), rmse


def _holt_winters(values: np.ndarray, horizon: int,
                  alpha: float = 0.5, beta: float = 0.3, gamma: float = 0.3,
                  seasonal_periods: int = 4) -> tuple[np.ndarray, float]:
    """
    Simple additive Holt-Winters (level + trend + seasonal). Hand-rolled so we
    don't depend on statsmodels for the POC.
    """
    n = len(values)
    if n < 2 * seasonal_periods:
        # Fall back to simple double exponential (no seasonality)
        level = values[0]
        trend = values[1] - values[0]
        for i in range(1, n):
            new_level = alpha * values[i] + (1 - alpha) * (level + trend)
            trend = beta * (new_level - level) + (1 - beta) * trend
            level = new_level
        forecast = np.array([level + (h + 1) * trend for h in range(horizon)])
        # In-sample rmse approx (simple)
        residuals = values - np.array([values[0] + i * trend for i in range(n)])
        rmse = float(np.sqrt(np.mean(residuals ** 2)))
        return forecast, rmse

    # Initialize components
    level = np.mean(values[:seasonal_periods])
    trend = (np.mean(values[seasonal_periods:2 * seasonal_periods]) -
             np.mean(values[:seasonal_periods])) / seasonal_periods
    seasonals = [values[i] - level for i in range(seasonal_periods)]
    fitted = np.zeros(n)
    for i in range(n):
        val = values[i]
        last_level = level
        s_idx = i % seasonal_periods
        prev_season = seasonals[s_idx]
        level = alpha * (val - prev_season) + (1 - alpha) * (level + trend)
        trend = beta * (level - last_level) + (1 - beta) * trend
        seasonals[s_idx] = gamma * (val - level) + (1 - gamma) * prev_season
        fitted[i] = level + trend + prev_season
    rmse = float(np.sqrt(np.mean((values - fitted) ** 2)))

    forecast = np.zeros(horizon)
    for h in range(horizon):
        s_idx = (n + h) % seasonal_periods
        forecast[h] = level + (h + 1) * trend + seasonals[s_idx]
    return forecast, rmse


def forecast_indicator(db_path: str, indicator: str, nationality: str = "Saudi",
                       sex: str = "Total", category: str = "All",
                       horizon: int = 4, method: str = "holt_winters") -> Dict[str, Any]:
    """
    Produce baseline + optimistic + pessimistic scenarios for the next `horizon` quarters.
    Scenarios apply +/- a shock equal to 0.5 * historical_std * progression factor.
    """
    con = connect(db_path)
    df = pd.read_sql_query("""
        SELECT quarter, value FROM labor_facts
        WHERE indicator=%s AND dimension='time_series' AND nationality=%s AND sex=%s AND category=%s
        ORDER BY quarter
    """, con.raw, params=(indicator, nationality, sex, category))
    con.close()

    if len(df) < 4:
        return {"ok": False, "error": f"Need at least 4 historical quarters; got {len(df)}."}

    df = df.assign(_k=df["quarter"].map(_q_key)).sort_values("_k").drop(columns="_k").reset_index(drop=True)
    values = df["value"].values
    last_q = df["quarter"].iloc[-1]

    if method == "linear":
        _, slope, intercept, rmse = fit_linear_trend(values)
        baseline = np.array([intercept + slope * (len(values) + h) for h in range(horizon)])
    else:
        baseline, rmse = _holt_winters(values, horizon)

    # Keep forecast in sensible range if it's a rate
    is_rate = indicator in ("unemployment_rate", "employment_to_population",
                            "labor_force_participation")
    if is_rate:
        baseline = np.clip(baseline, 0, 100)

    # Scenario shocks
    std = float(np.std(values))
    shock = 0.5 * std
    # Confidence interval from rmse
    ci = 1.96 * rmse
    optimistic = baseline - np.arange(1, horizon + 1) * (shock / 4)
    pessimistic = baseline + np.arange(1, horizon + 1) * (shock / 4)
    upper = baseline + ci
    lower = baseline - ci
    if is_rate:
        optimistic = np.clip(optimistic, 0, 100)
        pessimistic = np.clip(pessimistic, 0, 100)
        upper = np.clip(upper, 0, 100)
        lower = np.clip(lower, 0, 100)
        # For unemployment, lower scenario = "better" case
        if indicator == "unemployment_rate":
            pass  # optimistic is already lower
        else:
            # For LFP / employment ratio, higher = better, flip scenario names
            optimistic, pessimistic = pessimistic, optimistic

    future_quarters = _next_quarters(last_q, horizon)

    return {
        "ok": True,
        "indicator": indicator,
        "nationality": nationality,
        "sex": sex,
        "category": category,
        "method": method,
        "historical_rmse": round(rmse, 3),
        "last_historical_quarter": last_q,
        "last_historical_value": round(float(values[-1]), 3),
        "horizon_quarters": future_quarters,
        "baseline": [round(float(v), 3) for v in baseline],
        "optimistic": [round(float(v), 3) for v in optimistic],
        "pessimistic": [round(float(v), 3) for v in pessimistic],
        "upper_95": [round(float(v), 3) for v in upper],
        "lower_95": [round(float(v), 3) for v in lower],
        "historical_series": df.to_dict(orient="records"),
    }


def summarize_forecast(r: Dict) -> str:
    if not r.get("ok"):
        return f"Forecast unavailable: {r.get('error')}"
    end_q = r["horizon_quarters"][-1]
    end_b = r["baseline"][-1]
    end_o = r["optimistic"][-1]
    end_p = r["pessimistic"][-1]
    last_v = r["last_historical_value"]
    delta = end_b - last_v
    direction = "increase" if delta > 0 else "decrease"
    return (
        f"Baseline forecast projects {r['indicator'].replace('_',' ')} "
        f"({r['nationality']}/{r['sex']}) reaching {end_b:.2f} by {end_q}, "
        f"a {direction} of {abs(delta):.2f} vs {r['last_historical_quarter']} "
        f"({last_v:.2f}). Optimistic path: {end_o:.2f}. "
        f"Pessimistic path: {end_p:.2f}. "
        f"Method: {r['method']} (historical RMSE: {r['historical_rmse']:.2f})."
    )


if __name__ == "__main__":
    import sys
    import json
    db = sys.argv[1] if len(sys.argv) > 1 else "data/labor.db"

    print("=== Saudi Total Unemployment — 4Q forecast ===")
    r = forecast_indicator(db, "unemployment_rate", "Saudi", "Total", horizon=4)
    print(summarize_forecast(r))
    print()
    for q, b, o, p in zip(r["horizon_quarters"], r["baseline"],
                          r["optimistic"], r["pessimistic"]):
        print(f"  {q}: baseline={b:.2f} opt={o:.2f} pess={p:.2f}")

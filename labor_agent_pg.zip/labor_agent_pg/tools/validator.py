"""
Data Validation Tool
====================
Checks ingested labor market data for common quality issues.
Returns a structured report of flags the agent can surface to the user.
"""
from __future__ import annotations

from db import connect
from typing import Dict, List, Any

import pandas as pd


def validate_dataset(db_path: str) -> Dict[str, Any]:
    """Run a suite of validation checks and return a report."""
    con = connect(db_path)
    report: Dict[str, Any] = {"flags": [], "summary": {}, "ok": True}

    try:
        df = pd.read_sql_query("SELECT * FROM labor_facts", con.raw)
    except Exception as e:
        return {"flags": [f"Could not read labor_facts: {e}"], "summary": {}, "ok": False}

    if df.empty:
        return {"flags": ["No data found in labor_facts."], "summary": {}, "ok": False}

    # 1. Check value ranges
    # Rates should be between 0 and 100
    rate_indicators = ["unemployment_rate", "employment_to_population",
                       "labor_force_participation"]
    rates = df[df["indicator"].isin(rate_indicators)]
    out_of_range = rates[(rates["value"] < 0) | (rates["value"] > 100)]
    if not out_of_range.empty:
        report["flags"].append(
            f"{len(out_of_range)} rate values outside [0,100] range"
        )
        report["ok"] = False

    # 2. Check for duplicates
    dup_cols = ["quarter", "indicator", "dimension", "category", "nationality", "sex"]
    dups = df[df.duplicated(subset=dup_cols, keep=False)]
    if not dups.empty:
        report["flags"].append(f"{len(dups)} duplicate (quarter, dim, cat, nat, sex) rows")

    # 3. Missing quarters in time series
    ts_indicators = df[df["dimension"] == "time_series"]["indicator"].unique()
    for ind in ts_indicators:
        q = sorted(df[(df["indicator"] == ind) & (df["dimension"] == "time_series")]["quarter"].unique())
        if len(q) < 2:
            continue
        # Build expected list between first and last quarter
        first = q[0]
        last = q[-1]
        expected = _expand_quarters(first, last)
        missing = sorted(set(expected) - set(q))
        if missing:
            report["flags"].append(
                f"Indicator '{ind}' missing quarters: {missing[:4]}{'...' if len(missing)>4 else ''}"
            )

    # 4. Check identity: unemployment + employment-to-pop ~ labor-force-participation (approx)
    # LFP = employment ratio + (unemployment_rate * LFP / 100)   -> not exact identity, just trend check
    # Instead, check: employment_ratio <= LFP (always true)
    pivot = df[df["dimension"] == "time_series"].pivot_table(
        index=["quarter", "nationality", "sex"],
        columns="indicator",
        values="value",
        aggfunc="first",
    ).reset_index()
    if "employment_to_population" in pivot.columns and "labor_force_participation" in pivot.columns:
        bad = pivot[pivot["employment_to_population"] > pivot["labor_force_participation"] + 0.01]
        if not bad.empty:
            report["flags"].append(
                f"{len(bad)} rows where employment ratio > LFP (should be impossible)"
            )
            report["ok"] = False

    # 5. Large QoQ jumps (> 3 percentage points for Saudi total unemployment)
    ur = df[(df["indicator"] == "unemployment_rate") & (df["dimension"] == "time_series")
            & (df["nationality"] == "Saudi") & (df["sex"] == "Total")].sort_values("quarter")
    if len(ur) >= 2:
        ur = ur.copy()
        ur["delta"] = ur["value"].diff().abs()
        big = ur[ur["delta"] > 3.0]
        if not big.empty:
            report["flags"].append(
                f"{len(big)} large QoQ jumps (>3pp) in Saudi unemployment rate at: "
                + ", ".join(big["quarter"].tolist())
            )

    # Summary counts
    report["summary"] = {
        "total_rows": int(len(df)),
        "quarters": sorted(df["quarter"].unique().tolist()),
        "indicators": sorted(df["indicator"].unique().tolist()),
        "source_files": sorted(df["source_file"].unique().tolist()),
    }
    if not report["flags"]:
        report["flags"].append("No issues found.")
    con.close()
    return report


def _expand_quarters(first: str, last: str) -> List[str]:
    """Given '2021-Q1' and '2025-Q4', yield every quarter label in between."""
    fy, fq = int(first[:4]), int(first[-1])
    ly, lq = int(last[:4]), int(last[-1])
    out = []
    y, q = fy, fq
    while (y, q) <= (ly, lq):
        out.append(f"{y}-Q{q}")
        q += 1
        if q > 4:
            q = 1
            y += 1
    return out


if __name__ == "__main__":
    import json
    import sys
    db = sys.argv[1] if len(sys.argv) > 1 else "data/labor.db"
    print(json.dumps(validate_dataset(db), indent=2, default=str))

"""
GASTAT Labor Market Data Ingestion Pipeline
============================================
Parses quarterly labor market Excel files from Saudi Arabia's GASTAT into a
normalized long-format table and loads it into SQLite.

Handles the typical GASTAT layout:
  - Row 0: Title
  - Row 1: Table description
  - Row 2: "Table X-Y"
  - Row 3-5: Header block (Year/Quarter, Nationality: Saudi|Non Saudi|Total,
             then Male|Female|Total under each nationality)
  - Row 6+: Data

Produces a long-format DataFrame with columns:
  quarter, table_id, indicator, dimension, category, nationality, sex, value, source_file, ingested_at
"""
from __future__ import annotations

import os
import re
import hashlib
from db import connect
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd


# --- Table metadata: map GASTAT sheet names to standardized indicators & dimensions ---
TABLE_META = {
    "1":    ("main_indicators",                "snapshot"),
    "2-1":  ("unemployment_rate",              "time_series"),
    "2-2":  ("unemployment_rate",              "age_group"),
    "2-3":  ("unemployment_rate",              "education"),
    "2-4":  ("unemployment_rate",              "region"),
    "2-5":  ("unemployed_distribution",        "time_series"),
    "2-6":  ("unemployed_distribution",        "age_group"),
    "2-7":  ("unemployed_distribution",        "education"),
    "2-8":  ("unemployed_distribution",        "duration"),
    "2-9":  ("unemployed_distribution",        "work_experience"),
    "2-10": ("unemployed_job_search_methods",  "methods"),
    "2-11": ("unemployed_willing_private",     "sex"),
    "2-12": ("unemployed_commute_time",        "sex"),
    "2-13": ("unemployed_working_hours",       "sex"),
    "3-1":  ("employed_distribution",          "time_series"),
    "3-2":  ("employed_distribution",          "age_group"),
    "3-3":  ("employed_distribution",          "education"),
    "3-4":  ("employed_distribution",          "occupation"),
    "3-5":  ("employed_distribution",          "economic_activity"),
    "3-6":  ("employed_distribution",          "sector"),
    "4-1":  ("employment_to_population",       "time_series"),
    "4-2":  ("employment_to_population",       "age_group"),
    "4-3":  ("employment_to_population",       "education"),
    "4-4":  ("employment_to_population",       "region"),
    "5-1":  ("labor_force_participation",      "time_series"),
    "5-2":  ("labor_force_participation",      "age_group"),
    "5-3":  ("labor_force_participation",      "education"),
    "5-4":  ("labor_force_participation",      "region"),
    "5-5":  ("labor_force_distribution",       "time_series"),
    "5-6":  ("labor_force_distribution",       "age_group"),
    "5-7":  ("labor_force_distribution",       "education"),
    "5-8":  ("out_of_labor_force_distribution","time_series"),
    "5-9":  ("out_of_labor_force_distribution","age_group"),
    "5-10": ("out_of_labor_force_distribution","education"),
    "5-11": ("out_of_labor_force_attachment",  "attachment"),
    "5-12": ("working_age_population",         "time_series"),
    "5-13": ("working_age_population",         "age_group"),
    "5-14": ("working_age_population",         "education"),
    "5-15": ("working_age_population",         "labor_market_status"),
    "6-1":  ("average_monthly_wage",           "age_group"),
    "6-2":  ("average_monthly_wage",           "education"),
    "6-3":  ("average_monthly_wage",           "economic_activity"),
    "6-4":  ("average_working_hours",          "time_series"),
}


# --- Quarter parsing: handles "2021 Q1", "2021Q1", "Q1 2021" etc. ---
QUARTER_RE = re.compile(r"(?P<y>20\d{2})\s*Q(?P<q>[1-4])|Q(?P<q2>[1-4])\s*(?P<y2>20\d{2})", re.IGNORECASE)


def parse_quarter(val) -> Optional[str]:
    """Normalize to 'YYYY-Qn' format. Returns None for non-quarter cells."""
    if pd.isna(val):
        return None
    s = str(val).strip()
    m = QUARTER_RE.search(s)
    if not m:
        return None
    y = m.group("y") or m.group("y2")
    q = m.group("q") or m.group("q2")
    return f"{y}-Q{q}"


def infer_quarter_from_filename(path: str) -> Optional[str]:
    """Extract quarter from filename like 'Labor_Market_Q4_2025'."""
    name = os.path.basename(path)
    m = re.search(r"Q([1-4])[_\s]*(20\d{2})|(Fourth|Third|Second|First)[_\s]*[Qq]uarter[_\s]*(20\d{2})|(20\d{2})[_\s]*Q([1-4])", name, re.IGNORECASE)
    if not m:
        return None
    if m.group(1) and m.group(2):
        return f"{m.group(2)}-Q{m.group(1)}"
    if m.group(3) and m.group(4):
        q_map = {"first": 1, "second": 2, "third": 3, "fourth": 4}
        return f"{m.group(4)}-Q{q_map[m.group(3).lower()]}"
    if m.group(5) and m.group(6):
        return f"{m.group(5)}-Q{m.group(6)}"
    return None


def _clean_cell(val):
    if pd.isna(val):
        return None
    if isinstance(val, str):
        return val.strip()
    return val


def parse_time_series_sheet(df: pd.DataFrame, table_id: str, indicator: str,
                            source_file: str) -> pd.DataFrame:
    """
    Parse a time-series format sheet (Year/Quarter in col 0, then 9 value cols for
    Saudi M/F/T | Non-Saudi M/F/T | Total M/F/T).
    """
    records = []
    # Data starts at row 6 (0-indexed) for GASTAT format
    # Columns 1-9 are: Saudi_M, Saudi_F, Saudi_T, NonSaudi_M, NonSaudi_F, NonSaudi_T, Total_M, Total_F, Total_T
    nationality_order = ["Saudi", "Saudi", "Saudi", "Non-Saudi", "Non-Saudi", "Non-Saudi", "Total", "Total", "Total"]
    sex_order = ["Male", "Female", "Total", "Male", "Female", "Total", "Male", "Female", "Total"]

    for idx in range(len(df)):
        row = df.iloc[idx]
        quarter = parse_quarter(row.iloc[0])
        if not quarter:
            continue
        # Values in columns 1-9
        for col_i in range(9):
            if col_i + 1 >= len(row):
                break
            val = _clean_cell(row.iloc[col_i + 1])
            if val is None or (isinstance(val, str) and not val):
                continue
            try:
                v = float(val)
            except (TypeError, ValueError):
                continue
            records.append({
                "quarter": quarter,
                "table_id": table_id,
                "indicator": indicator,
                "dimension": "time_series",
                "category": "All",
                "nationality": nationality_order[col_i],
                "sex": sex_order[col_i],
                "value": v,
                "source_file": os.path.basename(source_file),
                "ingested_at": datetime.utcnow().isoformat(),
            })
    return pd.DataFrame(records)


def parse_breakdown_sheet(df: pd.DataFrame, table_id: str, indicator: str,
                          dimension: str, source_file: str,
                          snapshot_quarter: str) -> pd.DataFrame:
    """
    Parse a breakdown sheet (one quarter, broken down by age / education / region / etc).
    Column 0 (or col 0+1 for age) is the category label; columns 1..9 (or 2..10) are values.
    """
    records = []

    # Detect layout: age-group sheets have 11 columns (sub-group + age + 9 values)
    # Other breakdowns have 10 columns (category + 9 values)
    ncols = df.shape[1]
    if ncols >= 11 and dimension == "age_group":
        cat_col, val_start = 1, 2  # age groups in col 1
    else:
        cat_col, val_start = 0, 1

    nationality_order = ["Saudi", "Saudi", "Saudi", "Non-Saudi", "Non-Saudi", "Non-Saudi", "Total", "Total", "Total"]
    sex_order = ["Male", "Female", "Total", "Male", "Female", "Total", "Male", "Female", "Total"]

    # Find the data rows — skip header rows (first 6) and rows where col 0 starts with "Source" or is NaN
    for idx in range(6, len(df)):
        row = df.iloc[idx]
        cat = _clean_cell(row.iloc[cat_col])
        if cat is None or not isinstance(cat, str):
            continue
        low = cat.lower()
        if low.startswith("source") or low.startswith("note") or low.startswith("table") or low == "" or "nan" in low:
            continue
        # Skip sub-header rows like "Educational Level"
        if cat in ("Educational Level", "Age groups", "Nationality"):
            continue

        for col_i in range(9):
            cell = _clean_cell(row.iloc[val_start + col_i]) if val_start + col_i < len(row) else None
            if cell is None:
                continue
            try:
                v = float(cell)
            except (TypeError, ValueError):
                continue
            records.append({
                "quarter": snapshot_quarter,
                "table_id": table_id,
                "indicator": indicator,
                "dimension": dimension,
                "category": cat,
                "nationality": nationality_order[col_i],
                "sex": sex_order[col_i],
                "value": v,
                "source_file": os.path.basename(source_file),
                "ingested_at": datetime.utcnow().isoformat(),
            })
    return pd.DataFrame(records)


def parse_main_indicators(df: pd.DataFrame, table_id: str, source_file: str,
                          snapshot_quarter: str) -> pd.DataFrame:
    """Parse Table 1: Main indicators snapshot."""
    records = []
    nationality_order = ["Saudi", "Saudi", "Saudi", "Non-Saudi", "Non-Saudi", "Non-Saudi", "Total", "Total", "Total"]
    sex_order = ["Male", "Female", "Total", "Male", "Female", "Total", "Male", "Female", "Total"]

    for idx in range(6, len(df)):
        row = df.iloc[idx]
        label = _clean_cell(row.iloc[0])
        if not label or not isinstance(label, str):
            continue
        low = label.lower()
        if low.startswith(("source", "note", "labor market")):
            continue
        # Map indicator name
        label_key = label.strip().lower().replace(" ", "_").replace("-", "_")
        for col_i in range(9):
            cell = _clean_cell(row.iloc[col_i + 1]) if col_i + 1 < len(row) else None
            if cell is None:
                continue
            try:
                v = float(cell)
            except (TypeError, ValueError):
                continue
            records.append({
                "quarter": snapshot_quarter,
                "table_id": table_id,
                "indicator": f"main_{label_key}",
                "dimension": "snapshot",
                "category": label,
                "nationality": nationality_order[col_i],
                "sex": sex_order[col_i],
                "value": v,
                "source_file": os.path.basename(source_file),
                "ingested_at": datetime.utcnow().isoformat(),
            })
    return pd.DataFrame(records)


def ingest_gastat_xlsx(path: str, snapshot_quarter: Optional[str] = None) -> pd.DataFrame:
    """
    Main entry: parse a GASTAT xlsx and return a long-format DataFrame.
    If snapshot_quarter is not given, it's inferred from filename.
    """
    if snapshot_quarter is None:
        snapshot_quarter = infer_quarter_from_filename(path) or "unknown"

    all_sheets = pd.read_excel(path, sheet_name=None, header=None)
    frames = []

    for sheet_name, df in all_sheets.items():
        s = sheet_name.strip()
        if s.lower() in ("index", "contents", "notes"):
            continue
        if s not in TABLE_META:
            continue
        indicator, dimension = TABLE_META[s]

        try:
            if s == "1":
                f = parse_main_indicators(df, s, path, snapshot_quarter)
            elif dimension == "time_series":
                f = parse_time_series_sheet(df, s, indicator, path)
            else:
                f = parse_breakdown_sheet(df, s, indicator, dimension, path, snapshot_quarter)
            if not f.empty:
                frames.append(f)
        except Exception as e:
            print(f"[WARN] Failed to parse sheet '{s}': {e}")
            continue

    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True)
    # Deduplicate (quarter, table_id, indicator, dimension, category, nationality, sex)
    out = out.drop_duplicates(
        subset=["quarter", "table_id", "indicator", "dimension", "category", "nationality", "sex"],
        keep="last",
    )
    return out


# --- PostgreSQL persistence (bulk-inserts for speed over the network) ---

def init_db(_db_path: Optional[str] = None) -> None:
    """Apply schema.sql to the database. Idempotent — safe to call repeatedly.

    The `_db_path` argument is ignored; kept for backward-compat with old
    callers. The connection target comes from DATABASE_URL.
    """
    from db import init_schema
    init_schema()


def save_to_db(df: pd.DataFrame, _db_path: Optional[str] = None, source_file: str = "",
               validation_flags: Optional[str] = None) -> int:
    """
    Bulk-upsert all rows of `df` into labor_facts in a single round-trip.

    Compared to the old row-by-row INSERT loop, this is 10-100x faster against
    a remote PostgreSQL (Cloud SQL). 5,109 rows ingest in <1 second locally
    and <5 seconds against Cloud SQL via the proxy.

    Returns: number of rows touched (inserted or updated).
    """
    from db import connect, bulk_insert

    if df.empty:
        return 0

    init_db()

    # Build list of dicts for bulk_insert
    rows = df.to_dict(orient="records")

    con = connect()
    try:
        # Bulk upsert into labor_facts
        n = bulk_insert(
            con, "labor_facts", rows,
            columns=["quarter", "table_id", "indicator", "dimension",
                     "category", "nationality", "sex", "value",
                     "source_file", "ingested_at"],
            on_conflict_keys=["quarter", "table_id", "indicator", "dimension",
                              "category", "nationality", "sex"],
        )

        # Audit log entry
        file_hash = None
        try:
            with open(source_file, "rb") as fh:
                file_hash = hashlib.md5(fh.read()).hexdigest()
        except Exception:
            pass
        snapshot = df["quarter"].mode().iat[0] if not df.empty else None
        con.execute(
            """INSERT INTO ingestion_log
               (source_file, file_hash, snapshot_quarter, rows_ingested, validation_flags)
               VALUES (%s, %s, %s, %s, %s)""",
            (os.path.basename(source_file), file_hash, snapshot, n,
             validation_flags or "")
        )
        con.commit()
    finally:
        con.close()
    return n


def get_connection(_db_path: Optional[str] = None):
    """Backward-compatible accessor. Use db.connect() directly in new code."""
    from db import connect
    return connect()


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python ingestion.py <path_to_xlsx> [db_path_ignored]")
        sys.exit(1)
    path = sys.argv[1]
    df = ingest_gastat_xlsx(path)
    print(f"Parsed {len(df):,} rows from {path}")
    print(df.head(5).to_string())
    n = save_to_db(df, None, path)
    print(f"\nUpserted {n:,} rows into labor_facts.")
